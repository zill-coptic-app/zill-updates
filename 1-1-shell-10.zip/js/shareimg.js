/* Verse copy / share text / share image card / save image. User-initiated only. Offline.
   Native (Capacitor plugins) when available, Web APIs otherwise. */
function zPlug(n) { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n]; }
function wrapLines(ctx, text, maxW) {
  const words = text.split(/\s+/), lines = []; let cur = '';
  words.forEach(w => { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
  if (cur) lines.push(cur); return lines;
}
function zRefIso(ref) { return ref.replace(/(\S+)$/, (m, t) => '\u2066' + t.replace(/\u200E/g, '').replace(/[^\u0660-\u0669]/g, '\u200E$&\u200E') + '\u2069'); }
function zFmtCopy(text, ref) { return '«' + text + '»\n— ' + zRefIso(ref); }
/* Story-size card 1080x1920, style A (dark glass). Text shrinks to fit; returns null when the passage is too long for a readable card.
   Layout: nothing in the top ~250px or bottom ~300px (story UI). A clear band at y 1300-1440 is kept empty so the user can place an Instagram link sticker. */
function zRR(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
/* emerald share palette (follows the current theme; classic skin keeps the old look) */
function zPal() {
  const light = document.documentElement.getAttribute('data-theme') === 'light';
  return light ? { light: true, plate: 'img/skin/plate-light.jpg', veil: 'rgba(244,243,228,.58)', text: '#1E3A2E', gold: '#7C5A14', sub: '#5B6F5E', panel: 'rgba(255,255,255,.62)', stroke: 'rgba(124,90,20,.45)', logo: 'img/skin/logo-light.png' }
               : { light: false, plate: 'img/skin/plate-dark.jpg', veil: 'rgba(5,28,22,.46)', text: '#F4EFDC', gold: '#E9C074', sub: '#CBD8C9', panel: 'rgba(6,36,28,.58)', stroke: 'rgba(233,192,116,.5)', logo: 'img/skin/logo-dark.png' };
}
function zImgSrc(src) { return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; }); }
async function zPaintBg(ctx, W, H, P, veil) {
  const im = await zImgSrc(P.plate);
  if (im) { const k = Math.max(W / im.width, H / im.height), w = im.width * k, h = im.height * k; ctx.drawImage(im, (W - w) / 2, 0, w, h); }
  else { ctx.fillStyle = P.light ? '#E9EFDC' : '#0B2A22'; ctx.fillRect(0, 0, W, H); }
  ctx.fillStyle = veil || P.veil; ctx.fillRect(0, 0, W, H);
}
function zLogoImg() { return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = 'assets/img/logo_zill.png'; }); }
async function verseCanvas(text, ref) {
  { const P0 = zPal(); if (P0) return verseCanvasE(text, ref, P0); }
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 52px "Noto Naskh Arabic"'); await document.fonts.load('700 38px "Noto Sans Arabic"'); } } catch (e) {}
  const P = zPal(), logo = P ? await zImgSrc(P.logo) : await zLogoImg();
  const W = 1080, H = 1920, c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  const availH = 760, maxW = 820; let size = 68, lines = [], lh = 0, ok = false;
  for (; size >= 40; size -= 2) {
    ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif'; ctx.direction = 'rtl';
    lines = wrapLines(ctx, text, maxW); lh = Math.round(size * 1.9);
    if (lines.length * lh <= availH) { ok = true; break; }
  }
  if (!ok) return null;
  const g = ctx.createLinearGradient(0, 0, W * 0.6, H); g.addColorStop(0, '#101731'); g.addColorStop(0.55, '#1a1440'); g.addColorStop(1, '#2a1a52');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const r1 = ctx.createRadialGradient(W * 0.8, H * 0.18, 10, W * 0.8, H * 0.18, 650); r1.addColorStop(0, 'rgba(138,112,230,.30)'); r1.addColorStop(1, 'rgba(138,112,230,0)'); ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);
  const r2 = ctx.createRadialGradient(W * 0.15, H * 0.8, 10, W * 0.15, H * 0.8, 600); r2.addColorStop(0, 'rgba(227,178,87,.14)'); r2.addColorStop(1, 'rgba(227,178,87,0)'); ctx.fillStyle = r2; ctx.fillRect(0, 0, W, H);
  if (P) await zPaintBg(ctx, W, H, P);
  ctx.direction = 'rtl'; ctx.textAlign = 'center';
  const bh = lines.length * lh, cy = H * 0.46, ph = bh + 290, pw = 940, px = (W - pw) / 2, py = cy - ph / 2;
  ctx.save(); zRR(ctx, px, py, pw, ph, 56); ctx.fillStyle = P ? P.panel : 'rgba(255,255,255,.07)'; ctx.fill(); ctx.lineWidth = P ? 3 : 2; ctx.strokeStyle = P ? P.stroke : 'rgba(255,255,255,.18)'; ctx.stroke(); ctx.restore();
  ctx.fillStyle = P ? P.gold : '#E3B257'; ctx.font = '700 64px "Noto Sans Arabic", sans-serif'; ctx.fillText('\u271D', W / 2, Math.min(365, py - 30));
  const top = cy - bh / 2 + size * 1.05;
  ctx.fillStyle = P ? P.text : '#F4EFE2'; ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  lines.forEach((l, i) => ctx.fillText(l, W / 2, top + i * lh));
  const yr = top + (lines.length - 1) * lh + 120;
  ctx.fillStyle = P ? P.gold : '#E3B257'; ctx.fillRect(W / 2 - 55, yr - 70, 110, 3);
  ctx.font = '700 46px "Noto Sans Arabic", sans-serif'; ctx.fillText(zRefIso(ref), W / 2, yr + 10);
  const by = 1500;
  if (P && logo) { const lw = 360, lh2 = Math.round(lw * logo.height / logo.width); ctx.drawImage(logo, W / 2 - lw / 2, by - 70, lw, lh2); ctx.fillStyle = P.gold; ctx.font = '700 40px "Noto Sans Arabic", sans-serif'; ctx.fillText('مساحتك الروحية', W / 2, by - 70 + lh2 + 52); return c; }
  if (logo) { ctx.save(); ctx.globalAlpha = 0.95; zRR(ctx, W / 2 - 60, by - 60, 120, 120, 28); ctx.clip(); ctx.drawImage(logo, W / 2 - 60, by - 60, 120, 120); ctx.restore(); }
  ctx.fillStyle = '#A9A5C8'; ctx.font = '700 30px "Noto Sans Arabic", sans-serif'; ctx.fillText('ظِلّ', W / 2, by + 105);
  return c;
}

/* Selected verse design (user pick 23:45): church silhouette, glowing cross, gold glass frame, overlapping reference pill, logo + gold ribbons. All text is real text; art is drawn here or cropped from the user's chosen image (church only). */
function zGoldGrad(ctx, x0, x1, light) { const g = ctx.createLinearGradient(x0, 0, x1, 0); if (light) { g.addColorStop(0, '#9A7420'); g.addColorStop(.5, '#D9B25A'); g.addColorStop(1, '#9A7420'); } else { g.addColorStop(0, '#B98A33'); g.addColorStop(.5, '#F6DC94'); g.addColorStop(1, '#B98A33'); } return g; }
function zCross(ctx, cx, top, h, w, fill) { const t = w, a = h * 0.32; ctx.fillStyle = fill; ctx.fillRect(cx - t / 2, top, t, h); ctx.fillRect(cx - h * 0.28, top + a, h * 0.56, t); }
async function verseCanvasE(text, ref, P) {
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 52px "Noto Naskh Arabic"'); await document.fonts.load('700 38px "Noto Sans Arabic"'); } } catch (e) {}
  const W = 1080, H = 1920, L = P.light, c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  const maxW = 780, availH = 620; let size = 68, lines = [], lh = 0, ok = false;
  for (; size >= 40; size -= 2) { ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif'; ctx.direction = 'rtl'; lines = wrapLines(ctx, text, maxW); lh = Math.round(size * 1.85); if (lines.length * lh <= availH) { ok = true; break; } }
  if (!ok) return null;
  await zPaintBg(ctx, W, H, P, L ? 'rgba(244,243,228,.30)' : 'rgba(5,28,22,.22)');
  const bh = lines.length * lh, fH = Math.max(560, bh + 250), fX = 50, fW = 980, fT = 660, fB = fT + fH, cx = W / 2;
  // church silhouette, upper left, feathered into the plate
  const ch = await zImgSrc(L ? 'img/skin/church-light.png' : 'img/skin/church-dark.png');
  if (ch) { const cw = 540, chh = Math.round(cw * ch.height / ch.width), t = document.createElement('canvas'); t.width = cw; t.height = chh; const tc = t.getContext('2d'); tc.drawImage(ch, 0, 0, cw, chh); tc.globalCompositeOperation = 'destination-in'; tc.save(); tc.translate(cw * .5, chh * .52); tc.scale(cw * .5, chh * .5); const rg = tc.createRadialGradient(0, 0, 0, 0, 0, 1); [[0,1],[.3,.96],[.5,.75],[.68,.42],[.84,.14],[1,0]].forEach(a => rg.addColorStop(a[0], 'rgba(0,0,0,' + a[1] + ')')); tc.fillStyle = rg; tc.fillRect(-1, -1, 2, 2); tc.restore();  ctx.globalAlpha = L ? .9 : .85; ctx.drawImage(t, -10, fT - 150 - chh); ctx.globalAlpha = 1; }
  // glowing cross + rules
  const ry = fT - 70; ctx.save(); ctx.shadowColor = L ? 'rgba(217,178,90,.9)' : 'rgba(255,225,140,.95)'; ctx.shadowBlur = 40; zCross(ctx, cx, ry - 170, 170, 20, L ? '#1E4A33' : '#F6DC94'); ctx.restore();
  ctx.fillStyle = zGoldGrad(ctx, 120, 440, L); ctx.fillRect(120, ry, 320, 3); ctx.fillStyle = zGoldGrad(ctx, 640, 960, L); ctx.fillRect(640, ry, 320, 3);
  // frame
  ctx.save(); zRR(ctx, fX, fT, fW, fH, 70); ctx.fillStyle = L ? 'rgba(255,255,255,.55)' : 'rgba(8,48,38,.55)'; ctx.fill(); ctx.shadowColor = L ? 'rgba(217,178,90,.7)' : 'rgba(246,220,148,.8)'; ctx.shadowBlur = 26; ctx.lineWidth = 5; ctx.strokeStyle = zGoldGrad(ctx, fX, fX + fW, L); ctx.stroke(); ctx.restore();
  // verse
  ctx.direction = 'rtl'; ctx.textAlign = 'center'; ctx.fillStyle = P.text; ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  const top = fT + (fH - 110 - bh) / 2 + size * 1.05 + 10; lines.forEach((l, i) => ctx.fillText(l, cx, top + i * lh));
  // small cross + rules near the bottom of the frame
  const sy = fB - 62; ctx.fillStyle = zGoldGrad(ctx, 280, 480, L); ctx.fillRect(280, sy, 200, 3); ctx.fillStyle = zGoldGrad(ctx, 600, 800, L); ctx.fillRect(600, sy, 200, 3);
  zCross(ctx, cx, sy - 22, 46, 7, L ? '#9A7420' : '#F0D184');
  // reference pill, overlapping the frame edge
  const rf = ref.replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 1632)).replace(/(\S+)$/, '\u2066$1\u2069');
  ctx.font = '700 40px "Noto Sans Arabic", sans-serif'; const pw = Math.max(280, Math.ceil(ctx.measureText(rf).width) + 90), ph = 76, py = fB - 8;
  ctx.save(); zRR(ctx, cx - pw / 2, py, pw, ph, 38); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 14; ctx.fillStyle = L ? '#1E4A33' : zGoldGrad(ctx, cx - pw / 2, cx + pw / 2, false); ctx.fill(); ctx.restore();
  ctx.fillStyle = L ? '#F6E7B4' : '#10352B'; ctx.textBaseline = 'middle'; ctx.fillText(rf, cx, py + ph / 2 + 2); ctx.textBaseline = 'alphabetic';
  // ribbons at the bottom
  const rb = (y0, y1, a, w) => { ctx.beginPath(); ctx.moveTo(0, y0); ctx.bezierCurveTo(W * .3, y0 + 140, W * .62, y1 + 40, W, y1); ctx.lineWidth = w; ctx.strokeStyle = a; ctx.stroke(); };
  ctx.save(); ctx.fillStyle = L ? 'rgba(46,110,70,.18)' : 'rgba(120,200,160,.14)'; ctx.beginPath(); ctx.moveTo(0, 1790); ctx.bezierCurveTo(W * .3, 1930, W * .62, 1760, W, 1690); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  rb(1800, 1700, zGoldGrad(ctx, 0, W, L), 4); rb(1830, 1735, L ? 'rgba(154,116,32,.55)' : 'rgba(246,220,148,.5)', 2.5); rb(1865, 1775, L ? 'rgba(154,116,32,.35)' : 'rgba(246,220,148,.3)', 2); ctx.restore();
  // logo + tagline
  const logo = await zImgSrc(P.logo), ly = Math.max(1470, py + ph + 70);
  if (logo) { const lw = 300, lh2 = Math.round(lw * logo.height / logo.width); ctx.drawImage(logo, cx - lw / 2, ly, lw, lh2); const ty = ly + lh2 + 46; ctx.fillStyle = P.gold; ctx.font = '700 38px "Noto Sans Arabic", sans-serif'; ctx.textAlign = 'center'; ctx.fillText('مساحتك الروحية', cx, ty); const tw = ctx.measureText('مساحتك الروحية').width / 2; ctx.fillStyle = zGoldGrad(ctx, 100, 400, L); ctx.fillRect(cx - tw - 40 - 200, ty - 14, 200, 3); ctx.fillRect(cx + tw + 40, ty - 14, 200, 3); }
  c.__layout = { size, lines: lines.length, fT, fB }; return c;
}
async function zCopy(text, ref) {
  const s = zFmtCopy(text, ref), CB = zPlug('Clipboard');
  try { if (CB && CB.write) { await CB.write({ string: s }); return 'copied'; } } catch (e) {}
  try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(s); return 'copied'; } } catch (e) {}
  try { const t = document.createElement('textarea'); t.value = s; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok ? 'copied' : 'failed'; } catch (e) { return 'failed'; }
}
async function zShareText(text, ref) {
  const s = zFmtCopy(text, ref), SH = zPlug('Share');
  try { if (SH && SH.share) { await SH.share({ text: s, dialogTitle: 'مشاركة آية' }); return 'shared'; } } catch (e) { return 'cancelled'; }
  try { if (navigator.share) { await navigator.share({ text: s }); return 'shared'; } } catch (e) { return 'cancelled'; }
  return await zCopy(text, ref) === 'copied' ? 'copied-fallback' : 'failed';
}
function zB64(c) { return c.toDataURL('image/png').split(',')[1]; }
async function zShareImage(text, ref) {
  const c = await verseCanvas(text, ref); if (!c) return 'toolong';
  const SH = zPlug('Share'), FS = zPlug('Filesystem');
  if (SH && FS) {
    try {
      const name = 'zill_share/verse-' + Date.now() + '.png';
      await FS.writeFile({ path: name, data: zB64(c), directory: 'CACHE', recursive: true });
      const u = await FS.getUri({ path: name, directory: 'CACHE' });
      await SH.share({ files: [u.uri], dialogTitle: 'مشاركة آية' }); return 'shared';
    } catch (e) { return /cancel/i.test(String(e && e.message || e)) ? 'cancelled' : 'failed'; }
  }
  const blob = await new Promise(r => c.toBlob(r, 'image/png')), file = new File([blob], 'verse.png', { type: 'image/png' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return 'shared'; } catch (e) { return 'cancelled'; } }
  return zDownload(blob);
}
function zDownload(blob) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'verse.png'; document.body.appendChild(a); a.click(); a.remove(); return 'downloaded'; }
async function zSaveImage(text, ref) {
  const c = await verseCanvas(text, ref); if (!c) return 'toolong';
  const FS = zPlug('Filesystem');
  if (FS) {
    try { await FS.writeFile({ path: 'Zill/verse-' + Date.now() + '.png', data: zB64(c), directory: 'DOCUMENTS', recursive: true }); return 'saved'; }
    catch (e) { return 'savefail'; }
  }
  return zDownload(await new Promise(r => c.toBlob(r, 'image/png')));
}

/* Whole-chapter image, landscape: title + every verse with its number, flowed RTL into N columns (right column first, text flows line by line, a verse may continue into the next column), app colours.
   Columns and font size are picked so the image is about 1.8:1 or wider; very long chapters get the smallest size and may end up taller. */
async function chapterCanvas(title, verses, opts) {
  { const P0 = zPal(); if (P0) return chapterCanvasE(title, verses, P0); }
  opts = opts || {};
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 30px "Noto Naskh Arabic"'); await document.fonts.load('700 44px "Noto Sans Arabic"'); } } catch (e) {}
  const P = zPal(), logo = P ? await zImgSrc(P.logo) : await zLogoImg();
  const W = 2400, PAD = 80, GAP = 50, headH = 190, footH = 130, MINR = 1.75;
  const m = document.createElement('canvas').getContext('2d'); m.direction = 'rtl';
  const layout = (cols, size) => {
    const colW = Math.floor((W - PAD * 2 - GAP * (cols - 1)) / cols), lh = Math.round(size * 1.9), lines = [];
    m.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
    verses.forEach(v => { if (v.extra) { wrapLines(m, v.t, colW).forEach(l => lines.push({ l, extra: true })); return; } const num = toArabicDigits(String(v.n)); wrapLines(m, num + ' ' + v.t, colW).forEach((l, i) => lines.push({ l, first: i === 0, num })); });
    const per = Math.ceil(lines.length / cols), H = headH + per * lh + footH;
    return { cols, size, colW, lh, lines, per, H };
  };
  let best = null;
  if (P) {   // emerald: one landscape image, whole chapter, never split. Biggest font whose columns are at least ~9em wide and whose shape is landscape (>=1.4:1).
    outerP: for (let size = 60; size >= 28; size -= 2) for (let cols = 2; cols <= 7; cols++) { const colW = Math.floor((W - PAD * 2 - GAP * (cols - 1)) / cols); if (colW < size * 9) break; const L = layout(cols, size); if (W / L.H >= 1.4) { best = L; break outerP; } }
    if (!best) best = layout(7, 28);
    const H0 = best.H; best.H = Math.max(H0, Math.round(W / 1.9)); best.off = Math.floor((best.H - H0) / 2);
  } else {
  outer: for (let size = 42; size >= 22; size -= 2) for (let cols = 3; cols <= 8; cols++) { const L = layout(cols, size); if (W / L.H >= MINR) { best = L; break outer; } }
  if (!best) best = layout(8, 22);
  }
  const { cols, size, colW, lh, lines, per, H } = best, off = best.off || 0;
  const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, W * 0.7, H); g.addColorStop(0, '#101731'); g.addColorStop(0.55, '#1a1440'); g.addColorStop(1, '#2a1a52'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  if (P) await zPaintBg(ctx, W, H, P, P.light ? 'rgba(244,243,228,.80)' : 'rgba(4,24,19,.74)');
  if (!P) { const r1 = ctx.createRadialGradient(W * 0.88, 60, 10, W * 0.88, 60, 800); r1.addColorStop(0, 'rgba(138,112,230,.26)'); r1.addColorStop(1, 'rgba(138,112,230,0)'); ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H); }
  ctx.direction = 'rtl'; ctx.textAlign = 'right';
  ctx.fillStyle = P ? P.gold : '#E3B257'; ctx.font = '700 58px "Noto Sans Arabic", sans-serif'; ctx.fillText(title, W - PAD, 100);
  ctx.fillRect(PAD, 130, W - PAD * 2, 3);
  ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  lines.forEach((ln, i) => {
    const col = Math.floor(i / per), row = i % per, x = W - PAD - col * (colW + GAP), y = headH + off + row * lh;
    if (ln.extra) { ctx.fillStyle = P ? P.sub : '#C9A55A'; ctx.fillText(ln.l, x, y); }
    else if (ln.first) { ctx.fillStyle = P ? P.gold : '#E3B257'; ctx.fillText(ln.num, x, y); const nw = ctx.measureText(ln.num + ' ').width; ctx.fillStyle = P ? P.text : '#F4EFE2'; ctx.fillText(ln.l.slice(ln.num.length + 1), x - nw, y); }
    else { ctx.fillStyle = P ? P.text : '#F4EFE2'; ctx.fillText(ln.l, x, y); }
  });
  ctx.textAlign = 'center'; ctx.fillStyle = P ? P.gold : '#A9A5C8'; ctx.font = '700 30px "Noto Sans Arabic", sans-serif';
  if (P && logo) { const lw = 150, lh2 = Math.round(lw * logo.height / logo.width); ctx.drawImage(logo, W / 2 - lw / 2 - 150, H - 112, lw, lh2); ctx.fillText('مساحتك الروحية', W / 2 + 40, H - 50); c.__layout = { cols, size, W, H }; return c; }
  if (logo) { ctx.save(); zRR(ctx, W / 2 - 30, H - 108, 60, 60, 14); ctx.clip(); ctx.drawImage(logo, W / 2 - 30, H - 108, 60, 60); ctx.restore(); }
  ctx.fillText('ظِلّ', W / 2, H - 28);
  c.__layout = { cols, size, W, H };
  return c;
}



/* Emerald chapter image (user reference 23:50): church + emerald/gold title plaque + framed text columns + book/cross + logo plaque. ONE landscape image, whole chapter, never split.
   Canvas width grows with the chapter: columns stay ~14em wide; layout is the one with the largest text relative to the image width among landscape (>=1.3:1) ones within <=16 MP and <=8000px wide. */
async function zArt(src, w, mask, tint) {
  const im = await zImgSrc(src); if (!im) return null;
  const h = Math.round(w * im.height / im.width), t = document.createElement('canvas'); t.width = w; t.height = h; const tc = t.getContext('2d'); tc.drawImage(im, 0, 0, w, h);
  if (tint) { tc.globalCompositeOperation = 'source-atop'; tc.fillStyle = tint; tc.fillRect(0, 0, w, h); }
  tc.globalCompositeOperation = 'destination-in'; tc.save(); tc.translate(w * .5, h * .5); tc.scale(w * .5, h * .5); const rg = tc.createRadialGradient(0, 0, 0, 0, 0, 1); [[0,1],[.3,.96],[.5,.75],[.68,.42],[.84,.14],[1,0]].forEach(a => rg.addColorStop(a[0], 'rgba(0,0,0,' + a[1] + ')')); tc.fillStyle = rg; tc.fillRect(-1, -1, 2, 2); tc.restore();
  return t;
}
async function chapterCanvasE(title, verses, P) {
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 40px "Noto Naskh Arabic"'); await document.fonts.load('700 44px "Noto Sans Arabic"'); } } catch (e) {}
  const L = P.light, GAP = 56, MAXPX = 16e6, MAXW = 8000;
  const m = document.createElement('canvas').getContext('2d'); m.direction = 'rtl';
  const layout = (cols, size) => {
    const k = Math.max(1, size / 40), colW = Math.round(size * 14), MX = Math.round(60 * k), PI = Math.round(70 * k), W = 2 * (MX + PI) + cols * colW + GAP * (cols - 1), u = Math.max(k, Math.min(W / 2400, 1.35));
    const lh = Math.round(size * 1.9), T = Math.round(300 * u), B = Math.round(270 * u), lines = [];
    m.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
    verses.forEach(v => { if (v.extra) { wrapLines(m, v.t, colW).forEach(l => lines.push({ l, extra: true })); return; } const num = toArabicDigits(String(v.n)); wrapLines(m, num + ' ' + v.t, colW).forEach((l, i) => lines.push({ l, first: i === 0, num })); });
    const per = Math.ceil(lines.length / cols), H0 = T + 2 * PI + per * lh + B, H = Math.max(H0, Math.round(W / 1.9));
    return { cols, size, colW, W, H, H0, lh, lines, per, T, B, MX, PI, u, off: Math.floor((H - H0) / 2) };
  };
  let best = null, bs = 0;
  for (let size = 60; size >= 26; size -= 2) for (let cols = 2; cols <= 18; cols++) { const Lt = layout(cols, size); if (Lt.W > MAXW || Lt.W * Lt.H > MAXPX) break; if (Lt.W / Lt.H0 >= 1.3 && size / Lt.W > bs) { bs = size / Lt.W; best = Lt; } }
  if (!best) best = layout(2, 26);
  const { cols, size, colW, W, H, lh, lines, per, T, B, MX, PI, u, off } = best;
  const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  await zPaintBg(ctx, W, H, P, L ? 'rgba(244,243,228,.25)' : 'rgba(4,24,19,.25)');
  const gold = L ? '#B8892E' : '#E9C074', gg = ctx.createLinearGradient(0, 0, W, 0); gg.addColorStop(0, gold); gg.addColorStop(.5, L ? '#E8CB7E' : '#F6DC94'); gg.addColorStop(1, gold);
  // church, top left, behind the panel edge
  const dk = L ? null : 'rgba(4,26,20,.86)', ch = await zArt('img/skin/chap-church.png', Math.round(520 * u), .62, dk);
  if (ch) { ctx.globalAlpha = .95; if (!L) ctx.globalCompositeOperation = 'lighten'; ctx.drawImage(ch, Math.round(10 * u), Math.round(T - ch.height * .86 + 40 * u)); ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1; }
  // hills at the bottom
  ctx.save(); ctx.fillStyle = L ? 'rgba(70,130,90,.30)' : 'rgba(40,110,80,.38)'; ctx.beginPath(); ctx.moveTo(0, H - B * .62); ctx.bezierCurveTo(W * .25, H - B * 1.0, W * .5, H - B * .35, W * .75, H - B * .8); ctx.bezierCurveTo(W * .9, H - B * 1.0, W * .96, H - B * .8, W, H - B * .85); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  ctx.fillStyle = L ? 'rgba(60,120,80,.35)' : 'rgba(30,95,70,.45)'; ctx.beginPath(); ctx.moveTo(0, H - B * .35); ctx.bezierCurveTo(W * .3, H - B * .7, W * .6, H - B * .1, W, H - B * .45); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill(); ctx.restore();
  // panel
  const pX = MX, pY = T, pW = W - 2 * MX, pH = H - T - B + 40 * u, rr = 60 * u;
  ctx.save(); zRR(ctx, pX, pY, pW, pH, rr); ctx.fillStyle = L ? 'rgba(248,243,224,.94)' : 'rgba(6,38,30,.88)'; ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 40 * u; ctx.fill(); ctx.restore();
  ctx.lineWidth = Math.max(3, 5 * u); ctx.strokeStyle = gg; zRR(ctx, pX, pY, pW, pH, rr); ctx.stroke();
  ctx.lineWidth = Math.max(2, 2 * u); ctx.strokeStyle = L ? 'rgba(184,137,46,.55)' : 'rgba(233,192,116,.45)'; zRR(ctx, pX + 16 * u, pY + 16 * u, pW - 32 * u, pH - 32 * u, rr - 14 * u); ctx.stroke();
  // text columns
  ctx.direction = 'rtl'; ctx.textAlign = 'right'; ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  const x0 = W - MX - PI, y0 = T + PI + size * 1.1 + off;
  lines.forEach((ln, i) => {
    const col = Math.floor(i / per), row = i % per, x = x0 - col * (colW + GAP), y = y0 + row * lh;
    if (ln.extra) { ctx.fillStyle = P.sub; ctx.fillText(ln.l, x, y); }
    else if (ln.first) { ctx.fillStyle = L ? '#9A7420' : '#E9C074'; ctx.fillText(ln.num, x, y); const nw = ctx.measureText(ln.num + ' ').width; ctx.fillStyle = P.text; ctx.fillText(ln.l.slice(ln.num.length + 1), x - nw, y); }
    else { ctx.fillStyle = P.text; ctx.fillText(ln.l, x, y); }
  });
  for (let i = 1; i < cols; i++) { const x = x0 - i * (colW + GAP) + GAP / 2; ctx.fillStyle = L ? 'rgba(184,137,46,.35)' : 'rgba(233,192,116,.3)'; ctx.fillRect(x - 1, T + PI * 0.8, 2, pH - PI * 1.5); }
  // title plaque with glowing cross
  ctx.textAlign = 'center'; ctx.font = '700 ' + Math.round(64 * u) + 'px "Noto Sans Arabic", sans-serif';
  const tw = Math.ceil(ctx.measureText(title).width), qw = Math.max(tw + 260 * u, 640 * u), qh = 140 * u, qx = W / 2 - qw / 2, qy = T - qh * .55;
  ctx.save(); ctx.shadowColor = 'rgba(255,225,140,.9)'; ctx.shadowBlur = 36 * u; zCross(ctx, W / 2, qy - 120 * u, 120 * u, 14 * u, L ? '#D9B25A' : '#F6DC94'); ctx.restore();
  ctx.save(); zRR(ctx, qx, qy, qw, qh, 50 * u); ctx.fillStyle = 'rgba(8,52,40,.96)'; ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 20 * u; ctx.fill(); ctx.restore();
  ctx.lineWidth = Math.max(3, 4 * u); ctx.strokeStyle = gg; zRR(ctx, qx, qy, qw, qh, 50 * u); ctx.stroke();
  ctx.fillStyle = '#F2D58A'; ctx.textBaseline = 'middle'; ctx.fillText(title, W / 2, qy + qh / 2 + 4 * u); ctx.textBaseline = 'alphabetic';
  // book + cross, bottom left
  const bk = await zArt('img/skin/chap-book.png', Math.round(560 * u), .66, L ? null : 'rgba(5,28,22,.35)');
  if (bk) ctx.drawImage(bk, Math.round(20 * u), H - bk.height - Math.round(6 * u));
  // logo plaque, bottom centre
  const logo = await zImgSrc('img/skin/logo-dark.png'), lw = 300 * u, lh2 = logo ? Math.round(lw * logo.height / logo.width) : 0, bw = 560 * u, bh = 190 * u, bx = W / 2 - bw / 2, by = H - bh - 22 * u;
  ctx.save(); zRR(ctx, bx, by, bw, bh, 60 * u); ctx.fillStyle = 'rgba(8,52,40,.96)'; ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 20 * u; ctx.fill(); ctx.restore();
  ctx.lineWidth = Math.max(3, 4 * u); ctx.strokeStyle = gg; zRR(ctx, bx, by, bw, bh, 60 * u); ctx.stroke();
  if (logo) { const lw2 = 200 * u, lh3 = Math.round(lw2 * logo.height / logo.width); ctx.drawImage(logo, W / 2 - lw2 / 2, by + 16 * u, lw2, lh3); ctx.fillStyle = '#F2D58A'; ctx.font = '700 ' + Math.round(34 * u) + 'px "Noto Sans Arabic", sans-serif'; ctx.fillText('مساحتك الروحية', W / 2, by + 16 * u + lh3 + 40 * u); }
  c.__layout = { cols, size, W, H, px: W * H, lines: lines.length, per }; return c;
}

/* chapter data for sharing: verses in order plus source psalm title / subscriptions (unnumbered lines) */
function chapterShareVerses(book, chapter) {
  const vs = book.chapters[String(chapter)] || {}, ex = (BIBLE.extras && BIBLE.extras[String(book.id)] && BIBLE.extras[String(book.id)][String(chapter)]) || {}, out = [];
  if (ex.h) out.push({ extra: true, t: bibleExtraText(ex.h) });
  Object.keys(vs).map(Number).sort((a, b) => a - b).forEach(n => { out.push({ n, t: tashText(book.id, chapter, n, vs[String(n)]) }); (ex.f || []).filter(x => x[0] === n).forEach(x => out.push({ extra: true, t: bibleExtraText(x[1]) })); });
  return out;
}

async function zShareChapter(book, chapter) {
  const title = (book.id <= 39 ? 'سفر ' : book.id <= 43 ? 'إنجيل ' : '') + book.name + '، الأصحاح ' + toArabicDigits(chapter);
  const c = await chapterCanvas(title, chapterShareVerses(book, chapter));
  const SH = zPlug('Share'), FS = zPlug('Filesystem');
  if (SH && FS) {
    try {
      const name = 'zill_share/chapter-' + book.id + '-' + chapter + '-' + Date.now() + '.png';
      await FS.writeFile({ path: name, data: zB64(c), directory: 'CACHE', recursive: true });
      const u = await FS.getUri({ path: name, directory: 'CACHE' });
      await SH.share({ files: [u.uri], dialogTitle: 'مشاركة أصحاح' }); return 'shared';
    } catch (e) { return /cancel/i.test(String(e && e.message || e)) ? 'cancelled' : 'failed'; }
  }
  const blob = await new Promise(r => c.toBlob(r, 'image/png')), file = new File([blob], 'chapter.png', { type: 'image/png' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return 'shared'; } catch (e) { return 'cancelled'; } }
  return 'unavailable';
}

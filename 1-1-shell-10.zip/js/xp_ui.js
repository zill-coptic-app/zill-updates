/* ظل: XP hooks + pages «هدف اليوم» and «رحلتي في ظل». Local only, stored on this device. */
(function () {
  const X = window.ZXP; if (!X) return;
  const AR = n => (window.toArabicDigits ? toArabicDigits(n) : String(n));
  const eng = () => X.create(localStorage);
  const SESSION = {}; // per-game round counters (memory only)
  const ROUND = 5;    // app choice: every 5 answered questions in a game = one finished round
  function css() {
    if (document.getElementById('xpCss')) return;
    const s = document.createElement('style'); s.id = 'xpCss';
    s.textContent = '.xp-card{background:var(--card-bg);border:1px solid var(--card-border);border-radius:20px;padding:14px;margin:10px 0}' +
      '.xp-bar{height:10px;border-radius:99px;background:rgba(127,127,127,.25);overflow:hidden;margin:8px 0}.xp-bar>i{display:block;height:100%;background:var(--gold);border-radius:99px;transition:width .5s}' +
      '.xp-lv{font-weight:700;font-size:17px}.xp-sub{font-size:13px;opacity:.8}' +
      '.xp-act{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 0;border-top:1px solid var(--card-border)}.xp-act:first-of-type{border-top:0}' +
      '.xp-st{font-size:12px;padding:3px 10px;border-radius:99px;border:1px solid var(--card-border)}.xp-st.on{background:var(--gold);color:var(--on-gold);border-color:var(--gold)}' +
      '.xp-btn{display:inline-block;padding:7px 14px;border-radius:99px;background:var(--gold);color:var(--on-gold);font-weight:700;font-size:14px;cursor:pointer;margin-inline-start:6px}.xp-btn.ghost{background:transparent;color:var(--text);border:1px solid var(--card-border)}' +
      '.xp-ach{display:flex;gap:10px;align-items:center;padding:8px 0;border-top:1px solid var(--card-border)}.xp-ach.off{opacity:.5}' +
      '.xp-toast{position:fixed;left:50%;bottom:84px;transform:translateX(-50%);pointer-events:none;z-index:9999;max-width:88%;background:var(--gold);color:var(--on-gold);padding:10px 18px;border-radius:18px;font-weight:700;font-size:14px;box-shadow:0 8px 22px rgba(0,0,0,.35);text-align:center}' +
      '.xp-lvup{animation:xpPop .6s ease}@keyframes xpPop{0%{transform:translateX(-50%) scale(.7);opacity:0}60%{transform:translateX(-50%) scale(1.08)}100%{transform:translateX(-50%) scale(1);opacity:1}}' +
      '.xp-row2{display:flex;justify-content:space-between;padding:5px 0;font-size:14px}';
    document.head.appendChild(s);
  }
  let tq = [], tbusy = false;
  function toast(msg, up) { tq.push([msg, up]); if (!tbusy) nextToast(); }
  function nextToast() {
    const it = tq.shift(); if (!it) { tbusy = false; return; } tbusy = true; css();
    const d = document.createElement('div'); d.className = 'xp-toast' + (it[1] ? ' xp-lvup' : ''); d.textContent = it[0]; d.setAttribute('role', 'status');
    document.body.appendChild(d); setTimeout(() => { d.remove(); nextToast(); }, 2600);
  }
  function notes(res, label) {
    (res.notes || []).forEach(n => {
      if (n.type === 'level') toast('ترقية! ' + (n.ledger === 'game' ? 'مستوى الألعاب: ' : 'مستوى النمو: ') + n.level.name, true);
      else if (n.type === 'ach') toast('إنجاز جديد: ' + n.n);
      else if (n.type === 'goal') toast('كملت هدف اليوم. ربنا يبارك.');
    });
  }
  function safe(f) { try { return f(); } catch (e) { return null; } }
  window.zxpLogin = function () { safe(() => { const r = eng().game('login'); if (r.awarded) toast('+' + AR(r.awarded) + ' نقاط دخول اليوم'); notes(r); }); };
  window.zxpQ = function (game, right) {
    safe(() => {
      const e = eng(), s = SESSION[game] || (SESSION[game] = { n: 0, ok: 0 });
      s.n++; if (right) s.ok++;
      notes(e.game(right ? 'correct' : 'wrong', game));
      if (s.n >= ROUND) { const flawless = s.ok === s.n; SESSION[game] = { n: 0, ok: 0 }; notes(e.game('complete', game, { flawless })); }
    });
  };
  window.zxpDone = function (game, opt) {
    safe(() => {
      const e = eng(); notes(e.game('complete', game, { flawless: false }));
      if (opt && opt.hardKey) notes(e.game('hard', game, { key: opt.hardKey }));
    });
  };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const bar = l => '<div class="xp-bar"><i style="width:' + l.pct + '%"></i></div>';
  const lvBlock = (title, l) => '<div class="xp-card"><div class="xp-sub">' + title + '</div><div class="xp-lv">المستوى ' + AR(l.level) + ' · ' + esc(l.name) + '</div>' + bar(l) +
    '<div class="xp-sub">' + AR(l.total) + ' نقطة' + (l.next !== null ? ' · باقي ' + AR(l.toNext) + ' للمستوى «' + esc(l.nextName) + '»' : ' · أعلى مستوى') + '</div></div>';
  const dkey = () => { const d = new Date(), p = n => (n < 10 ? '0' : '') + n; return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); };
  function goal() {
    css(); const e = eng(), st = e.state ? null : null; const raw = JSON.parse(localStorage.getItem('zill.xp.growth') || '{}'); const day = (raw.days || {})[dkey()] || {};
    const sm = e.summary(); const pts = (day.chapter ? 20 : 0) + (day.prayer ? 15 : 0) + (day.verse ? 5 : 0) + (day.goal ? 10 : 0);
    const left = [!day.chapter && 'قراءة إصحاح اليوم', !day.prayer && 'وقت الصلاة'].filter(Boolean);
    const pct = Math.round(((day.chapter ? 1 : 0) + (day.prayer ? 1 : 0)) * 50);
    const row = (id, name, pts, on, btn) => '<div class="xp-act"><div><b>' + name + '</b><div class="xp-sub">' + AR(pts) + ' نقطة</div></div><div><span class="xp-st' + (on ? ' on' : '') + '">' + (on ? 'مكتمل' : 'لم يبدأ') + '</span>' + (on ? '' : btn) + '</div></div>';
    const html = lvBlock('نقاط النمو الروحي', sm.growth.level) +
      '<div class="xp-card"><div class="xp-lv">هدف اليوم الأساسي (القراءة والصلاة): ' + AR(pct) + '٪</div>' + bar({ pct }) + '<div class="xp-sub">نقاط اليوم: ' + AR(pts) + ' · المتبقي من الهدف الأساسي: ' + (left.length ? left.join('، ') : 'لا شيء') + '</div><div class="xp-sub">' + (day.verse ? 'التأمل: اكتمل (إضافي)' : 'التأمل إضافي واختياري، مش شرط لإكمال الهدف.') + '</div>' +
      (day.goal ? '<p class="advice-src">كملت هدف اليوم بالقراءة والصلاة. ثبّتك الرب على المواظبة.</p>' : '<p class="advice-src">أتمّ القراءة والصلاة معًا وخد 10 نقاط إضافية.</p>') + '</div>' +
      '<div class="xp-card">' +
      row('c', 'قراءة إصحاح اليوم', 20, day.chapter, '<span class="xp-btn ghost" id="xpRead">اقرأ</span><span class="xp-btn" id="xpC">سجّلت القراءة</span>') +
      row('p', 'وقت الصلاة', 15, day.prayer, '<span class="xp-btn" id="xpP">صليت</span>') +
      row('v', 'تأمل اليوم', 5, day.verse, '<span class="xp-btn ghost" id="xpMed">آية اليوم</span><span class="xp-btn" id="xpV">تأملت</span>') +
      '</div><p class="advice-src">التسجيل يدوي: انت اللي بتقول إنك قريت وصليت، والنقاط محفوظة على جهازك بس. الدخول للتطبيق لوحده مابيدّيش نقاط نمو.</p>' +
      '<div class="bk-list"><div class="bk-row" role="button" id="xpToJ"><span class="bk-name">رحلتي في ظل</span></div></div>';
    zxShowPage('هدف اليوم', '', '', html, 'home');
    const mark = (act, opt) => () => { const r = safe(() => eng().growth(act, opt)); if (r) { if (r.awarded) toast('+' + AR(r.awarded) + ' نقطة'); notes(r); } goal(); };
    const g = id => document.getElementById(id);
    if (g('xpRead')) g('xpRead').onclick = () => window.zxOpenChapterOfDay && zxOpenChapterOfDay();
    if (g('xpMed')) g('xpMed').onclick = () => { try { document.querySelector('[data-sec="today"]').click(); } catch (e) {} };
    if (g('xpC')) g('xpC').onclick = async () => { let bk = null, ch = null; try { const pack = await bibleLoad(); const c = chapterOfDay(pack, new Date()); bk = c.book.id; ch = c.ch; } catch (e) {} mark('chapter', { book: bk, chapter: ch })(); };
    if (g('xpP')) g('xpP').onclick = mark('prayer');
    if (g('xpV')) g('xpV').onclick = mark('verse');
    g('xpToJ').onclick = journey;
  }
  function journey() {
    css(); const e = eng(), s = e.summary(), raw = JSON.parse(localStorage.getItem('zill.xp.growth') || '{}'), gr = JSON.parse(localStorage.getItem('zill.xp.game') || '{}');
    const days = raw.days || {}, now = new Date(), p = n => (n < 10 ? '0' : '') + n, k = d => d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
    const week = [], dn = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    let wk = 0, mo = 0, mc = 0;
    for (let i = 0; i < 7; i++) { const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i); const x = days[k(d)] || {}; week.push('<div class="xp-row2"><span>' + dn[d.getDay()] + ' ' + AR(d.getDate()) + '</span><span>' + (x.chapter ? 'قراءة ' : '') + (x.prayer ? 'صلاة ' : '') + (x.verse ? 'تأمل ' : '') + (x.goal ? '✓' : '') + (!x.chapter && !x.prayer && !x.verse ? '·' : '') + '</span></div>'); if (x.goal) wk++; }
    Object.keys(days).forEach(key => { if (key.slice(0, 7) === k(now).slice(0, 7)) { if (days[key].goal) mo++; if (days[key].chapter) mc++; } });
    const ach = s.achievements, aRow = a => '<div class="xp-ach' + (a.done ? '' : ' off') + '"><span class="xp-st' + (a.done ? ' on' : '') + '">' + (a.done ? '✓' : '○') + '</span><div><b>' + esc(a.n) + '</b><div class="xp-sub">' + esc(a.d) + (a.done ? ' · ' + a.date : '') + '</div></div></div>';
    const gs = gr.stats || {};
    const html = lvBlock('نقاط النمو الروحي', s.growth.level) +
      '<div class="xp-card"><div class="xp-row2"><span>الإصحاحات المقروءة</span><b>' + AR(s.growth.chapters) + '</b></div><div class="xp-row2"><span>أيام أتممت فيها هدفك</span><b>' + AR(s.growth.goalDays) + '</b></div>' +
      '<div class="xp-row2"><span>الأيام المتتالية الحالية</span><b>' + AR(s.growth.streak) + '</b></div><div class="xp-row2"><span>أطول سلسلة</span><b>' + AR(s.growth.longest) + '</b></div>' +
      '<div class="xp-row2"><span>إنجازات النمو</span><b>' + AR(s.growth.ach) + '</b></div></div>' +
      '<h2 class="rd-sec-title">محطات الاستمرارية</h2><div class="xp-card">' + X.STREAK_STEPS.map(st => { const on = s.growth.longest >= st[0]; return '<div class="xp-ach' + (on ? '' : ' off') + '"><span class="xp-st' + (on ? ' on' : '') + '">' + (on ? '✓' : '○') + '</span><div><b>' + esc(st[1]) + '</b><div class="xp-sub">' + AR(st[0]) + ' ' + (st[0] === 1 ? 'يوم' : st[0] < 11 ? 'أيام' : 'يومًا') + ' متتالي (قراءة وصلاة)</div></div></div>'; }).join('') + '<div class="xp-sub">السلسلة الحالية: ' + AR(s.growth.streak) + ' · لو فات يوم تبدأ السلسلة من جديد، لكن النقاط والإنجازات بتفضل.</div></div>' +
      '<h2 class="rd-sec-title">سجل آخر ٧ أيام</h2><div class="xp-card">' + week.join('') + '</div>' +
      '<div class="xp-card"><div class="xp-row2"><span>ملخص أسبوعي: أيام هدف مكتمل</span><b>' + AR(wk) + ' / ٧</b></div><div class="xp-row2"><span>ملخص الشهر: أيام هدف مكتمل</span><b>' + AR(mo) + '</b></div><div class="xp-row2"><span>إصحاحات هذا الشهر (حسب التسجيل)</span><b>' + AR(mc) + '</b></div></div>' +
      '<h2 class="rd-sec-title">إنجازات النمو</h2><div class="xp-card">' + ach.filter(a => a.kind === 'growth').map(aRow).join('') + '</div>' +
      '<h2 class="rd-sec-title">الألعاب (رصيد منفصل)</h2>' + lvBlock('نقاط الألعاب', s.game.level) +
      '<div class="xp-card"><div class="xp-row2"><span>ألعاب مكتملة</span><b>' + AR(s.game.completed) + '</b></div><div class="xp-row2"><span>أطول سلسلة إجابات صحيحة</span><b>' + AR(gs.bestRun || 0) + '</b></div><div class="xp-row2"><span>إنجازات الألعاب</span><b>' + AR(s.game.ach) + '</b></div></div>' +
      '<h2 class="rd-sec-title">إنجازات الألعاب</h2><div class="xp-card">' + ach.filter(a => a.kind === 'game').map(aRow).join('') + '</div>' +
      '<p class="advice-src">النقاط محفوظة على جهازك فقط، ومتضمنة في نسخة الاحتياط. نقاط الألعاب ونقاط النمو مش بتتجمع مع بعض.</p>';
    zxShowPage('رحلتي في ظل', '', '', html, 'home');
  }
  function gameCard() { css(); const r = safe(() => lvBlock('نقاط الألعاب', eng().summary().game.level)); return r || ''; }
  window.ZXPUI = { goal, journey, gameCard };
})();

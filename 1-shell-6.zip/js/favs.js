/* Favorites (قراءاتي) — localStorage bookmarks for bible chapters, days'
   readings and synax entries. Fully offline. */
const FAVS_KEY = 'zill.favs';

function favsLoad() {
  try { return JSON.parse(localStorage.getItem(FAVS_KEY) || '[]'); } catch (e) { return []; }
}
function favsSave(list) { localStorage.setItem(FAVS_KEY, JSON.stringify(list)); }
function favsHas(id) { return favsLoad().some(f => f.id === id); }
function favsToggle(entry) {
  const list = favsLoad();
  const i = list.findIndex(f => f.id === entry.id);
  if (i >= 0) { list.splice(i, 1); favsSave(list); return false; }
  list.unshift(entry);
  favsSave(list);
  return true;
}

/* Offline bible search with light Arabic normalization. */
function arNorm(s) {
  return String(s)
    .replace(/[ً-ْٰ]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/ة/g, 'ه');
}

function bibleSearch(pack, query, limit) {
  const q = arNorm(query.trim());
  if (q.length < 2) return [];
  const out = [];
  for (const book of pack.books) {
    for (const [ch, verses] of Object.entries(book.chapters)) {
      for (const [n, text] of Object.entries(verses)) {
        if (arNorm(text).includes(q)) {
          out.push({ bookId: book.id, book: book.name, chapter: +ch, verse: +n, text });
          if (out.length >= (limit || 60)) return out;
        }
      }
    }
  }
  return out;
}

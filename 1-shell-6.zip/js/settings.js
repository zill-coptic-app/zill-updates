/* Settings: theme, optional reminders (OFF by default, user picks the time), hidden-by-default
   home customization (user 01:37: only inside settings, simple default home). */
const SET_KEY = 'zill.settings';
const REMINDERS = [
  { id: 1, name: 'آية اليوم', body: 'آية النهاردة مستنياك في ظِلّ.', fixed: '14:00', always: true },   // fixed by the user 18:03: verse 2 pm
  { id: 2, name: 'نصيحة اليوم', body: 'نصيحة النهاردة مستنياك في ظِلّ.', fixed: '15:00', always: true },   // user 18:03: spiritual saying 3 pm
  { id: 3, name: 'وقت الصلاة', body: 'حان وقت الصلاة اللي اخترتها.' },
  { id: 4, name: 'منبّه', body: 'المنبّه بتاعك.', alarm: true }
];
const HIDEABLE = [['synax', 'السنكسار'], ['snake', 'الثعبان'], ['game', 'مين الشخصية؟'], ['fathers', 'أقوال وتأملات'], ['doctrine', 'العقيدة'], ['games2', 'ألعاب أكتر'], ['bios', 'السِّيَر'], ['suggest', 'اقتراحاتك']];
function setLoad() { try { return JSON.parse(localStorage.getItem(SET_KEY) || '{}'); } catch (e) { return {}; } }
function setSave(o) { localStorage.setItem(SET_KEY, JSON.stringify(o)); }
function hiddenSections() { return setLoad().hidden || []; }

function remOn(r, t) { return !!(r.always || (t && t.on)); }
function remTimeOf(r, t) { return r.fixed || (t && t.time) || ''; }
function zillAlarmPlugin() {
  const C = window.Capacitor; if (!C) return null;
  try { return C.registerPlugin ? C.registerPlugin('ZillAlarm') : (C.Plugins && C.Plugins.ZillAlarm) || null; } catch (e) { return (C.Plugins && C.Plugins.ZillAlarm) || null; }
}
async function quotesLoad() {
  if (window.__quotes) return window.__quotes;
  try { window.__quotes = (await packLoadJson('quotes-ar', 'content/packs/quotes-ar.json')).verses || []; } catch (e) {}
  return window.__quotes || [];
}
/* the verse of a given date: the same pick the Home card uses (index into the baked verse list) */
function verseForDate(Q, d) { return Q.length ? Q[dayIndex(d) % Q.length] : null; }

async function remindersApply(st) {
  const code = await remindersApplyCore(st);
  try { const now = new Date(), s2 = setLoad(); s2.remState = { code, at: now.getTime(), until: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 29, 15, 0, 0).getTime() }; setSave(s2); } catch (e) {}
  return code;
}
function remStatusText() {
  const rs = setLoad().remState; if (!rs || rs.code === 'web-only') return '';
  const dt = new Date(rs.until), ds = toArabicDigits(String(dt.getDate())) + '/' + toArabicDigits(String(dt.getMonth() + 1));
  if (rs.until < Date.now()) return 'الجدولة خلصت. افتح التطبيق عشان تتجدد.';
  if (rs.code === 'denied') return 'التذكيرات مفعّلة في التطبيق، لكن إذن الإشعارات مقفول من إعدادات الموبايل، فمفيش تذكير هيوصلك لحد ما تفتحه.';
  if (rs.code === 'error') return 'حصلت مشكلة في جدولة التذكيرات. افتح التطبيق تاني.';
  if (rs.code === 'inexact') return 'اتجدولت لحد ' + ds + '، بس الموبايل مش مسمّح بالمنبّهات الدقيقة فممكن تتأخر.';
  return 'اتجدولت لحد ' + ds + ' (٣٠ يوم). بتتجدد تلقائيًا كل ما تفتح التطبيق، فلو ماتفتحتش هتقف بعد التاريخ ده.';
}
async function remindersApplyCore(st) {
  const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
  if (!LN) return 'web-only';           // no native plugin: preferences saved, nothing scheduled
  try {
    const ZA0 = zillAlarmPlugin();
    if (ZA0) { // the alarm itself needs no notification permission, so set or cancel it first
      for (const r of REMINDERS) if (r.alarm) { const t = (st.rem || {})[r.id], tm = remTimeOf(r, t);
        try { if (t && t.on && tm) { const [ah, am] = tm.split(':').map(Number); await ZA0.setAlarm({ hour: ah, minute: am }); } else await ZA0.cancelAlarm(); } catch (e) {} }
    }
    const perm = await LN.requestPermissions();
    if (perm.display !== 'granted') return 'denied';
    try { await LN.createChannel({ id: 'zill_remind', name: 'تذكيرات ظِلّ', importance: 4, sound: 'zill_knock.ogg' }); } catch (e) {}
    const ZA = zillAlarmPlugin();
    const DAYS = 30, cancelIds = [];
    REMINDERS.forEach(r => { cancelIds.push({ id: r.id }); for (let i = 0; i < DAYS; i++) cancelIds.push({ id: r.id * 100 + i }); });
    await LN.cancel({ notifications: cancelIds });
    const list = [], now = new Date();
    const Q = await quotesLoad();
    const tash = st.tash !== '0';
    let alarmNative = false;
    for (const r of REMINDERS) { const t = (st.rem || {})[r.id]; const tm = remTimeOf(r, t);
      if (r.alarm && ZA) continue; // handled above
      if (!(remOn(r, t) && tm)) continue;
      const [h, m] = tm.split(':').map(Number);
      const base = { title: 'ظِلّ', channelId: 'zill_remind', sound: 'zill_knock.ogg' };
      if (r.id === 1 || r.id === 2) {   // per-day content, scheduled for the next 30 days, refreshed whenever the app opens
        for (let i = 0; i < DAYS; i++) {
          const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, h, m, 0);
          if (d <= now) continue;
          let body = r.body, extra = {};
          if (r.id === 2 && CONTENT.pack) { const a = adviceForToday(CONTENT.pack, d); if (a) body = a.crisis + ': ' + a.tip.replace(/\n/g, ' ، '); }
          if (r.id === 1) { const v = verseForDate(Q, d);
            if (v) { const ref = v.r.replace(/^(.+?)\s*(\d+):(\d+)$/, (mm, n, c, vv) => n + ' ' + toArabicDigits(c) + ':' + toArabicDigits(vv)), txt = tash ? v.t : v.p;
              body = txt; extra = { largeBody: txt + '\n' + ref, summaryText: ref }; body = txt + ' (' + ref + ')'; } }
          list.push(Object.assign({ id: r.id * 100 + i, body, schedule: { at: d, allowWhileIdle: true } }, base, extra));
        }
      } else list.push(Object.assign({ id: r.id, body: r.body, schedule: { on: { hour: h, minute: m }, allowWhileIdle: true } }, base));
    }
    if (list.length) await LN.schedule({ notifications: list });
    try { if (list.length && LN.checkExactNotificationSetting) { const ex = await LN.checkExactNotificationSetting(); if (ex && ex.exact_alarm && ex.exact_alarm !== 'granted') return 'inexact'; } } catch (e) {}
    return 'scheduled';
  } catch (e) { return 'error'; }
}

function settingsHTML(mode) {
  const st = setLoad(), rem = st.rem || {}, hid = st.hidden || [];
  const escT = s => String(s == null ? '' : s).replace(/[<>&"]/g, '');
  const thList = (window.zThemes ? zThemes() : [{ id: 'dark', name: 'داكن' }, { id: 'light', name: 'فاتح' }]);
  const curTheme = localStorage.getItem('zill.theme') || 'dark';
  let h = '<h2 class="rd-sec-title">المظهر</h2><div class="game-actions">' + thList.map(t => '<span class="game-btn' + (curTheme === t.id ? ' sel' : '') + '" data-theme-set="' + escT(t.id) + '">' + escT(t.name) + '</span>').join('') + '</div>';
  const rs = st.rs || '1', ls = st.ls || '1';
  h += '<h2 class="rd-sec-title">حجم الخط</h2><div class="game-actions">' + [['1','عادي'],['1.15','كبير'],['1.3','أكبر']].map(([v,n]) => '<span class="game-btn' + (rs === v ? ' sel' : '') + '" data-rs="' + v + '">' + n + '</span>').join('') + '</div>';
  h += '<h2 class="rd-sec-title">المسافة بين السطور</h2><div class="game-actions">' + [['1','عادي'],['1.2','واسع']].map(([v,n]) => '<span class="game-btn' + (ls === v ? ' sel' : '') + '" data-ls="' + v + '">' + n + '</span>').join('') + '</div>';
  h += '<h2 class="rd-sec-title">التشكيل (الكتاب المقدس)</h2><div class="game-actions">' + [['1','بالتشكيل'],['0','بدون']].map(([v,n]) => '<span class="game-btn' + ((st.tash || '1') === v ? ' sel' : '') + '" data-tash="' + v + '">' + n + '</span>').join('') + '</div><p class="bible-src">التشكيل من نص فان دايك المشكول (eBible.org). أي آية مش متطابقة معاه بتظهر بدون تشكيل.</p>';
  { const D = document.documentElement.dataset;
  h += '<h2 class="rd-sec-title">الحركة</h2><div class="game-actions">' + [['1','انتقالات ناعمة'],['0','بدون حركة (أخف)']].map(([v,n]) => '<span class="game-btn' + (D.motion === v ? ' sel' : '') + '" data-fx="' + v + '">' + n + '</span>').join('') + '</div>';
  h += '<h2 class="rd-sec-title">الشفافية والزجاج</h2><div class="game-actions">' + [['1','زجاج شفاف'],['0','بدون شفافية (أخف)']].map(([v,n]) => '<span class="game-btn' + (D.glass === v ? ' sel' : '') + '" data-fg="' + v + '">' + n + '</span>').join('') + '</div><p class="bible-src">لو موبايلك بطيء اختار «أخف». الاختيار بتاعك بيفضل محفوظ.</p>'; }
  const remStart = h.length;
  h += '<h2 class="rd-sec-title">التذكيرات</h2>';
  REMINDERS.forEach(r => { const t = rem[r.id] || {};
    h += '<div class="set-row"><label>' + (r.always ? '<span class="set-always" aria-hidden="true">✓</span> ' : '<input type="checkbox" data-rem-on="' + r.id + '"' + (t.on ? ' checked' : '') + '> ') + r.name + '</label>' +
      (r.fixed ? '<span class="set-fixed">كل يوم ' + toArabicDigits(String(+r.fixed.split(':')[0] % 12 || 12)) + ':' + toArabicDigits(r.fixed.split(':')[1]) + ' م</span>' : '<input type="time" class="set-time" data-rem-time="' + r.id + '" value="' + (t.time || '') + '">') + '</div>'; });
  h += '<p class="rd-concl" id="remStatus">' + (mode === 'rem' ? remStatusText() : '') + '</p>';
  const remEnd = h.length;
  h += '<h2 class="rd-sec-title">إخفاء من الرئيسية</h2>';
  HIDEABLE.forEach(([id, n]) => { h += '<div class="set-row"><label><input type="checkbox" data-hide="' + id + '"' + (hid.includes(id) ? ' checked' : '') + '> ' + n + '</label></div>'; });
  h += '<p class="rd-concl">الأقسام المخفية تفضل موجودة، بس مش ظاهرة في الرئيسية.</p>';
  h += '<h2 class="rd-sec-title">نسخة من بياناتك</h2><p class="rd-concl">بتنسخ المفضلة والإعدادات ومكان القراءة كنص تحتفظ بيه، وترجّعه في أي وقت من هنا.</p><div class="game-actions"><span class="game-btn" id="zBkBtn" role="button">انسخ بياناتي</span></div><textarea id="zBkBox" hidden readonly dir="ltr" rows="4" style="width:100%;margin-top:8px"></textarea><p class="rd-concl" id="zBkSt"></p><p class="rd-concl">عندك نص نسخة محفوظ؟ الصقه هنا، هنراجعه ونقولك إيه اللي جواه قبل ما يتكتب أي حاجة.</p><textarea id="zRsBox" dir="ltr" rows="4" style="width:100%" placeholder="الصق نص النسخة هنا"></textarea><div class="game-actions"><span class="game-btn" id="zRsChk" role="button">راجع النص</span><span class="game-btn" id="zRsGo" role="button" hidden>استرجع البيانات دي</span></div><p class="rd-concl" id="zRsSt"></p>';
  // Content updates row: rendered only when an update endpoint is configured
  // (UPDATER.endpoint is null in every current build, so this stays hidden).
  if (typeof UPDATER !== 'undefined' && UPDATER.endpoint) {
    h += '<h2 class="rd-sec-title">تحديث المحتوى</h2><p class="rd-concl" id="zUpdSt"></p><div id="zUpdNews"></div>';
  }
  h += '<h2 class="rd-sec-title">المصادر والصور</h2><div id="creditsBox"><p class="rd-concl">نص الكتاب المقدس: ترجمة سميث وفان دايك (ملكية عامة)، مراجَع على نسخة ثانية من نفس الترجمة.</p><div dir="ltr" class="cred-en">eBible.org arb-vd</div><p class="rd-concl">الأسفار القانونية الثانية: مصدر الترجمة لسه بنتأكد منه.</p><p class="rd-concl">نصيحة اليوم: صياغة من كتابة التطبيق (مش اقتباسات من آباء) والآيات من نص الكتاب المقدس. لسه ما اتراجعتش كنسيًا.</p><p class="rd-concl">نصوص الأجبية: من مجموعة ملفات عربية رقمية (coptic_io). ملفات الترانيم في نفس المجموعة مسجّل فيها روابط tasbeha.org، لكن ملفات الأجبية نفسها مفيهاش مصدر مسجّل، والطبعة بالظبط مش معروفة، وإذن إعادة استخدام النص لسه ما اتأكدش منه، ولم تُراجَع كنسيًا. (إشعار حقوق التسجيل الصوتي للقداس الغريغوري منفصل وخاص بالتسجيل فقط.)</p><p class="rd-concl">الخطوط:</p><div dir="ltr" class="cred-en">Noto Naskh Arabic, Noto Sans Arabic (SIL OFL)</div></div>';
  zFillCredits();
  setTimeout(() => { if (typeof updaterShowNews === 'function') { updaterShowStatus(); updaterShowNews(); } }, 0);
  if (mode === 'rem') return h.slice(remStart, remEnd).replace(/<h2 class="rd-sec-title">[^<]*<\/h2>/, '<p class="rd-intro">آية اليوم ونصيحة اليوم مفعّلين في التطبيق دايمًا. وصولهم لموبايلك بيعتمد على إذن الإشعارات. باقي التذكيرات فعّل اللي تحتاجه.</p>');
  return h.slice(0, remStart) + h.slice(remEnd);
}

function applyReading() { const st = setLoad(), r = document.documentElement.style; r.setProperty('--rs', st.rs || '1'); r.setProperty('--lhm', st.ls || '1'); }

async function zFillCredits() {
  try {
    if (!window.__imgcred) { try { window.__imgcred = await packLoadJson('image-credits', 'content/packs/image-credits.json'); } catch (e) { window.__imgcred = []; } }
    setTimeout(() => {
      const box = document.getElementById('creditsBox'); if (!box || box.dataset.done) return; box.dataset.done = '1';
      const esc = t => String(t || '').replace(/[<>&"]/g, '');
      const rows = window.__imgcred.map(v => '<li><b>' + esc(v.n) + '</b><div dir="ltr" class="cred-en">' + esc(v.t) + '<br>' + esc(v.l) + (v.a ? ' · ' + esc(v.a) : '') + '<br><a href="' + esc(v.u) + '" target="_blank" rel="noopener">' + esc(v.u) + '</a></div></li>').join('');
      box.insertAdjacentHTML('beforeend', '<p class="rd-concl">صور الشخصيات، المصدر Wikimedia Commons:</p><ul class="cred-list">' + rows + '</ul>');
    }, 0);
    setTimeout(() => { const box = document.getElementById('creditsBox'); if (typeof ZGUIDE_ON !== 'undefined' && ZGUIDE_ON && box) box.insertAdjacentHTML('beforeend', '<p class="rd-concl">دليل سفر التكوين المصوّر:</p><ul class="cred-list"><li>رسومات تخيّلية بالذكاء الاصطناعي لتوضيح أحداث الأصحاحات، والشرح المكتوب من كتابة البرنامج. النص المقدّس في الأصحاح نفسه.</li></ul>'); }, 0);
    try {
      const lb = await packLoadJson('long-bios', 'content/packs/long-bios.json').catch(() => null);
      const SRC = { bio_anthony: 'سيرة القديس أنطونيوس: «حياة أنطونيوس» للبابا أثناسيوس، ترجمة إنجليزية لـ <bdi dir="ltr">H. Ellershaw</bdi> (سلسلة <bdi dir="ltr">Nicene and Post-Nicene Fathers</bdi>، نيويورك ١٨٩٢، ملكية عامة، عن موقع <bdi dir="ltr">CCEL</bdi>). النص العربي صياغة من كتابة التطبيق وهو سيرة غير كاملة (أجزاء من السيرة لم تُضمَّن). سنة ٢٥١م للميلاد من التقليد القبطي، ووفاته سنة ٣٥٦م من مقدمة محرر الطبعة.' };
      const hs = ((lb && lb.entries) || []).filter(e => e.ui_ready === true && SRC[e.id]).map(e => '<li>' + SRC[e.id] + '</li>').join('');
      if (hs) setTimeout(() => { const box = document.getElementById('creditsBox'); if (box) box.insertAdjacentHTML('beforeend', '<p class="rd-concl">المقروءات الطويلة:</p><ul class="cred-list">' + hs + '</ul>'); }, 0);
    } catch (e) {}
  } catch (e) {}
}

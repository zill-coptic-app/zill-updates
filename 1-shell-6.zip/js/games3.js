/* ألعاب إضافية: صح ولا غلط (بشرح من شرح الأصحاح)، متاهة الفلك، دوّر على الكلمات.
   كل المحتوى متأصل في شرح الأصحاح (js/notes/b1.js) — حقائق نصية فقط. */

/* ---------- صح ولا غلط ---------- */
/* كل سؤال مبني على حقيقة من شرح الأصحاح؛ العبارات الغلط متعمدة والتوضيح بيصححها. */
const ZTF_POOL = [
  { q: 'الله خلق الإنسان على صورته، ذكر وأنثى.', ok: true, why: 'الإنسان هو الوحيد اللي اتقال عنه «على صورة الله»، واتخلق ذكرًا وأنثى في اليوم السادس.', ref: 'تكوين ١: ٢٦-٢٧' },
  { q: 'الله سمّى النور «نهار» والظلمة «ليل».', ok: true, why: 'في اليوم الأول: فصل الله بين النور والظلمة، وسمّى النور نهارًا والظلمة ليلًا.', ref: 'تكوين ١: ٣-٥' },
  { q: 'الله خلق الإنسان في اليوم الرابع.', ok: false, why: 'اليوم الرابع كان للنورين والنجوم؛ الإنسان اتخلق في اليوم السادس.', ref: 'تكوين ١: ١٤-١٩،٢٤-٣١' },
  { q: 'آدم هو اللي سمّى امرأته حواء.', ok: true, why: 'آدم سمّى امرأته حواء لأنها أم كل حي.', ref: 'تكوين ٣: ٢٠' },
  { q: 'أول سؤال قاله الله لآدم بعد الأكل كان: «أين أنت؟».', ok: true, why: 'أول كلام الله مع آدم بعد الأكل كان سؤال: «أين أنت؟» ثم «من أعلمك أنك عريان؟».', ref: 'تكوين ٣: ٩-١١' },
  { q: 'آدم قال لله إنه أكل لوحده ومحصلش من حد حاجة.', ok: false, why: 'بالعكس: آدم قال إن المرأة أعطته، والمرأة قالت إن الحية غرّتها — كل واحد حيل على اللي بعده.', ref: 'تكوين ٣: ١٢-١٣' },
  { q: 'الله حكم على الحية إنها تمشي على رجليها.', ok: false, why: 'الحكم كان إن الحية تمشي على بطنها وتأكل ترابًا.', ref: 'تكوين ٣: ١٤' },
  { q: 'نوح كان عمره خمس مئة سنة لما صار الطوفان.', ok: false, why: 'نوح كان عمره ست مئة سنة لما صار طوفان المياه على الأرض.', ref: 'تكوين ٧: ٦' },
  { q: 'اللي دخل الفلك كان تمن أشخاص: نوح وامرأته وبنوه التلاتة ونساؤهم.', ok: true, why: 'دخل ثمانية أشخاص: نوح وامرأته وبنوه الثلاثة ونساؤهم الثلاث.', ref: 'تكوين ٧: ٧،١٣' },
  { q: 'الرب هو اللي أغلق باب الفلك على نوح.', ok: true, why: 'النص بيقول: «وأغلق الرب عليه».', ref: 'تكوين ٧: ١٦' },
  { q: 'المطر في الطوفان استمر أربعين يوم وأربعين ليلة.', ok: true, why: 'كان المطر على الأرض أربعين يومًا وأربعين ليلة، والمياه تعاظمت مئة وخمسين يومًا.', ref: 'تكوين ٧: ١٢،٢٤' },
  { q: 'الله قال لنوح ياخد من كل الحيوانات اتنين اتنين بس.', ok: false, why: 'من البهائم الطاهرة سبعة سبعة ذكرًا وأنثى، ومن غير الطاهرة اثنين.', ref: 'تكوين ٧: ٢' },
  { q: 'علامة ميثاق الله مع نوح هي القوس في السحاب.', ok: true, why: 'علامة الميثاق قوس الله في السحاب، وكلما ظهرت يذكر الله ميثاقه الأبدي.', ref: 'تكوين ٩: ١٢-١٧' },
  { q: 'نوح لعن ابنه حام.', ok: false, why: 'اللعنة في كلام نوح اتوجهت لكنعان بن حام، مش لحام نفسه.', ref: 'تكوين ٩: ٢٢،٢٥' },
  { q: 'حام هو أبو كنعان.', ok: true, why: 'بنو نوح اللي خرجوا من الفلك: سام وحام ويافث، وحام هو أبو كنعان.', ref: 'تكوين ٩: ١٨' },
  { q: 'الناس بنت البرج في شنعار علشان تصلي فيه لله.', ok: false, why: 'بنوا المدينة والبرج علشان يصنعوا لأنفسهم اسمًا وميتبددوش على وجه الأرض.', ref: 'تكوين ١١: ٤' },
  { q: 'المدينة والبرج اتبنوا في أرض شنعار، والمكان اتسمّى بابل.', ok: true, why: 'دُعي اسمها بابل لأن الرب هناك بلبل لسان كل الأرض.', ref: 'تكوين ١١: ٢،٩' },
  { q: 'ساراي امرأة أبرام كان عندها ولاد كتير.', ok: false, why: 'النص بيقول إن ساراي كانت عاقرًا ليس لها ولد.', ref: 'تكوين ١١: ٣٠' },
  { q: 'متوشالح أطول الأعمار في أصحاح مواليد آدم: عاش ٩٦٩ سنة.', ok: true, why: 'متوشالح عاش ٩٦٩ سنة ومات، وهو أطول الأعمار في الأصحاح.', ref: 'تكوين ٥: ٢٧' }
];
const ZG3 = { tf: null, maze: null, ws: null };

function zgTF(root, st) {
  st = st || { ok: 0, n: 0, used: [] };
  const avail = ZTF_POOL.map((x, i) => i).filter(i => !st.used.includes(i));
  const idx = avail.length ? avail[Math.floor(Math.random() * avail.length)] : (st.used = [], Math.floor(Math.random() * ZTF_POOL.length));
  st.used.push(idx);
  const item = ZTF_POOL[idx];
  ZG3.tf = { idx, answered: false };
  root.innerHTML = '<p class="advice-src">صح ولا غلط؟ وبعد ما تجاوب هتعرف ليه. النتيجة ' + toArabicDigits(st.ok) + ' من ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p>' + item.q + '</p></div>' +
    '<div class="zg-opts"><div class="game-btn" id="ztfT" role="button">صح</div><div class="game-btn" id="ztfF" role="button">غلط</div></div><div id="ztff"></div>';
  const answer = pick => {
    if (ZG3.tf.answered) return; ZG3.tf.answered = true; st.n++;
    const right = pick === item.ok; if (right) st.ok++;
    const bT = root.querySelector('#ztfT'), bF = root.querySelector('#ztfF');
    const correctBtn = item.ok ? bT : bF, otherBtn = item.ok ? bF : bT;
    correctBtn.classList.add('right');
    otherBtn.classList.add(right ? 'dim' : 'wrong');
    root.querySelector('#ztff').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الإجابة الصح: ' + (item.ok ? 'صح' : 'غلط') + '. ') + item.why + ' <bdi>(' + item.ref + ')</bdi></p>' +
      '<div class="game-actions"><span class="game-btn" id="ztfn" role="button">السؤال اللي بعده</span></div>';
    root.querySelector('#ztfn').onclick = () => zgTF(root, st);
  };
  root.querySelector('#ztfT').onclick = () => answer(true);
  root.querySelector('#ztfF').onclick = () => answer(false);
}

/* ---------- متاهة الفلك ---------- */
/* وصّل نوح للفلك. متاهة ٩×٩ بتتولّد كل مرة، حركة بالأسهم أو السحب. */
const MZ_N = 9;
function mzGenerate() {
  const N = MZ_N, cells = [];
  for (let y = 0; y < N; y++) { const row = []; for (let x = 0; x < N; x++) row.push({ v: false, w: [true, true, true, true] }); cells.push(row); }
  /* walls: 0 top, 1 right, 2 bottom, 3 left — recursive backtracker */
  const stack = [[0, 0]]; cells[0][0].v = true;
  const DIRS = [[0, -1, 0, 2], [1, 0, 1, 3], [0, 1, 2, 0], [-1, 0, 3, 1]];
  while (stack.length) {
    const [x, y] = stack[stack.length - 1];
    const opts = DIRS.filter(d => { const nx = x + d[0], ny = y + d[1]; return nx >= 0 && ny >= 0 && nx < N && ny < N && !cells[ny][nx].v; });
    if (!opts.length) { stack.pop(); continue; }
    const d = opts[Math.floor(Math.random() * opts.length)];
    const nx = x + d[0], ny = y + d[1];
    cells[y][x].w[d[2]] = false; cells[ny][nx].w[d[3]] = false;
    cells[ny][nx].v = true; stack.push([nx, ny]);
  }
  return cells;
}
function mzNew(root, st) {
  st = st || { won: 0, tries: 0 };
  const cells = mzGenerate();
  const mz = { cells, px: 0, py: 0, gx: MZ_N - 1, gy: MZ_N - 1, moves: 0, over: false };
  ZG3.maze = mz; st.tries++;
  root.innerHTML = '<p class="advice-src">وصّل نوح للفلك قبل الطوفان. اتحرك بالأسهم أو اسحب على المتاهة. المحاولات اللي كسبتها: ' + toArabicDigits(st.won) + '</p>' +
    '<canvas id="mzCv" width="320" height="320" style="width:100%;max-width:340px;display:block;margin:8px auto;touch-action:none"></canvas>' +
    '<div class="snake-pad" style="display:grid;grid-template-columns:repeat(3,64px);gap:6px;justify-content:center;direction:ltr">' +
    '<span></span><span class="game-btn" id="mzU" role="button">↑</span><span></span>' +
    '<span class="game-btn" id="mzL" role="button">←</span><span class="game-btn" id="mzD" role="button">↓</span><span class="game-btn" id="mzR" role="button">→</span></div>' +
    '<div id="mzf"></div>';
  const cv = root.querySelector('#mzCv');
  const draw = () => {
    const ctx = cv.getContext('2d'), s = cv.width / MZ_N, css = getComputedStyle(document.documentElement);
    const gold = css.getPropertyValue('--gold').trim() || '#e3b257';
    ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.strokeStyle = 'rgba(160,160,170,.75)'; ctx.lineWidth = 2;
    for (let y = 0; y < MZ_N; y++) for (let x = 0; x < MZ_N; x++) {
      const c = mz.cells[y][x], X = x * s, Y = y * s;
      ctx.beginPath();
      if (c.w[0]) { ctx.moveTo(X, Y); ctx.lineTo(X + s, Y); }
      if (c.w[1]) { ctx.moveTo(X + s, Y); ctx.lineTo(X + s, Y + s); }
      if (c.w[2]) { ctx.moveTo(X, Y + s); ctx.lineTo(X + s, Y + s); }
      if (c.w[3]) { ctx.moveTo(X, Y); ctx.lineTo(X, Y + s); }
      ctx.stroke();
    }
    /* goal: فلك — مركب بسيط */
    const gx = (mz.gx + .5) * s, gy = (mz.gy + .5) * s;
    ctx.fillStyle = '#8a5a2b';
    ctx.beginPath(); ctx.moveTo(gx - s * .32, gy + s * .05); ctx.lineTo(gx + s * .32, gy + s * .05); ctx.lineTo(gx + s * .2, gy + s * .28); ctx.lineTo(gx - s * .2, gy + s * .28); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#a97b4f'; ctx.fillRect(gx - s * .16, gy - s * .2, s * .32, s * .24);
    ctx.beginPath(); ctx.moveTo(gx - s * .2, gy - s * .2); ctx.lineTo(gx + s * .2, gy - s * .2); ctx.lineTo(gx, gy - s * .36); ctx.closePath(); ctx.fill();
    /* player: نوح */
    ctx.fillStyle = gold; ctx.beginPath(); ctx.arc((mz.px + .5) * s, (mz.py + .5) * s, s * .3, 0, 7); ctx.fill();
    ctx.fillStyle = '#1a1a2e'; ctx.font = 'bold ' + Math.round(s * .42) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('ن', (mz.px + .5) * s, (mz.py + .55) * s);
  };
  const move = (dx, dy) => {
    if (mz.over) return;
    const c = mz.cells[mz.py][mz.px];
    if (dx === 1 && c.w[1]) return; if (dx === -1 && c.w[3]) return;
    if (dy === 1 && c.w[2]) return; if (dy === -1 && c.w[0]) return;
    mz.px += dx; mz.py += dy; mz.moves++;
    if (mz.px === mz.gx && mz.py === mz.gy) {
      mz.over = true; st.won++;
      root.querySelector('#mzf').innerHTML = '<p class="advice-src">وصل نوح للفلك في ' + toArabicDigits(mz.moves) + ' حركة ✓ «وأغلق الرب عليه» (تكوين ٧: ١٦)</p><div class="game-actions"><span class="game-btn" id="mzn" role="button">متاهة جديدة</span></div>';
      root.querySelector('#mzn').onclick = () => mzNew(root, st);
    }
    draw();
  };
  root.querySelector('#mzU').onclick = () => move(0, -1);
  root.querySelector('#mzD').onclick = () => move(0, 1);
  root.querySelector('#mzL').onclick = () => move(-1, 0);
  root.querySelector('#mzR').onclick = () => move(1, 0);
  let tsx = 0, tsy = 0;
  cv.addEventListener('touchstart', e => { tsx = e.touches[0].clientX; tsy = e.touches[0].clientY; }, { passive: true });
  cv.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - tsx, dy = e.changedTouches[0].clientY - tsy;
    if (Math.abs(dx) < 20 && Math.abs(dy) < 20) return;
    if (Math.abs(dx) > Math.abs(dy)) move(dx > 0 ? 1 : -1, 0); else move(0, dy > 0 ? 1 : -1);
  }, { passive: true });
  draw();
}

/* ---------- دوّر على الكلمات ---------- */
/* كلمات من شرح التكوين: أسماء وأماكن. شبكة ٩×٩، اضغط أول حرف وآخر حرف. */
const ZWS_BANK = ['نوح', 'الفلك', 'آدم', 'حواء', 'قايين', 'هابيل', 'شيث', 'أخنوخ', 'سام', 'حام', 'يافث', 'كنعان', 'بابل', 'شنعار', 'أبرام', 'ساراي', 'لوط', 'تارح', 'حاران', 'أور'];
const ZWS_N = 9, ZWS_LETTERS = 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي';
function zwsNew(root, st) {
  st = st || { done: 0 };
  const N = ZWS_N;
  const words = zgShuffle(ZWS_BANK).filter(w => w.length <= N).slice(0, 7);
  const grid = []; for (let y = 0; y < N; y++) grid.push(new Array(N).fill(''));
  const placed = [];
  const DIRS = [[1, 0], [0, 1], [1, 1]]; /* x يمين-للشمال منطقيًا؛ بنخزن ونرسم LTR داخلي */
  for (const w of words) {
    let okSpot = null;
    for (let tries = 0; tries < 200 && !okSpot; tries++) {
      const d = DIRS[Math.floor(Math.random() * DIRS.length)];
      const xs = d[0] === 1 ? N - w.length : N - 1, xe = d[0] === -1 ? w.length - 1 : 0;
      const ys = d[1] === 1 ? N - w.length : N - 1;
      const x0 = Math.floor(Math.random() * (xs + 1)), y0 = Math.floor(Math.random() * (ys + 1));
      let fits = true;
      for (let i = 0; i < w.length; i++) {
        const x = x0 + d[0] * i, y = y0 + d[1] * i;
        if (x < 0 || x >= N || y < 0 || y >= N || (grid[y][x] && grid[y][x] !== w[i])) { fits = false; break; }
      }
      if (fits) okSpot = { x0, y0, d };
    }
    if (!okSpot) continue;
    for (let i = 0; i < w.length; i++) grid[okSpot.y0 + okSpot.d[1] * i][okSpot.x0 + okSpot.d[0] * i] = w[i];
    placed.push({ w, x0: okSpot.x0, y0: okSpot.y0, dx: okSpot.d[0], dy: okSpot.d[1] });
  }
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!grid[y][x]) grid[y][x] = ZWS_LETTERS[Math.floor(Math.random() * ZWS_LETTERS.length)];
  const ws = { grid, placed, found: [], first: null };
  ZG3.ws = ws;
  root.innerHTML = '<p class="advice-src">دوّر على الكلمات في الشبكة: اضغط أول حرف وبعدين آخر حرف في الكلمة. لاقيت <span id="zwsc">٠</span> من ' + toArabicDigits(placed.length) + '</p>' +
    '<div class="zws-grid" id="zwsg" dir="rtl"></div>' +
    '<div class="zws-list" id="zwsl">' + placed.map(p => '<span class="zws-w" data-w="' + p.w + '">' + p.w + '</span>').join('') + '</div><div id="zwsf"></div>';
  const g = root.querySelector('#zwsg');
  const cellAt = [];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const c = document.createElement('div'); c.className = 'zws-cell'; c.textContent = grid[y][x]; c.setAttribute('role', 'button');
    c.dataset.x = x; c.dataset.y = y;
    c.onclick = () => tap(+c.dataset.x, +c.dataset.y, c);
    g.appendChild(c); cellAt.push(c);
  }
  const cell = (x, y) => cellAt[y * N + x];
  function tap(x, y, el) {
    if (!ws.first) { ws.first = { x, y }; el.classList.add('sel'); return; }
    const a = ws.first; ws.first = null;
    root.querySelectorAll('.zws-cell.sel').forEach(e => e.classList.remove('sel'));
    const dx = Math.sign(x - a.x), dy = Math.sign(y - a.y);
    const len = Math.max(Math.abs(x - a.x), Math.abs(y - a.y)) + 1;
    if (!(dx === 0 || dy === 0 || Math.abs(x - a.x) === Math.abs(y - a.y)) || len < 2) return;
    let str = ''; const cellsLine = [];
    for (let i = 0; i < len; i++) { const cx = a.x + dx * i, cy = a.y + dy * i; str += grid[cy][cx]; cellsLine.push([cx, cy]); }
    const hit = ws.placed.find(p => !ws.found.includes(p.w) && (p.w === str || p.w === str.split('').reverse().join('')));
    if (hit) {
      ws.found.push(hit.w);
      cellsLine.forEach(([cx, cy]) => cell(cx, cy).classList.add('found'));
      const tag = root.querySelector('.zws-w[data-w="' + hit.w + '"]'); if (tag) tag.classList.add('found');
      root.querySelector('#zwsc').textContent = toArabicDigits(ws.found.length);
      if (ws.found.length === ws.placed.length) {
        st.done++;
        root.querySelector('#zwsf').innerHTML = '<p class="advice-src">لاقيتهم كلهم ✓</p><div class="game-actions"><span class="game-btn" id="zwsn" role="button">شبكة جديدة</span></div>';
        root.querySelector('#zwsn').onclick = () => zwsNew(root, st);
      }
    }
  }
}

/* ---------- اختلافات: مشهد الفلك (رسم SVG من أشكال بسيطة، مفيش صور خارجية) ---------- */
/* كل اختلاف: [id, x, y, نصف قطر اللمس، وصف]. اللعبة بتختار ٥ من ٦ كل مرة. */
const ZSD_DIFFS = [
  ['sun', 52, 40, 30, 'لون الشمس'],
  ['dove', 232, 52, 28, 'الحمامة'],
  ['win', 150, 138, 26, 'شبابيك الفلك'],
  ['bow', 228, 112, 30, 'لون قوس قزح'],
  ['cloud', 128, 36, 30, 'السحابة'],
  ['flag', 176, 92, 24, 'العلم على الفلك']
];
function zsdScene(off) {
  const has = (id) => !off.includes(id);
  const sun = has('sun') ? '#F2C14E' : '#E8833A';
  const bowC = has('bow') ? '#D9534F' : '#8E5BD1';
  let s = '<svg viewBox="0 0 300 200" xmlns="http://www.w3.org/2000/svg" style="width:100%;display:block;border-radius:14px">' +
    '<rect width="300" height="200" fill="#BFE3F6"/><rect y="150" width="300" height="50" fill="#4C8FBF"/>' +
    '<circle cx="52" cy="40" r="17" fill="' + sun + '"/>' +
    (has('cloud') ? '<g fill="#fff"><ellipse cx="128" cy="38" rx="22" ry="10"/><ellipse cx="144" cy="32" rx="14" ry="9"/><ellipse cx="112" cy="34" rx="12" ry="8"/></g>' : '') +
    '<path d="M180 150 A48 48 0 0 1 276 150" fill="none" stroke="' + bowC + '" stroke-width="7"/>' +
    '<path d="M188 150 A40 40 0 0 1 268 150" fill="none" stroke="#F2C14E" stroke-width="7"/>' +
    '<path d="M196 150 A32 32 0 0 1 260 150" fill="none" stroke="#6BBF59" stroke-width="7"/>' +
    '<path d="M70 132 L230 132 L212 168 L90 168 Z" fill="#8B5A2B"/>' +
    '<rect x="105" y="100" width="90" height="32" fill="#B9854B"/><path d="M98 100 L150 76 L202 100 Z" fill="#7A4B20"/>' +
    (has('flag') ? '<rect x="149" y="64" width="2" height="14" fill="#5a3a18"/><path d="M151 64 L168 69 L151 74 Z" fill="#D9534F"/>' : '<rect x="149" y="64" width="2" height="14" fill="#5a3a18"/>') +
    '<rect x="120" y="108" width="14" height="14" rx="2" fill="#FFE9A8"/>' +
    (has('win') ? '<rect x="143" y="108" width="14" height="14" rx="2" fill="#FFE9A8"/>' : '') +
    '<rect x="166" y="108" width="14" height="14" rx="2" fill="#FFE9A8"/>' +
    (has('dove') ? '<g fill="#fff" stroke="#999" stroke-width=".6"><ellipse cx="232" cy="52" rx="9" ry="5"/><path d="M226 50 Q232 38 240 48 Z"/><circle cx="240" cy="50" r="3"/></g><path d="M243 50 L249 51 L243 52 Z" fill="#E8A33D"/>' : '') +
    '</svg>';
  return s;
}
function zsdNew(root, st) {
  st = st || { done: 0 };
  const pick = zgShuffle(ZSD_DIFFS.slice()).slice(0, 5), off = pick.map(d => d[0]);
  const found = [];
  root.innerHTML = '<p class="advice-src">في ٥ اختلافات بين الصورتين. اضغط على مكان الاختلاف في الصورة اللي تحت. اللي لقيته: <b id="zsdc">٠</b> من ٥. الأدوار اللي خلصتها: ' + toArabicDigits(st.done) + '.</p>' +
    '<div id="zsdA" style="max-width:340px;margin:8px auto">' + zsdScene([]) + '</div>' +
    '<div id="zsdB" style="max-width:340px;margin:8px auto;position:relative;touch-action:manipulation">' + zsdScene(off) + '<svg id="zsdM" viewBox="0 0 300 200" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none"></svg></div>' +
    '<div id="zsdf"></div>';
  const mark = (d) => ['zsdM'].forEach(id => { root.querySelector('#' + id).insertAdjacentHTML('beforeend', '<circle cx="' + d[1] + '" cy="' + d[2] + '" r="' + (d[3] - 6) + '" fill="none" stroke="#2E9E4F" stroke-width="3"/>'); });
  root.querySelector('#zsdB').addEventListener('click', ev => {
    const box = root.querySelector('#zsdB').getBoundingClientRect();
    const x = (ev.clientX - box.left) / box.width * 300, y = (ev.clientY - box.top) / box.height * 200;
    const hit = pick.find(d => !found.includes(d[0]) && Math.hypot(x - d[1], y - d[2]) <= d[3]);
    if (!hit) { const f = root.querySelector('#zsdf'); f.innerHTML = '<p class="advice-src">مش هنا. جرّب تاني.</p>'; return; }
    found.push(hit[0]); mark(hit);
    root.querySelector('#zsdc').textContent = toArabicDigits(found.length);
    root.querySelector('#zsdf').innerHTML = '<p class="advice-src">صح ✓ ' + hit[4] + '</p>';
    if (found.length === pick.length) {
      st.done++;
      root.querySelector('#zsdf').innerHTML = '<p class="advice-src">لقيت الاختلافات كلها ✓</p><div class="game-actions"><span class="game-btn" id="zsdn" role="button">مشهد جديد</span></div>';
      root.querySelector('#zsdn').onclick = () => zsdNew(root, st);
    }
  });
}

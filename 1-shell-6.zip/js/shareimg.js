/* Verse copy / share text / share image card / save image. User-initiated only. Offline.
   Native (Capacitor plugins) when available, Web APIs otherwise. */
function zPlug(n) { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n]; }
function wrapLines(ctx, text, maxW) {
  const words = text.split(/\s+/), lines = []; let cur = '';
  words.forEach(w => { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
  if (cur) lines.push(cur); return lines;
}
function zRefIso(ref) { return ref.replace(/(\S+)$/, (m, t) => '\u2066' + t.replace(/\u200E/g, '').replace(/[^\u0660-\u0669]/g, '\u200E$&\u200E') + '\u2069'); }
function zFmtCopy(text, ref) { return '«' + text + '»\n— ' + zRefIso(ref); }
/* Story-size card 1080x1920, style A (dark glass). Text shrinks to fit; returns null when the passage is too long for a readable card.
   Layout: nothing in the top ~250px or bottom ~300px (story UI). A clear band at y 1300-1440 is kept empty so the user can place an Instagram link sticker. */
function zRR(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function zLogoImg() { return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = 'assets/img/logo_zill.png'; }); }
async function verseCanvas(text, ref) {
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 52px "Noto Naskh Arabic"'); await document.fonts.load('700 38px "Noto Sans Arabic"'); } } catch (e) {}
  const logo = await zLogoImg();
  const W = 1080, H = 1920, c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  const availH = 760, maxW = 820; let size = 68, lines = [], lh = 0, ok = false;
  for (; size >= 40; size -= 2) {
    ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif'; ctx.direction = 'rtl';
    lines = wrapLines(ctx, text, maxW); lh = Math.round(size * 1.9);
    if (lines.length * lh <= availH) { ok = true; break; }
  }
  if (!ok) return null;
  const g = ctx.createLinearGradient(0, 0, W * 0.6, H); g.addColorStop(0, '#101731'); g.addColorStop(0.55, '#1a1440'); g.addColorStop(1, '#2a1a52');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const r1 = ctx.createRadialGradient(W * 0.8, H * 0.18, 10, W * 0.8, H * 0.18, 650); r1.addColorStop(0, 'rgba(138,112,230,.30)'); r1.addColorStop(1, 'rgba(138,112,230,0)'); ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);
  const r2 = ctx.createRadialGradient(W * 0.15, H * 0.8, 10, W * 0.15, H * 0.8, 600); r2.addColorStop(0, 'rgba(227,178,87,.14)'); r2.addColorStop(1, 'rgba(227,178,87,0)'); ctx.fillStyle = r2; ctx.fillRect(0, 0, W, H);
  ctx.direction = 'rtl'; ctx.textAlign = 'center';
  const bh = lines.length * lh, cy = H * 0.46, ph = bh + 290, pw = 940, px = (W - pw) / 2, py = cy - ph / 2;
  ctx.save(); zRR(ctx, px, py, pw, ph, 56); ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.stroke(); ctx.restore();
  ctx.fillStyle = '#E3B257'; ctx.font = '700 64px "Noto Sans Arabic", sans-serif'; ctx.fillText('\u271D', W / 2, Math.min(365, py - 30));
  const top = cy - bh / 2 + size * 1.05;
  ctx.fillStyle = '#F4EFE2'; ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  lines.forEach((l, i) => ctx.fillText(l, W / 2, top + i * lh));
  const yr = top + (lines.length - 1) * lh + 120;
  ctx.fillStyle = '#E3B257'; ctx.fillRect(W / 2 - 55, yr - 70, 110, 3);
  ctx.font = '700 46px "Noto Sans Arabic", sans-serif'; ctx.fillText(zRefIso(ref), W / 2, yr + 10);
  const by = 1500;
  if (logo) { ctx.save(); ctx.globalAlpha = 0.95; zRR(ctx, W / 2 - 60, by - 60, 120, 120, 28); ctx.clip(); ctx.drawImage(logo, W / 2 - 60, by - 60, 120, 120); ctx.restore(); }
  ctx.fillStyle = '#A9A5C8'; ctx.font = '700 30px "Noto Sans Arabic", sans-serif'; ctx.fillText('ظِلّ', W / 2, by + 105);
  return c;
}
async function zCopy(text, ref) {
  const s = zFmtCopy(text, ref), CB = zPlug('Clipboard');
  try { if (CB && CB.write) { await CB.write({ string: s }); return 'copied'; } } catch (e) {}
  try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(s); return 'copied'; } } catch (e) {}
  try { const t = document.createElement('textarea'); t.value = s; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok ? 'copied' : 'failed'; } catch (e) { return 'failed'; }
}
async function zShareText(text, ref) {
  const s = zFmtCopy(text, ref), SH = zPlug('Share');
  try { if (SH && SH.share) { await SH.share({ text: s, dialogTitle: 'مشاركة آية' }); return 'shared'; } } catch (e) { return 'cancelled'; }
  try { if (navigator.share) { await navigator.share({ text: s }); return 'shared'; } } catch (e) { return 'cancelled'; }
  return await zCopy(text, ref) === 'copied' ? 'copied-fallback' : 'failed';
}
function zB64(c) { return c.toDataURL('image/png').split(',')[1]; }
async function zShareImage(text, ref) {
  const c = await verseCanvas(text, ref); if (!c) return 'toolong';
  const SH = zPlug('Share'), FS = zPlug('Filesystem');
  if (SH && FS) {
    try {
      const name = 'zill_share/verse-' + Date.now() + '.png';
      await FS.writeFile({ path: name, data: zB64(c), directory: 'CACHE', recursive: true });
      const u = await FS.getUri({ path: name, directory: 'CACHE' });
      await SH.share({ files: [u.uri], dialogTitle: 'مشاركة آية' }); return 'shared';
    } catch (e) { return /cancel/i.test(String(e && e.message || e)) ? 'cancelled' : 'failed'; }
  }
  const blob = await new Promise(r => c.toBlob(r, 'image/png')), file = new File([blob], 'verse.png', { type: 'image/png' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return 'shared'; } catch (e) { return 'cancelled'; } }
  return zDownload(blob);
}
function zDownload(blob) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'verse.png'; document.body.appendChild(a); a.click(); a.remove(); return 'downloaded'; }
async function zSaveImage(text, ref) {
  const c = await verseCanvas(text, ref); if (!c) return 'toolong';
  const FS = zPlug('Filesystem');
  if (FS) {
    try { await FS.writeFile({ path: 'Zill/verse-' + Date.now() + '.png', data: zB64(c), directory: 'DOCUMENTS', recursive: true }); return 'saved'; }
    catch (e) { return 'savefail'; }
  }
  return zDownload(await new Promise(r => c.toBlob(r, 'image/png')));
}

/* Whole-chapter image, landscape: title + every verse with its number, flowed RTL into N columns (right column first, text flows line by line, a verse may continue into the next column), app colours.
   Columns and font size are picked so the image is about 1.8:1 or wider; very long chapters get the smallest size and may end up taller. */
async function chapterCanvas(title, verses, opts) {
  opts = opts || {};
  try { if (document.fonts && document.fonts.load) { await document.fonts.load('400 30px "Noto Naskh Arabic"'); await document.fonts.load('700 44px "Noto Sans Arabic"'); } } catch (e) {}
  const logo = await zLogoImg();
  const W = 2400, PAD = 80, GAP = 50, headH = 190, footH = 130, MINR = 1.75;
  const m = document.createElement('canvas').getContext('2d'); m.direction = 'rtl';
  const layout = (cols, size) => {
    const colW = Math.floor((W - PAD * 2 - GAP * (cols - 1)) / cols), lh = Math.round(size * 1.9), lines = [];
    m.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
    verses.forEach(v => { if (v.extra) { wrapLines(m, v.t, colW).forEach(l => lines.push({ l, extra: true })); return; } const num = toArabicDigits(String(v.n)); wrapLines(m, num + ' ' + v.t, colW).forEach((l, i) => lines.push({ l, first: i === 0, num })); });
    const per = Math.ceil(lines.length / cols), H = headH + per * lh + footH;
    return { cols, size, colW, lh, lines, per, H };
  };
  let best = null;
  outer: for (let size = 42; size >= 22; size -= 2) for (let cols = 3; cols <= 8; cols++) { const L = layout(cols, size); if (W / L.H >= MINR) { best = L; break outer; } }
  if (!best) best = layout(8, 22);
  const { cols, size, colW, lh, lines, per, H } = best;
  const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, W * 0.7, H); g.addColorStop(0, '#101731'); g.addColorStop(0.55, '#1a1440'); g.addColorStop(1, '#2a1a52'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const r1 = ctx.createRadialGradient(W * 0.88, 60, 10, W * 0.88, 60, 800); r1.addColorStop(0, 'rgba(138,112,230,.26)'); r1.addColorStop(1, 'rgba(138,112,230,0)'); ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);
  ctx.direction = 'rtl'; ctx.textAlign = 'right';
  ctx.fillStyle = '#E3B257'; ctx.font = '700 58px "Noto Sans Arabic", sans-serif'; ctx.fillText(title, W - PAD, 100);
  ctx.fillRect(PAD, 130, W - PAD * 2, 3);
  ctx.font = '400 ' + size + 'px "Noto Naskh Arabic", serif';
  lines.forEach((ln, i) => {
    const col = Math.floor(i / per), row = i % per, x = W - PAD - col * (colW + GAP), y = headH + row * lh;
    if (ln.extra) { ctx.fillStyle = '#C9A55A'; ctx.fillText(ln.l, x, y); }
    else if (ln.first) { ctx.fillStyle = '#E3B257'; ctx.fillText(ln.num, x, y); const nw = ctx.measureText(ln.num + ' ').width; ctx.fillStyle = '#F4EFE2'; ctx.fillText(ln.l.slice(ln.num.length + 1), x - nw, y); }
    else { ctx.fillStyle = '#F4EFE2'; ctx.fillText(ln.l, x, y); }
  });
  ctx.textAlign = 'center'; ctx.fillStyle = '#A9A5C8'; ctx.font = '700 30px "Noto Sans Arabic", sans-serif';
  if (logo) { ctx.save(); zRR(ctx, W / 2 - 30, H - 108, 60, 60, 14); ctx.clip(); ctx.drawImage(logo, W / 2 - 30, H - 108, 60, 60); ctx.restore(); }
  ctx.fillText('ظِلّ', W / 2, H - 28);
  c.__layout = { cols, size, W, H };
  return c;
}

/* chapter data for sharing: verses in order plus source psalm title / subscriptions (unnumbered lines) */
function chapterShareVerses(book, chapter) {
  const vs = book.chapters[String(chapter)] || {}, ex = (BIBLE.extras && BIBLE.extras[String(book.id)] && BIBLE.extras[String(book.id)][String(chapter)]) || {}, out = [];
  if (ex.h) out.push({ extra: true, t: bibleExtraText(ex.h) });
  Object.keys(vs).map(Number).sort((a, b) => a - b).forEach(n => { out.push({ n, t: tashText(book.id, chapter, n, vs[String(n)]) }); (ex.f || []).filter(x => x[0] === n).forEach(x => out.push({ extra: true, t: bibleExtraText(x[1]) })); });
  return out;
}

async function zShareChapter(book, chapter) {
  const title = (book.id <= 39 ? 'سفر ' : book.id <= 43 ? 'إنجيل ' : '') + book.name + '، الأصحاح ' + toArabicDigits(chapter);
  const c = await chapterCanvas(title, chapterShareVerses(book, chapter));
  const SH = zPlug('Share'), FS = zPlug('Filesystem');
  if (SH && FS) {
    try {
      const name = 'zill_share/chapter-' + book.id + '-' + chapter + '-' + Date.now() + '.png';
      await FS.writeFile({ path: name, data: zB64(c), directory: 'CACHE', recursive: true });
      const u = await FS.getUri({ path: name, directory: 'CACHE' });
      await SH.share({ files: [u.uri], dialogTitle: 'مشاركة أصحاح' }); return 'shared';
    } catch (e) { return /cancel/i.test(String(e && e.message || e)) ? 'cancelled' : 'failed'; }
  }
  const blob = await new Promise(r => c.toBlob(r, 'image/png')), file = new File([blob], 'chapter.png', { type: 'image/png' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return 'shared'; } catch (e) { return 'cancelled'; } }
  return 'unavailable';
}

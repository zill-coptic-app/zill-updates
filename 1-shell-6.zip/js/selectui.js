/* Themed dropdown: replaces the native (gray) popup for select.agp-sel. The <select> stays the source of truth. */
(function () {
  let open = null;
  function close() { if (open) { open.remove(); open = null; document.removeEventListener('keydown', onKey, true); } }
  function onKey(e) { if (e.key === 'Escape') { e.preventDefault(); close(); } }
  function show(sel) {
    close();
    const wrap = document.createElement('div'); wrap.className = 'tsel-back'; wrap.setAttribute('role', 'presentation');
    const box = document.createElement('div'); box.className = 'tsel-box'; box.setAttribute('role', 'listbox'); box.setAttribute('aria-label', sel.getAttribute('aria-label') || '');
    const hd = document.createElement('div'); hd.className = 'tsel-hd'; const cb = document.createElement('button'); cb.type = 'button'; cb.className = 'tsel-x'; cb.textContent = 'إغلاق'; cb.addEventListener('click', close); hd.appendChild(cb); 
    const list = document.createElement('div'); list.className = 'tsel-list';
    [...sel.options].forEach((o, i) => {
      const it = document.createElement('div'); it.className = 'tsel-opt' + (sel.selectedIndex === i ? ' on' : ''); it.setAttribute('role', 'option'); it.setAttribute('aria-selected', sel.selectedIndex === i ? 'true' : 'false'); it.tabIndex = 0;
      it.textContent = o.textContent;
      const pick = () => { sel.selectedIndex = i; close(); sel.dispatchEvent(new Event('change', { bubbles: true })); try { sel.focus(); } catch (e) {} };
      it.addEventListener('click', pick); it.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
      list.appendChild(it);
    });
    box.appendChild(hd); box.appendChild(list);
    wrap.appendChild(box); wrap.addEventListener('click', e => { if (e.target === wrap) close(); });
    document.body.appendChild(wrap); open = wrap; document.addEventListener('keydown', onKey, true);
    const on = box.querySelector('.on'); if (on) list.scrollTop = Math.max(0, on.offsetTop - list.clientHeight / 2 + on.offsetHeight / 2); if (on) on.focus({ preventScroll: true });
  }
  ['pointerdown', 'mousedown'].forEach(t => document.addEventListener(t, e => { if (e.target.closest && e.target.closest('select.agp-sel')) e.preventDefault(); }, { capture: true, passive: false }));
  document.addEventListener('click', e => { let s = e.target.closest && e.target.closest('select.agp-sel'); if (!s) { for (const c of document.querySelectorAll('select.agp-sel')) { const r = c.getBoundingClientRect(); if (r.width && e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) { s = c; break; } } } if (s) { e.preventDefault(); show(s); } }, true);
  document.addEventListener('keydown', e => { const s = e.target.closest && e.target.closest('select.agp-sel'); if (s && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown')) { e.preventDefault(); show(s); } }, true);
})();

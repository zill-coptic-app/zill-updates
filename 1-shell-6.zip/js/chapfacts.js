/* Chapter notes loader. Notes live in js/notes/b<bookId>.js, loaded on demand. */
const ZNOTE_BOOKS = [1];
function zLoadNotes(book) {
  return new Promise(res => {
    if ((window.ZNOTES && ZNOTES[book]) || ZNOTE_BOOKS.indexOf(book) < 0) return res();
    const s = document.createElement('script'); s.src = 'js/notes/b' + book + '.js'; s.onload = () => res(); s.onerror = () => res(); document.head.appendChild(s);
  });
}
function chapFactsHTML(book, ch) {
  const f = window.ZNOTES && ZNOTES[book] && ZNOTES[book][ch]; if (!f) return '';
  const refs = v => ' <span class="cf-v" dir="rtl">' + String(v).split(/([،,-])/).map(x => /^[،,-]$/.test(x) ? (x === '-' ? ' \u2013 ' : '\u060C ') : '<bdi>' + toArabicDigits(x) + '</bdi>').join('') + '</span>';
  const li = a => a.map(x => '<li>' + (x.h ? '<b>' + x.h + ':</b> ' : '') + x.t + refs(x.v) + '</li>').join('');
  const sec = (title, a) => a && a.length ? '<h4>' + title + '</h4><ul>' + li(a) + '</ul>' : '';
  return '<details class="chfacts"><summary>شرح الأصحاح</summary>' + sec('الفكرة', f.gist) + sec('الأحداث بالترتيب', f.events) + sec('ملاحظات من النص', f.meaning) + sec('أدوار إلهية', f.roles) + sec('الأشخاص', f.people) + sec('الأماكن', f.places) + sec('العلاقات', f.relations) + '</details>';
}

/* Coptic calendar: Gregorian -> Coptic date (Alexandrian calendar).
   Rule: 1 Thout of Coptic year Y falls on Sep 11 of Gregorian year Y-283,
   shifted to Sep 12 when Y % 4 === 0 (year after a Coptic leap year).
   Verified anchor: 2026-11-26 = 17 Hathor 1743. */
const COPTIC_MONTHS = ['توت','بابه','هاتور','كيهك','طوبه','أمشير','برمهات','برمودة','بشنس','بؤونه','أبيب','مسرى','النسيء'];

function copticNewYearGregorian(copticYear) {
  const gy = copticYear + 283;
  const day = (copticYear % 4 === 0) ? 12 : 11;
  return new Date(gy, 8, day); // Sep is month index 8
}

function toCoptic(date) {
  let year = date.getFullYear() - 284;
  let ny = copticNewYearGregorian(year);
  if (new Date(date.getFullYear(), date.getMonth(), date.getDate()) >= copticNewYearGregorian(year + 1)) { year += 1; ny = copticNewYearGregorian(year); }
  else if (new Date(date.getFullYear(), date.getMonth(), date.getDate()) < ny) { year -= 1; ny = copticNewYearGregorian(year); }
  const U = d => Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()); /* calendar-day arithmetic: immune to DST/time of day */
  const dayOfYear = Math.round((U(date) - U(ny)) / 86400000) + 1;
  const month = Math.min(13, Math.ceil(dayOfYear / 30));
  const day = dayOfYear - (month - 1) * 30;
  return { year, month, day, monthName: COPTIC_MONTHS[month - 1] };
}

const AR_DIGITS = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
function toArabicDigits(n) {
  return String(n).replace(/[0-9]/g, d => AR_DIGITS[+d]);
}

const GREG_MONTHS_AR = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const WEEKDAYS_AR = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

function formatGregorianAr(date) {
  return WEEKDAYS_AR[date.getDay()] + ' ' + toArabicDigits(date.getDate()) + ' ' + GREG_MONTHS_AR[date.getMonth()];
}

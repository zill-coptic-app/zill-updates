/* «افهم الكتاب» pilot. Every entry is the app's own wording, written after reading the named sources.
   No commentary text is copied; no Father is quoted. Entries exist only for the passages below.
   Fields: b = book id, c = chapter, f..t = verse range. */
const ZEXPL = [
  { b: 43, c: 3, f: 16, t: 17,
    meaning: 'الآيتان تقولان إن سبب مجيء المسيح هو محبة الله للعالم كله، وإن الهدف هو الخلاص والحياة، مش الحكم على الناس. الإيمان بالمسيح هو الباب اللي بيدخّل الإنسان في الحياة الأبدية. في تفسير القمص أنطونيوس فكري: الخلاص هدية مجانية من محبة الله، ولا يتوقف على استحقاق الإنسان.',
    context: 'الكلام جزء من حوار المسيح مع نيقوديموس، معلّم من معلّمي اليهود، جاءه ليلًا. في نفس الحوار اتكلّم المسيح عن الميلاد الجديد من الماء والروح، وعن رفعه على الصليب زي ما رفع موسى الحية النحاسية في البرية (سفر العدد ٢١).',
    words: [['بذل', 'أعطى وقدّم'], ['الوحيد', 'ابن الله الوحيد، كما في النص'], ['يهلك', 'يضيع ويفنى'], ['يدين', 'يحكم بالعقوبة']],
    reflection: 'من الآية نفسها: الله هو اللي بدأ بالمحبة، والعطاء كان قبل أي استحقاق. السؤال اللي تسيبه الآية لكل واحد: إزاي ترد على المحبة دي؟',
    sources: ['القمص أنطونيوس فكري، تفسير يوحنا ٣، منشور في الموسوعة الكنسية على st-takla.org/bible/commentary/ar/nt/church-encyclopedia/john/chapter-03.html', 'القمص تادرس يعقوب ملطي، تفسير يوحنا ٣، st-takla.org (الفهرس: pub_Bible-Interpretations/Holy-Bible-Tafsir-02-New-Testament/Father-Tadros-Yacoub-Malaty)'] },
  { b: 19, c: 23, f: 1, t: 4,
    meaning: 'داود يشبّه الله براعٍ يعتني بكل احتياج قطيعه: يطعمه ويريحه ويقوده، وحتى في أصعب الأوقات يكون معه. في تفسير القمص تادرس يعقوب ملطي يُقرأ المزمور أيضًا في ضوء المسيح الراعي الصالح، وهذه قراءة المفسّر وليست نص المزمور.',
    context: 'المزمور منسوب لداود، وحسب التفسير المذكور هو من أوائل مزاميره أيام كان راعيًا. في الشرق كانوا يلقّبون الملك الصالح بالراعي. وفي الكنيسة المزمور موجود في صلاة الساعة الثالثة من الأجبية، وحسب نفس التفسير كان المعمَّدون الجدد يرددونه.',
    words: [['لا يعوزني', 'لا ينقصني'], ['يربضني', 'يُجلسني ويريّحني'], ['يوردني', 'يأتي بي إلى مياه أشرب منها'], ['مياه الراحة', 'مياه هادئة، والغنم تشرب منها براحة'], ['ظل الموت', 'ضيقة شديدة تكاد توصّل للموت، مش الموت نفسه']],
    reflection: 'الآية الرابعة ما بتقولش إن الوادي المظلم مش هيتعدّي، بتقول «أنت معي». المعية هي سبب الطمأنينة.',
    sources: ['القمص تادرس يعقوب ملطي وكذلك الموسوعة الكنسية، تفسير المزمور ٢٣، st-takla.org/bible/commentary/ar/ot/church-encyclopedia/psalms/chapter-023.html', 'القمص أنطونيوس فكري، المزمور ٢٣، st-takla.org (Father-Antonious-Fekry/21-Sefr-El-Mazameer)'] },
  { b: 43, c: 1, f: 1, t: 4,
    meaning: 'يوحنا يبدأ إنجيله بإعلان إن «الكلمة» كان موجودًا من الأزل، وإنه عند الله، وإنه الله. وكل الأشياء به كانت، وفيه الحياة. في تفسير القمص أنطونيوس فكري: المقصود بالكلمة هو الأقنوم الثاني، لأن الكلمة تعبّر عن العقل وتصدر منه.',
    context: 'بينما ركّز متى ولوقا على ميلاد المسيح في الزمان، ركّز يوحنا على ميلاده الأزلي، وكان همّه الأول إثبات لاهوت المسيح.',
    words: [['الكلمة', 'لقب للمسيح، العقل والتعبير الإلهي'], ['في البدء', 'قبل أي بداية للخليقة']],
    reflection: 'لو كانت كل الأشياء به كانت، يبقى الحياة نفسها ليها مصدر واحد. التأمل هنا: الحياة اللي بنعيشها هدية، مش حاجة بديهية.',
    sources: ['القمص أنطونيوس فكري، تفسير يوحنا ١ (ع١-٥)، st-takla.org/bible/commentary/ar/nt/church-encyclopedia/john/chapter-01.html'] }
];
const ZEXPL_NOTE = 'الشرح هنا من إعداد التطبيق بعد قراءة المصادر المذكورة، وليس نصًّا منقولًا منها. هو عرض لما ذكره المفسّرون المسمَّون، وليس بيانًا كنسيًّا رسميًّا، وقد يحتاج مراجعة كنسية.';
function zExplFind(bookId, chapter, verses) {
  return ZEXPL.filter(e => e.b === bookId && e.c === chapter && verses.some(v => v >= e.f && v <= e.t));
}
function zExplRender(entries, ref) {
  const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x !== undefined) e.textContent = x; return e; };
  const box = document.createElement('div');
  box.appendChild(el('h3', 'ex-h', 'افهم الآية'));
  box.appendChild(el('div', 'ex-ref', ref));
  if (!entries.length) {
    box.appendChild(el('p', 'ex-empty', 'لا يوجد شرح لهذه الآية بعد. النسخ والمشاركة متاحان كالمعتاد.'));
    return box;
  }
  entries.forEach(e => {
    const s = el('section', 'ex-sec');
    s.appendChild(el('div', 'ex-rng', 'الآيات ' + toArabicDigits(e.f) + (e.t > e.f ? '-' + toArabicDigits(e.t) : '')));
    [['المعنى', e.meaning], ['السياق', e.context]].forEach(([h, t]) => { s.appendChild(el('h4', '', h)); s.appendChild(el('p', '', t)); });
    s.appendChild(el('h4', '', 'معاني كلمات'));
    const dl = el('dl'); e.words.forEach(([w, m]) => { dl.appendChild(el('dt', '', w)); dl.appendChild(el('dd', '', m)); }); s.appendChild(dl);
    s.appendChild(el('h4', '', 'تأمل'));
    s.appendChild(el('p', 'ex-refl', e.reflection));
    s.appendChild(el('div', 'ex-lbl', 'التأمل من إعداد التطبيق وليس من المفسّرين.'));
    s.appendChild(el('h4', '', 'المصادر'));
    e.sources.forEach(x => s.appendChild(el('p', 'ex-src', x)));
    box.appendChild(s);
  });
  box.appendChild(el('div', 'ex-lbl', ZEXPL_NOTE));
  return box;
}

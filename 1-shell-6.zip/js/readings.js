/* Offline katameros reader: baked per-Coptic-month reading packs + Arabic
   synaxarium (source: katameros-api, MIT). No network needed at runtime. */
const READINGS = { months: {}, synax: null, synaxFailed: false };

/* Katameros/Synaxarium day turns over at 17:00 (user, 18:05): from 5 pm the app shows the next liturgical day (the eve). */
const KAT_ROLL_HOUR = 17;
function katDate(now) { const d = new Date(now || Date.now()); if (d.getHours() >= KAT_ROLL_HOUR) d.setDate(d.getDate() + 1); return d; }

function pad2(n) { return String(n).padStart(2, '0'); }

async function loadMonthPack(year, month) {
  const key = year + '-' + pad2(month);
  if (READINGS.months[key]) return READINGS.months[key];
  try {
    const pack = await packLoadJson('readings-' + key, 'content/readings/month-' + key + '.json');
    READINGS.months[key] = pack;
    return pack;
  } catch (e) { return null; }
}

/* -> { coptic, day } where day = { gregorian, title, sections[] } | null */
async function readingsForDate(date) {
  const c = toCoptic(date);
  const pack = await loadMonthPack(c.year, c.month);
  const day = pack && pack.days ? (pack.days[String(c.day)] || null) : null;
  return { coptic: c, day };
}

async function synaxEntries(cm, cd) {
  if (!READINGS.synax && !READINGS.synaxFailed) {
    try {
      READINGS.synax = await packLoadJson('synax-ar', 'content/packs/synax-ar.json');
      if (!READINGS.synax) READINGS.synaxFailed = true;
    } catch (e) { READINGS.synaxFailed = true; }
  }
  const days = (READINGS.synax && READINGS.synax.days) || {};
  return { entries: days[cm + '-' + cd] || [] };
}

/* -> { coptic, entries: [{title, text(html)}] } */
async function synaxForDate(date) {
  const c = toCoptic(date);
  const { entries } = await synaxEntries(c.month, c.day);
  return { coptic: c, entries };
}

/* Numeric refs (chapter:verse-range) get LTR isolation so RTL layout can't scramble them. */
function numRef(s) { // LRM around every separator so digit groups keep left-to-right order (Arabic digits + a dash otherwise reorder)
  const M = '\u200E', t = packText(toArabicDigits(s).replace(/\u200E/g, '').replace(/,/g, '،').replace(/-/g, '–'));
  return '<bdi dir="ltr" class="n">' + '\u2066' + t.replace(/([^٠-٩\s])/g, M + '$1' + M).replace(/\s+/g, ' ') + '\u2069' + '</bdi>'; }

/* Home rows: one per sub-reading that actually carries passages.
   -> [{ tag, label, secIdx, subIdx }] */
function readingRowsForDay(day) {
  const rows = [];
  if (!day || !day.sections) return rows;
  day.sections.forEach((sec, si) => {
    (sec.subs || []).forEach((sub, ui) => {
      const refs = [];
      (sub.readings || []).forEach(r => (r.passages || []).forEach(p => refs.push(toArabicDigits(packText(p.book)) + ' ' + numRef(p.ref))));
      if (!refs.length) return; // e.g. synax sub inside liturgy: shown via the synax section instead
      rows.push({ tag: sec.title, label: sub.title + ': ' + refs.join(' ، '), secIdx: si, subIdx: ui });
    });
  });
  return rows;
}

function passageHTML(p) {
  let h = '<p class="rd-ref-line">' + packText(p.book) + ' ' + numRef(p.ref) + '</p>';
  (p.verses || []).forEach(v => {
    h += '<p class="verse"><span class="vnum">' + toArabicDigits(v.n) + '</span>' + packText(v.t) + '</p>';
  });
  return h;
}

function subHTML(sub) {
  const labelled = (sub.readings || []).length > 1 && (sub.readings || []).every(r => (r.passages || []).length);
  let h = labelled ? '' : '<h3 class="rd-sub-title">' + packText(sub.title) + '</h3>';
  (sub.readings || []).forEach(r => {
    if (r.intro) h += '<p class="rd-intro">' + packText(r.intro) + '</p>';
    const b0 = (r.passages || [])[0] && r.passages[0].book, many = (sub.readings || []).length > 1;
    if (many && b0) h += '<h4 class="rd-part">' + (b0 === 'مزامير' ? 'المزمور' : (['متى', 'مرقس', 'لوقا', 'يوحنا'].includes(b0) ? 'الإنجيل' : packText(b0))) + '</h4>';
    (r.passages || []).forEach(p => { h += passageHTML(p); });
    if (r.concl) h += '<p class="rd-concl">' + packText(r.concl) + '</p>';
  });
  return h;
}

/* Full day or one sub-reading as read-screen body HTML. */
function dayReadingsHTML(day, onlySec, onlySub) {
  if (!day) return '';
  let h = '';
  day.sections.forEach((sec, si) => {
    if (onlySec !== undefined && si !== onlySec) return;
    const subs = (sec.subs || []).filter((sub, ui) =>
      (onlySub === undefined || ui === onlySub) &&
      (sub.readings || []).some(r => (r.passages || []).length));
    if (!subs.length) return;
    h += '<h2 class="rd-sec-title">' + packText(sec.title) + '</h2>';
    subs.forEach(sub => { h += subHTML(sub); });
  });
  return h;
}


/* Full day split into its parts (عشية / باكر / قداس) so the three never run together. */
function daySectionsList(day) {
  const out = [];
  (day && day.sections || []).forEach((sec, si) => {
    if ((sec.subs || []).some(sub => (sub.readings || []).some(r => (r.passages || []).length))) out.push({ si, title: sec.title });
  });
  return out;
}

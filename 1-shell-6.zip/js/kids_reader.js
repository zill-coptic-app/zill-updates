/* Story player (children section). Continuous story: one tap plays the whole
   story; narration chains across beats on a single blessed Audio element and
   text/images auto-advance with it. Beats without audio auto-advance on a
   reading timer. The user never sees chapters. Questions are optional and
   only offered after the story ends.
   Story text is an app-written Egyptian retelling of the Bible text; verse
   refs shown per beat. No rewards/stars here (rewards live only in games). */
(function () {
  let ov = null, S = null, flat = [], qs = [], idx = 0, qi = 0, mode = 'story';
  let AU = null, timer = null, playing = false, started = false;
  const AD = s => (typeof toArabicDigits === 'function' ? toArabicDigits(s) : String(s));
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  /* src values land raw inside innerHTML attributes: only relative pack
     paths and blob: object URLs are allowed; anything else renders as no
     image/audio rather than as markup. */
  const safeSrc = s => { const v = String(s || ''); return (v.startsWith('blob:') || /^[A-Za-z0-9_\-./]+$/.test(v)) ? v : ''; };
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function ensure() { if (ov) return; ov = document.createElement('div'); ov.className = 'kr-ov'; ov.hidden = true; document.body.appendChild(ov); }
  function stopTimer() { if (timer) { clearTimeout(timer); timer = null; } }
  function halt() { stopTimer(); if (AU) { try { AU.pause(); } catch (e) {} AU.onended = null; AU.onerror = null; AU.onplay = null; AU.onpause = null; AU.src = ''; } playing = false; }
  function readMs(t) { return Math.min(12000, 3500 + String(t || '').length * 45); }
  function setBtn(t) { const b = document.getElementById('krPlay'); if (b) b.textContent = t; }
  function beatAud(b) { return ''; } /* lean test build: narration omitted */

  function advance() {
    if (idx < flat.length - 1) playFrom(idx + 1);
    else finishStory();
  }
  function scheduleAdvance() { stopTimer(); timer = setTimeout(() => { timer = null; if (playing) advance(); }, readMs(flat[idx] && flat[idx].t)); }

  function playFrom(i) {
    stopTimer();
    idx = i;
    started = true;
    renderBeat();
    const src = beatAud(flat[idx]);
    playing = true;
    if (src) {
      if (!AU) AU = new Audio();
      AU.onended = () => { if (playing) advance(); };
      AU.onerror = () => { playing = false; stopTimer(); setBtn('▶ كمّل'); const n = document.getElementById('krNoAud'); if (n) n.hidden = false; };
      AU.onplay = () => { playing = true; setBtn('❚❚ وقّف'); };
      AU.onpause = () => { if (AU && !AU.ended) { playing = false; stopTimer(); setBtn('▶ كمّل'); } };
      AU.src = src;
      const p = AU.play();
      if (p && p.catch) p.catch(() => { playing = false; setBtn('▶ اسمع'); });
      setBtn('❚❚ وقّف');
    } else {
      /* No narration file for this beat (audio incomplete): do NOT fake the
         narration with a silent timer. Pause the chain with a clear state;
         the user consciously continues reading past it. */
      playing = false;
      setBtn('▶ كمّل');
    }
  }
  function pauseChain() {
    stopTimer();
    if (AU && !AU.paused) { try { AU.pause(); } catch (e) {} }
    playing = false;
    setBtn('▶ كمّل');
  }
  function resumeChain() {
    const src = beatAud(flat[idx]);
    playing = true;
    if (AU && src && AU.src && !AU.ended) {
      const p = AU.play();
      if (p && p.catch) p.catch(() => { playing = false; setBtn('▶ اسمع'); });
      setBtn('❚❚ وقّف');
    } else if (!src) { playing = true; scheduleAdvance(); setBtn('❚❚ وقّف'); }
    else playFrom(idx);
  }
  function finishStory() {
    halt();
    mode = 'end';
    renderEnd(false);
  }

  function renderBeat() {
    const b = flat[idx];
    let h = '<div class="kr-top"><button class="kr-x" id="krX" aria-label="رجوع">‹</button><div class="kr-t"><b>' + esc(S.title) + '</b><span>' + AD(idx + 1) + ' من ' + AD(flat.length) + '</span></div></div><div class="kr-body">';
    h += '<div class="kr-bar"><div class="kr-bar-in" style="width:' + Math.round(((idx + 1) / flat.length) * 100) + '%"></div></div>';
    h += (b.img && safeSrc(b._img || b.img) ? '<img class="kr-img" src="' + safeSrc(b._img || b.img) + '" alt="">' : '');
    h += '<p class="kr-text">' + esc(b.t) + '</p><p class="kr-ref">' + esc(b.ref) + '</p>';
    if (!beatAud(b)) h += '<p class="kr-note" id="krNoAud">نسخة التجربة دي من غير صوت القصة - اضغط «كمّل» تكمل قراءة.</p>';
    h += '<div class="kr-nav">' + (idx > 0 ? '<button class="game-btn" id="krPrev">السابق</button>' : '') +
      '<button class="game-btn" id="krPlay">' + (playing ? '❚❚ وقّف' : (started ? '▶ كمّل' : '▶ اسمع الحكاية')) + '</button>' +
      (idx < flat.length - 1 ? '<button class="game-btn" id="krNext">التالي</button>' : '') + '</div>';
    ov.innerHTML = h + '</div>';
    wireBeat();
  }
  function wireBeat() {
    const g = id => document.getElementById(id);
    g('krX').onclick = close;
    g('krPlay').onclick = () => { if (playing) pauseChain(); else resumeChain(); };
    if (g('krPrev')) g('krPrev').onclick = () => { pauseChain(); idx--; renderBeat(); };
    if (g('krNext')) g('krNext').onclick = () => { if (idx < flat.length - 1) { pauseChain(); idx++; renderBeat(); } else finishStory(); };
  }

  function renderEnd(afterQs) {
    let h = '<div class="kr-top"><button class="kr-x" id="krX" aria-label="رجوع">‹</button><div class="kr-t"><b>' + esc(S.title) + '</b><span></span></div></div><div class="kr-body">';
    h += '<p class="kr-text">' + (afterQs ? 'خلصت الأسئلة. أحسنت!' : 'خلصت الحكاية.') + '</p>';
    if (!afterQs && qs.length) h += '<p class="kr-note">تحب تجاوب على أسئلة عن الحكاية؟</p>';
    h += '<div class="kr-nav">' + (!afterQs && qs.length ? '<button class="game-btn" id="krQs">الأسئلة</button>' : '') +
      '<button class="game-btn" id="krAgain">نسمعها من الأول</button>' +
      '<button class="game-btn" id="krClose">إغلاق</button></div>';
    ov.innerHTML = h + '</div>';
    const g = id => document.getElementById(id);
    g('krX').onclick = close;
    g('krClose').onclick = close;
    g('krAgain').onclick = () => { mode = 'story'; playFrom(0); };
    if (g('krQs')) g('krQs').onclick = () => { mode = 'q'; qi = 0; qs.forEach(q => delete q._o); renderQ(); };
  }

  function renderQ() {
    const q = qs[qi];
    let h = '<div class="kr-top"><button class="kr-x" id="krX" aria-label="رجوع">‹</button><div class="kr-t"><b>أسئلة الحكاية</b><span>' + AD(qi + 1) + ' من ' + AD(qs.length) + '</span></div></div><div class="kr-body">';
    h += '<p class="kr-q">' + esc(q.q) + '</p>';
    if (q.open) {
      h += '<p class="kr-note">سؤال للتفكير، مفيش إجابة غلط.</p><div class="kr-nav"><button class="game-btn" id="krQNext">كمّل</button></div>';
    } else {
      if (!q._o) q._o = shuffle(q.o.map((t, i) => ({ t: (t && t.t !== undefined ? t.t : t), img: t && safeSrc(t._img || t.img), ok: i === q.ok })));
      h += '<div class="kr-opts">' + q._o.map((o, i) => '<button class="kr-opt" data-o="' + i + '">' + (o.img ? '<img src="' + o.img + '" alt="">' : '') + '<span>' + esc(o.t) + '</span></button>').join('') + '</div><div id="krFb" class="kr-fb" role="status"></div>';
    }
    h += '<div class="kr-nav"><button class="game-btn" id="krSkipQ">كمّل من غير أسئلة</button></div>';
    ov.innerHTML = h + '</div>';
    const g = id => document.getElementById(id);
    g('krX').onclick = close;
    g('krSkipQ').onclick = () => renderEnd(true);
    if (g('krQNext')) g('krQNext').onclick = nextQ;
    document.querySelectorAll('.kr-opt').forEach(el => el.onclick = () => {
      const q2 = qs[qi], o = q2._o[+el.dataset.o], fb = g('krFb');
      if (o.ok) { el.classList.add('ok'); fb.innerHTML = 'إجابة صحيحة. <button class="game-btn" id="krQNext2">كمّل</button>'; g('krQNext2').onclick = nextQ; document.querySelectorAll('.kr-opt').forEach(x => x.disabled = true); }
      else { el.classList.add('no'); el.disabled = true; fb.innerHTML = 'مفيش مشكلة. <button class="game-btn" id="krAgain2">نسمع الحكاية تاني</button> <button class="game-btn" id="krRetry">أجرّب تاني</button>'; g('krAgain2').onclick = () => { mode = 'story'; playFrom(0); }; g('krRetry').onclick = () => { fb.textContent = ''; el.classList.remove('no'); el.disabled = false; }; }
    });
  }
  function nextQ() { if (qi < qs.length - 1) { qi++; renderQ(); } else renderEnd(true); }

  /* Media overrides: a verified updated blob (IndexedDB) wins over the
     bundled file for every story image/audio. Resolved once per open. */
  async function kidsResolveMedia(story) {
    const jobs = [];
    const fix = (o, key) => { if (o && o[key]) jobs.push(packMediaUrl(o[key], o[key]).then((u) => { o['_' + key] = u; })); };
    for (const ch of story.chapters || []) {
      for (const b of ch.beats || []) { fix(b, 'img'); fix(b, 'aud'); }
      for (const q of ch.qs || []) { fix(q, 'img'); for (const o of q.o || []) fix(o, 'img'); }
    }
    await Promise.all(jobs);
  }
  function close() { halt(); mode = 'story'; started = false; if (ov) ov.hidden = true; document.body.classList.remove('kr-lock'); }
  window.zKidsClose = function () { if (ov && !ov.hidden) { close(); return true; } return false; };
  window.zKidsOpen = async function (id) {
    ensure();
    S = await packLoadJson('story-' + id, 'content/stories/' + id + '.json');
    /* Flatten chapters into one continuous sequence; chapter structure is
       internal segmentation only and is never shown. */
    flat = []; qs = [];
    for (const ch of S.chapters || []) { for (const b of ch.beats || []) flat.push(b); for (const q of ch.qs || []) qs.push(q); }
    idx = 0; qi = 0; mode = 'story'; playing = false;
    ov.hidden = false; document.body.classList.add('kr-lock');
    await kidsResolveMedia(S);
    renderBeat();
  };
})();

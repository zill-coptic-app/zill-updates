/* Content loader — offline-first. Ships with a bundled seed pack; newer
   verified packs (applied by updater.js) override it from localStorage. */
const CONTENT = { pack: null };

async function contentLoad() {
  // packLoadJson: applied update (IndexedDB) -> legacy localStorage slot -> bundle
  CONTENT.pack = await packLoadJson('core-ar', 'content/packs/core-ar.json');
  return CONTENT.pack;
}

/* Deterministic daily rotation, fully offline:
   crisis category rotates by day-of-year, tip rotates within its pool.
   Tips are objects { t, s } where s is a short source label (older packs
   with plain-string tips still render). */
function normTip(raw) {
  if (raw && typeof raw === 'object') return { t: raw.t, s: raw.s || '' };
  return { t: String(raw || ''), s: '' };
}

function adviceForToday(pack, date) {
  if (window.BROAD_TIPS && window.BROAD_TIPS.length) {   // broad daily advice: one tip a day, no repeat until the whole list has passed
    const st = new Date(date.getFullYear(), 0, 0), di = Math.floor((date - st) / 86400000) + date.getFullYear() * 366, bt = window.BROAD_TIPS[di % window.BROAD_TIPS.length];
    return { crisis: bt.n, tip: bt.t, verse: bt.v, vref: bt.r, source: '', disclaimer: '' };
  }
  const adv = pack && pack.advice;
  if (!adv || !adv.crises || !adv.crises.length) return null;
  const start = new Date(date.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((date - start) / 86400000);
  // walk all tips in turn (no crisis x tip lockstep): the cycle is the full tip count
  const flat = []; adv.crises.forEach(c => c.tips.forEach(t => flat.push([c, t])));
  const di = dayOfYear + date.getFullYear() * 366;
  const [crisis, rawTip] = flat[di % flat.length];
  const tip = normTip(rawTip);
  return { crisis: crisis.name, tip: tip.t, source: tip.s, disclaimer: adv.disclaimer };
}

function adviceForCrisis(pack, crisisId, date) {
  const adv = pack && pack.advice;
  if (!adv) return null;
  const crisis = adv.crises.find(c => c.id === crisisId);
  if (!crisis || !crisis.tips.length) return null;
  const start = new Date(date.getFullYear(), 0, 0);
  const dayOfYear = Math.floor((date - start) / 86400000);
  const tip = normTip(crisis.tips[dayOfYear % crisis.tips.length]);
  return { crisis: crisis.name, tip: tip.t, source: tip.s, disclaimer: adv.disclaimer };
}

/* Latin-script names inside Arabic source labels get their own LTR run so RTL can't reorder them. */
function srcLabel(s) { return String(s || '').replace(/[A-Za-z][A-Za-z0-9.'&\- ]*[A-Za-z0-9]/g, m => '<bdi dir="ltr">' + m + '</bdi>'); }

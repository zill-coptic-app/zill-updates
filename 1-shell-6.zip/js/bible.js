/* Offline bible reader (Van Dyke 1865 for the 66 protocanonical books;
   deuterocanon 67-73 ships from the same katameros Arabic pack — exact
   translation provenance under verification, labeled honestly in the UI). */
function tashText(bookId, c, v, plain) {
  const o = BIBLE.tash && setLoad().tash !== '0' && BIBLE.tash[String(bookId)];
  const t = o && o[String(c)] && o[String(c)][String(v)];
  return t || plain;
}
const BIBLE = { pack: null, loading: null, book: null, chapter: null };

async function bibleLoad() {
  if (BIBLE.pack) return BIBLE.pack;
  if (!BIBLE.loading) {
    BIBLE.loading = packLoadJson('bible-ar', 'content/packs/bible-ar.json')
      .catch(() => null);
  }
  const pk = await BIBLE.loading;
  if (pk && BIBLE.tash === undefined) {   // optional vowel marks (eBible.org arb-vd), overlay per verse; plain text stays for search
    BIBLE.tash = null;
    try { BIBLE.extras = (await packLoadJson('bible-extras', 'content/packs/bible-extras.json')).books; } catch (e) {}
    if (setLoad().tash !== '0') { try { BIBLE.tash = (await packLoadJson('bible-ar-tashkeel', 'content/packs/bible-ar-tashkeel.json')).books; } catch (e) {} }
  }
  if (pk && !pk._ad) { pk.books.forEach(b => { b.name = toArabicDigits(b.name); }); pk._ad = 1; }
  BIBLE.pack = pk;
  return BIBLE.pack;
}

const BIBLE_GROUPS = [
  { name: 'العهد القديم', from: 1, to: 39 },
  { name: 'العهد الجديد', from: 40, to: 66 },
  { name: 'الأسفار القانونية الثانية', from: 67, to: 73 }
];

function bibleGroupOf(id) { const i = BIBLE_GROUPS.findIndex(g => id >= g.from && id <= g.to); return i === 2 ? 0 : i; }

function bibleGroupsHTML(pack) {
  let h = '<div class="bk-list">';
  BIBLE_GROUPS.slice(0, 2).forEach((g, i) => {
    const n = pack.books.filter(b => b.id >= g.from && b.id <= g.to).length;
    if (!n) return;
    h += '<div class="bk-row" data-grp="' + i + '" role="button"><span class="bk-name">' + g.name + '</span></div>';
  });
  h += '</div>';
  return h;
}

function bibleBookRows(pack, g) {
  return pack.books.filter(b => b.id >= g.from && b.id <= g.to).map(b => {
    const chCount = Object.keys(b.chapters).length;
    return '<div class="bk-row" data-book="' + b.id + '" role="button"><span class="bk-name">' + b.name +
      '</span><span class="bk-meta">' + toArabicDigits(chCount) + ' أصحاح</span></div>';
  }).join('');
}

function bibleBooksHTML(pack, gi) {
  let h = '<div class="bk-list">' + bibleBookRows(pack, BIBLE_GROUPS[gi]) + '</div>';
  if (gi === 0) {
    const dc = bibleBookRows(pack, BIBLE_GROUPS[2]);
    if (dc) h += '<h2 class="rd-sec-title">' + BIBLE_GROUPS[2].name + '</h2><div class="bk-list">' + dc + '</div>';
  }
  return h;
}

function bibleChaptersHTML(book) {
  const nums = Object.keys(book.chapters).map(Number).sort((a, b) => a - b);
  let h = (typeof zGuideCardHTML === 'function' ? zGuideCardHTML(book.id) : '') + '<div class="ch-grid">';
  nums.forEach(n => {
    h += '<span class="ch-chip" data-ch="' + n + '" role="button">' + toArabicDigits(n) + '</span>';
  });
  h += '</div>';
  return h;
}

function bibleExtraText(t) {   // source titles/subscriptions: vowelled like the pack, plain when vowels are off
  return (BIBLE.tash && setLoad().tash !== '0') ? t : t.replace(/[\u064B-\u0652\u0670\u0640]/g, '').replace(/\u0671/g, '\u0627');
}
function bibleChapterText(book, chapter) {
  const verses = book.chapters[String(chapter)] || {};
  const nums = Object.keys(verses).map(Number).sort((a, b) => a - b);
  const ex = (BIBLE.extras && BIBLE.extras[String(book.id)] && BIBLE.extras[String(book.id)][String(chapter)]) || {};
  return (ex.h ? '<p class="verse-extra verse-title">' + bibleExtraText(ex.h) + '</p>' : '') + nums.map(n => {
    const f = (ex.f || []).filter(x => x[0] === n).map(x => '<p class="verse-extra verse-sub">' + bibleExtraText(x[1]) + '</p>').join('');
    return '<p class="verse" data-v="' + n + '"><span class="vnum">' + toArabicDigits(n) + '</span>' + tashText(book.id, chapter, n, verses[String(n)]) + '</p>' + f;
  }).join('');
}

/* Illustrated chapter guide, Genesis (test). Captions are app-written summaries of the chapter text (not Bible text);
   images are AI-drawn illustrations, labeled as such. Holy text is read in the chapter itself. */
const ZGUIDE_ON = false; /* Genesis illustrations temporarily OFF (user 23:52). Images parked in ../parked_genesis_img/gen; to restore: move back to web/img/gen and set true. */
const ZGUIDE = {
  1: { title: 'سفر التكوين بالصور', n: 50, items: [
    ['الله بكلمته يخلق النور، والبحر واليابسة، والشمس والقمر والنجوم، والطيور والأسماك، وآخر حاجة الإنسان.', '١-٣١'],
    ['الله يحط الإنسان في جنة عدن، ويعمل له معينًا نظيره: المرأة.', '٨، ١٨-٢٤'],
    ['آدم وحواء يأكلوا من الشجرة اللي نهاهم الله عنها، وبعدين يطلعوا من الجنة.', '١-٢٤'],
    ['قايين وهابيل بيقدّموا قرابين لله. قربان هابيل اتقبل، وقايين غضب وقتل أخاه.', '٣-٨'],
    ['سلسلة الأجيال من آدم لنوح، عشرة أجيال. وأخنوخ سار مع الله ولم يوجد لأن الله أخذه.', '١-٣٢'],
    ['الشر كتر على الأرض، ونوح لقى نعمة، والله يأمره يبني فلكًا.', '٥-٨، ١٣-٢٢'],
    ['نوح وبيته والحيوانات بيدخلوا الفلك، والطوفان يبدأ.', '٧-١٠'],
    ['المياه تنقص، والفلك يستقر على جبال أراراط، والحمامة ترجع بورقة زيتون.', '٤، ١١'],
    ['الله يقيم عهده مع نوح، وعلامته القوس في السحاب.', '٨-١٧'],
    ['أولاد نوح: سام وحام ويافث، ومنهم تفرّقت الأمم على الأرض.', '١-٣٢'],
    ['بناء المدينة والبرج في شنعار، والله يبلبل ألسنتهم فيتفرقوا.', '١-٩'],
    ['الرب يدعو أبرام يخرج من أرضه، وأبرام يمشي لأرض كنعان.', '١-٥'],
    ['أبرام ولوط يفترقوا، ولوط يختار دائرة الأردن.', '٥-١٢'],
    ['أبرام ينقذ لوط، وملكي صادق يخرج له بخبز وخمر ويباركه.', '١٤-٢٠'],
    ['الله يوعد أبرام بنسل كتير زي نجوم السما.', '٥-٦'],
    ['هاجر في البرية عند عين ماء، وبتولد إسماعيل.', '٧-١٥'],
    ['الله يغيّر اسم أبرام لإبراهيم، واسم ساراي لسارة، ويقيم عهده معاه.', '٥، ١٥'],
    ['ثلاثة زوّار عند إبراهيم، وسارة تضحك لما تسمع الوعد بابن.', '١-١٥'],
    ['لوط وعيلته يتطلّعوا من سدوم قبل ما تتدمّر.', '١٥-٢٥'],
    ['أبيمالك ملك جرار يعرف الحقيقة في حلم، ويرجّع سارة لإبراهيم.', '٣-١٤'],
    ['سارة تلد إسحاق وهي كبيرة، زي ما وعد الله.', '١-٧'],
    ['إبراهيم وإسحاق على الجبل، والله يقدّم كبشًا بدل الابن.', '١-١٤'],
    ['موت سارة، وإبراهيم يشتري مغارة المكفيلة قبر للعيلة.', '١-٢٠'],
    ['خادم إبراهيم يقابل رفقة عند البئر، وبعدين تتجوز إسحاق.', '١٠-٦٧'],
    ['ولادة التوأم عيسو ويعقوب، وعيسو يبيع بكوريته بطبق عدس.', '٢٤-٣٤'],
    ['إسحاق يحفر آبار في أرض جرار، والله يباركه.', '١٢-٣٣'],
    ['يعقوب ياخد بركة إسحاق قبل عيسو.', '١-٢٩'],
    ['يعقوب يحلم بسلّم من الأرض للسما، وملايكة طالعة ونازلة.', '١٠-٢٢'],
    ['يعقوب يقابل راحيل عند البئر، ويخدم لابان.', '١-٢٠'],
    ['أولاد كتير بيتولدوا ليعقوب، وغنمه بتكتر عند لابان.', '١-٤٣'],
    ['يعقوب يمشي بعيلته من عند لابان، ولابان يلحقه ويعملوا عهد.', '١٧-٥٥'],
    ['يعقوب يصارعه إنسان لحد الفجر عند مخاضة يبّوق، واسمه يبقى إسرائيل.', '٢٢-٣٢'],
    ['عيسو يجري يحضن يعقوب، والاتنين يتصالحوا.', '١-١٠'],
    ['شكيم يذلّ دينة بنت يعقوب، وابنا يعقوب شمعون ولاوي ينتقموا بعنف، ويعقوب يعاتبهم ويتضايق.', '١-٣١'],
    ['يعقوب يرجع لبيت إيل ويبني مذبح. وراحيل تموت بعد ولادة بنيامين، وبعدين يموت إسحاق.', '١-٢٩'],
    ['نسل عيسو، وعيسو هو أدوم، ساكن في جبل سعير.', '١-٤٣'],
    ['يوسف بالقميص الملوّن: إخوته يبيعوه لتجار ماشيين لمصر.', '٣، ٢٣-٣٦'],
    ['قصة يهوذا وثامار، وفي آخر الأصحاح تولد التوأم فارص وزارح.', '١-٣٠'],
    ['يوسف يتظلم ويتسجن في مصر، والرب معاه.', '١-٢٣'],
    ['يوسف يفسّر حلم رئيس السقاة ورئيس الخبازين في السجن.', '١-٢٣'],
    ['يوسف يفسّر حلم فرعون: سبع سنين شبع وبعدها سبع سنين جوع، وفرعون يقيمه على مصر.', '١-٤٩'],
    ['إخوة يوسف ييجوا مصر يشتروا قمح، ويسجدوا له وهم مش عارفينه.', '١-٢٤'],
    ['إخوته يرجعوا ومعاهم بنيامين، ويوسف يعمل لهم وليمة.', '١٥-٣٤'],
    ['الكأس الفضة في عدل بنيامين، ويهوذا يتشفّع فيه.', '١-٣٤'],
    ['يوسف يعرّفهم بنفسه ويحضنهم، ويبعت يجيب أبوه.', '١-٢٨'],
    ['يعقوب يروح مصر، ويقابل يوسف ويحضنه.', '١-٣٤'],
    ['يعقوب قدام فرعون، وعيلته تسكن أرض جاسان، ويوسف يوزّع القمح في المجاعة.', '١-٢٧'],
    ['يعقوب يبارك ابني يوسف: أفرايم ومنسى.', '١-٢٢'],
    ['يعقوب يجمع أولاده الاتناشر ويبارك كل واحد.', '١-٣٣'],
    ['موت يعقوب ودفنه في كنعان. يوسف يطمّن إخوته، وبعدين يموت.', '١-٢٦']
  ] }
};
(function () {
  const AD = s => (typeof toArabicDigits === 'function' ? toArabicDigits(s) : String(s));
  let cur = 0, ov = null, bookId = 0;
  window.zGuideCardHTML = function (id) {
    if (!ZGUIDE_ON) return '';
    const g = ZGUIDE[id]; if (!g) return '';
    return '<div class="gd-card" data-guide="' + id + '" role="button"><img src="img/gen/ch1.webp" alt="" loading="lazy"><div class="gd-card-t"><b>' + g.title + '</b><span>نظرة أولى بالصور، صورة لكل أصحاح بالترتيب (تجريبي)</span></div></div>';
  };
  function show(i) {
    const g = ZGUIDE[bookId], n = g.items.length; cur = Math.max(0, Math.min(n - 1, i));
    const it = g.items[cur], c = cur + 1;
    ov.querySelector('.gd-img').src = 'img/gen/ch' + c + '.webp';
    ov.querySelector('.gd-img').alt = 'أصحاح ' + AD(c);
    ov.querySelector('.gd-ch').textContent = 'أصحاح ' + AD(c);
    ov.querySelector('.gd-of').textContent = AD(c) + ' من ' + AD(n);
    ov.querySelector('.gd-cap').textContent = it[0];
    ov.querySelector('.gd-v').textContent = 'من الأصحاح: آيات ' + it[1];
    ov.querySelector('.gd-prev').disabled = cur === 0; ov.querySelector('.gd-next').disabled = cur === n - 1;
    const strip = ov.querySelector('.gd-strip'), on = strip.querySelector('.on'); if (on) on.classList.remove('on');
    const b = strip.children[cur]; if (b) { b.classList.add('on'); strip.scrollLeft = b.offsetLeft - strip.clientWidth / 2 + b.clientWidth / 2; }
    if (ov.querySelector('.gd-img-wrap')) ov.querySelector('.gd-img-wrap').scrollTop = 0;
    const nx = new Image(); if (cur < n - 1) nx.src = 'img/gen/ch' + (c + 1) + '.webp';
  }
  function open(id, start) {
    bookId = id; const g = ZGUIDE[id]; if (!g) return;
    if (!ov) {
      ov = document.createElement('div'); ov.id = 'gdOv'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', g.title);
      ov.innerHTML = '<div class="gd-top"><button class="gd-x" aria-label="إغلاق">✕</button><span class="gd-ch"></span><span class="gd-of"></span></div>' +
        '<div class="gd-img-wrap"><img class="gd-img" alt=""><button class="gd-prev" aria-label="السابق">›</button><button class="gd-next" aria-label="التالي">‹</button></div>' +
        '<div class="gd-cap"></div><div class="gd-v"></div>' +
        '<div class="gd-strip"></div>' +
        '<div class="gd-bot"><button class="gd-read">اقرأ الأصحاح</button></div>' +
        '<div class="gd-note">رسم تخيّلي بالذكاء الاصطناعي، والشرح من كتابة البرنامج. كل صورة بتوضّح مشهد أساسي من الأصحاح مش الأصحاح كله. النص المقدّس في الأصحاح نفسه.</div>';
      document.body.appendChild(ov);
      ov.querySelector('.gd-strip').innerHTML = g.items.map((_, i) => '<button data-i="' + i + '">' + AD(i + 1) + '</button>').join('');
      ov.querySelector('.gd-x').onclick = close;
      ov.querySelector('.gd-prev').onclick = () => show(cur - 1);
      ov.querySelector('.gd-next').onclick = () => show(cur + 1);
      ov.querySelector('.gd-strip').onclick = e => { const b = e.target.closest('button[data-i]'); if (b) show(+b.dataset.i); };
      ov.querySelector('.gd-read').onclick = () => {
        const c = cur + 1; close();
        const chip = document.querySelector('#bibleBody .ch-chip[data-ch="' + c + '"]'); if (chip) chip.click();
      };
      let sx = null;
      ov.querySelector('.gd-img-wrap').addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
      ov.querySelector('.gd-img-wrap').addEventListener('touchend', e => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; sx = null; if (Math.abs(dx) > 50) show(cur + (dx > 0 ? -1 : 1) * 1); }, { passive: true });
    }
    ov.hidden = false; show(start || 0);
  }
  function close() { if (ov) ov.hidden = true; }
  window.zGuideClose = function () { if (ov && !ov.hidden) { close(); return true; } return false; };
  document.addEventListener('click', e => { const c = e.target.closest('.gd-card[data-guide]'); if (c) open(+c.dataset.guide, 0); });
})();

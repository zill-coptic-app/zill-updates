/* الثعبان والتفاح — user request 01:27 («التعبان اللي بياكل التفاح»). Offline canvas game. */
const SNAKE = { timer: null, dir: [1, 0], next: [1, 0], body: [], apple: null, score: 0, N: 16, over: false };
function snakeBest() { return +(localStorage.getItem('zill.snake.best') || 0); }
function snakeReset() {
  SNAKE.body = [[5, 8], [4, 8], [3, 8]]; SNAKE.dir = [1, 0]; SNAKE.next = [1, 0]; SNAKE.score = 0; SNAKE.over = false;
  snakeApple();
}
function snakeApple() {
  let a;
  do { a = [Math.floor(Math.random() * SNAKE.N), Math.floor(Math.random() * SNAKE.N)]; }
  while (SNAKE.body.some(b => b[0] === a[0] && b[1] === a[1]));
  SNAKE.apple = a;
}
function snakeTurn(dx, dy) {
  if (dx === -SNAKE.dir[0] && dy === -SNAKE.dir[1]) return;
  SNAKE.next = [dx, dy];
}
function snakeStep() {
  if (SNAKE.over) return;
  SNAKE.dir = SNAKE.next;
  const h = [SNAKE.body[0][0] + SNAKE.dir[0], SNAKE.body[0][1] + SNAKE.dir[1]];
  const N = SNAKE.N;
  if (h[0] < 0 || h[1] < 0 || h[0] >= N || h[1] >= N || SNAKE.body.some(b => b[0] === h[0] && b[1] === h[1])) {
    SNAKE.over = true; snakeStop();
    if (SNAKE.score > snakeBest()) localStorage.setItem('zill.snake.best', String(SNAKE.score));
    snakeDraw(); return;
  }
  SNAKE.body.unshift(h);
  if (h[0] === SNAKE.apple[0] && h[1] === SNAKE.apple[1]) { SNAKE.score++; snakeApple(); } else SNAKE.body.pop();
  snakeDraw();
}
function snakeStop() { if (SNAKE.timer) { clearInterval(SNAKE.timer); SNAKE.timer = null; } }
function snakeStart() { snakeStop(); snakeReset(); snakeDraw(); SNAKE.timer = setInterval(snakeStep, 190); }
function snakeDraw() {
  const cv = document.getElementById('snakeCv'); if (!cv) return;
  const ctx = cv.getContext('2d'), s = cv.width / SNAKE.N;
  const css = getComputedStyle(document.documentElement);
  ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.fillStyle = 'rgba(127,127,127,.10)'; ctx.fillRect(0, 0, cv.width, cv.height);
  ctx.fillStyle = '#d9534f'; ctx.beginPath();
  ctx.arc((SNAKE.apple[0] + .5) * s, (SNAKE.apple[1] + .5) * s, s * .38, 0, 7); ctx.fill();
  SNAKE.body.forEach((b, i) => {
    ctx.fillStyle = i === 0 ? css.getPropertyValue('--gold').trim() : css.getPropertyValue('--gold2').trim();
    ctx.globalAlpha = i === 0 ? 1 : .8;
    ctx.fillRect(b[0] * s + 1, b[1] * s + 1, s - 2, s - 2);
  });
  ctx.globalAlpha = 1;
  const sc = document.getElementById('snakeScore');
  if (sc) sc.textContent = 'النتيجة: ' + toArabicDigits(SNAKE.score) + ' · الأفضل: ' + toArabicDigits(Math.max(snakeBest(), SNAKE.score));
  const ov = document.getElementById('snakeOver'); if (ov) ov.hidden = !SNAKE.over;
}

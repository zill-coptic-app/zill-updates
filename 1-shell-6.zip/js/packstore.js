/* Pack store — verified updated content packs, kept in IndexedDB so large
   packs (bible-ar 4.9MB, tashkeel 7.4MB) fit where localStorage (~5MB
   shared) cannot. Every read falls back to the bundled pack on any miss or
   error, so the app always opens offline with shipped content. Writes happen
   only through updater.js after manifest signature + per-pack SHA-256
   verification. Data only: packs are JSON text, never executable code. */
const PACK_STORE = (() => {
  const DB = 'zilldb', STORE = 'packs';
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((resolve) => {
      try {
        if (!window.indexedDB) return resolve(null);
        const rq = indexedDB.open(DB, 1);
        rq.onupgradeneeded = () => { try { rq.result.createObjectStore(STORE); } catch (e) {} };
        rq.onsuccess = () => resolve(rq.result);
        rq.onerror = () => resolve(null);
        rq.onblocked = () => resolve(null);
      } catch (e) { resolve(null); }
    });
    return dbp;
  }
  function req(db, mode, build) {
    return new Promise((resolve) => {
      let settled = false;
      const done = (v) => { if (!settled) { settled = true; resolve(v); } };
      try {
        const t = db.transaction(STORE, mode), s = t.objectStore(STORE);
        const r = build(s);
        if (r && typeof r === 'object' && 'onsuccess' in r) {
          r.onsuccess = () => done(r.result !== undefined ? r.result : true);
          r.onerror = () => done(undefined);
        } else {
          t.oncomplete = () => done(true);
          t.onerror = () => done(undefined);
          t.onabort = () => done(undefined);
        }
      } catch (e) { done(undefined); }
    });
  }
  return {
    async get(id) {
      const db = await open(); if (!db) return null;
      const v = await req(db, 'readonly', (s) => s.get(id));
      return typeof v === 'string' ? v : null;
    },
    async set(id, text) {
      const db = await open(); if (!db) return false;
      const v = await req(db, 'readwrite', (s) => s.put(text, id));
      return v !== undefined;
    },
    async del(id) {
      const db = await open(); if (!db) return false;
      const v = await req(db, 'readwrite', (s) => s.delete(id));
      return v !== undefined;
    },
    async getBlob(id) {
      const db = await open(); if (!db) return null;
      const v = await req(db, 'readonly', (s) => s.get(id));
      return (v instanceof Blob) ? v : null;
    },
    async setBlob(id, blob) {
      const db = await open(); if (!db) return false;
      const v = await req(db, 'readwrite', (s) => s.put(blob, id));
      return v !== undefined;
    }
  };
})();

/* Media override lookup. Pack id for a media file is its bundled relative
   path (e.g. 'audio/joseph/s1_b1.m4a'). A stored verified blob wins and is
   served through an object URL; anything missing falls back to the bundled
   file. Object URLs are cached per id for the session and revoked on
   re-apply or rollback. */
const PACK_MEDIA_URLS = {};
async function packMediaUrl(id, bundledUrl) {
  try {
    let blob = await PACK_STORE.getBlob('media/' + packKeyFor(id));
    if (!blob) blob = await PACK_STORE.getBlob('media/' + id);
    if (blob) {
      if (!PACK_MEDIA_URLS[id]) PACK_MEDIA_URLS[id] = URL.createObjectURL(blob);
      return PACK_MEDIA_URLS[id];
    }
  } catch (e) {}
  return bundledUrl;
}
function packMediaDropCache(id) {
  if (PACK_MEDIA_URLS[id]) { try { URL.revokeObjectURL(PACK_MEDIA_URLS[id]); } catch (e) {} delete PACK_MEDIA_URLS[id]; }
}

/* Escape a pack-sourced plain-text value for interpolation into HTML. */
const packText = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* Strict allowlist sanitizer for pack-sourced HTML (remotely updatable
   packs). Keeps only bare formatting tags (bundled packs use only <p>);
   strips ALL attributes, so no event handlers, no style, no href/src;
   drops script/style/svg/media/link/form/img/a and any active-content tag
   entirely. Output is inert markup: formatting only, never executable. */
const PACK_HTML_TAGS = { P: 1, BR: 1, B: 1, I: 1, STRONG: 1, EM: 1, SPAN: 1, BDI: 1, UL: 1, OL: 1, LI: 1, DIV: 1 };
const PACK_HTML_DROP = { SCRIPT: 1, STYLE: 1, SVG: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, LINK: 1, META: 1, FORM: 1, INPUT: 1, BUTTON: 1, AUDIO: 1, VIDEO: 1, IMG: 1, A: 1, TEXTAREA: 1, SELECT: 1, MATH: 1, TEMPLATE: 1, BASE: 1, TITLE: 1 };
function packSanHtml(s) {
  const t = document.createElement('template');
  t.innerHTML = String(s == null ? '' : s); // inert parse: no scripts run, no fetches
  const walk = (node) => {
    for (const n of [...node.childNodes]) {
      if (n.nodeType === 3) continue;              // text: safe
      if (n.nodeType !== 1) { n.remove(); continue; } // comments etc.
      if (PACK_HTML_DROP[n.tagName]) { n.remove(); continue; }
      if (!PACK_HTML_TAGS[n.tagName]) {            // unknown tag: unwrap children
        while (n.firstChild) node.insertBefore(n.firstChild, n);
        n.remove(); walk(node); return;
      }
      for (const a of [...n.attributes]) n.removeAttribute(a.name);
      walk(n);
    }
  };
  walk(t.content);
  return t.innerHTML;
}

/* Generation-aware key resolution. Updates are written under 'g<N>/<id>'
   and ACTIVATED by a single localStorage write that bumps the generation
   pointer (updater.js). A crash mid-write never activates partial content:
   readers keep resolving the old generation. */
function packKeyFor(id) {
  try {
    const st = JSON.parse(localStorage.getItem('zill.updater.v1') || '{}');
    const g = st.appliedGen && st.appliedGen[id];
    if (g) return 'g' + g + '/' + id;
  } catch (e) {}
  return id; // generation 0: plain keys (pre-generation entries)
}

/* Load a JSON pack: active generation wins, then pre-generation stored
   entry, then the legacy vc30 localStorage slot ('zill.pack.<id>'), then
   the bundled file. Corrupt stored JSON is ignored in favor of the bundle. */
async function packLoadJson(id, url) {
  let text = null;
  const key = packKeyFor(id);
  try { text = await PACK_STORE.get(key); } catch (e) {}
  if (text == null && key !== id) { try { text = await PACK_STORE.get(id); } catch (e) {} }
  if (text == null) { try { text = localStorage.getItem('zill.pack.' + id); } catch (e) {} }
  if (text != null) {
    try { return JSON.parse(text); } catch (e) { /* corrupt update → fall through to bundle */ }
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error('pack http ' + res.status + ' ' + url);
  return res.json();
}

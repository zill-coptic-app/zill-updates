/* Content updater — LOCAL MECHANISM ONLY.
   - No public endpoint is configured by default (UPDATER.endpoint = null).
   - When an endpoint is later authorized, the flow is:
     1) fetch manifest.json (small, capped)
     2) schema + version validation, then Ed25519 signature verification over
        the canonical manifest bytes with the embedded public key — an
        unsigned, malformed, stale or bad-signature manifest is rejected.
        Devices whose WebView lacks Ed25519 (crypto.subtle probe fails)
        reject every manifest: fail closed, never install unverifiable
        content.
     3) download changed packs (same origin as the manifest, size-capped),
        verify each pack's SHA-256 before applying
     4) apply atomically into the IndexedDB pack store; the immediately
        previous content is kept ('prev/...') so one-step rollback works
        offline.
   - Versions are positive integers. A manifest whose manifest_version is
     not newer than the last applied one is rejected (replay/downgrade
     guard), and a pack whose version is not newer than the applied one is
     skipped.
   - Packs are data only: JSON packs are parsed with JSON.parse and never
     executed; media packs are stored as blobs and served via object URLs.
     A mutable public JSON is never treated as trusted executable content.
   Test hook: UPDATER._verifyOverride, when a function, replaces signature
   verification. Used only by local automated tests; always null in builds. */
const UPDATER = {
  endpoint: 'https://zill-coptic-app.github.io/zill-updates/manifest.json',
  // Public key (Ed25519, raw 32 bytes, base64). Private key stays offline with the publisher.
  publicKeyB64: 'GzXGc6gbJ/tWquohchAD8puVzW95CzgF0uuqcV/Fc1k=', // real pack-signing PUBLIC key (signing/pack-pubkey.txt); inert until an endpoint is set
  stateKey: 'zill.updater.v1',
  _verifyOverride: null,
  _shellOverride: null,
  _fsOverride: null,
  // Separate Ed25519 key for shell (web code) bundles; private seed in the vault, never in the repo.
  shellPublicKeyB64: 'zKHB1rPbVno5G3JoHuAEu7ybezGaUO1mTHQKAq19+ZI='
};

const UPDATER_LIMITS = {
  manifestBytes: 200 * 1024,   // manifest is a small index
  packBytes: 30 * 1024 * 1024, // largest shipped pack is 7.4MB; headroom, not a target
  maxPacks: 50
};
const PACK_ID_RE = /^[A-Za-z0-9_\-./]+$/;
const MEDIA_TYPES = { '.m4a': 'audio/mp4', '.mp3': 'audio/mpeg', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' };

async function updaterCheck() {
  if (!UPDATER.endpoint || !UPDATER.publicKeyB64) return { skipped: 'no-endpoint' };
  let endpointUrl;
  try { endpointUrl = new URL(UPDATER.endpoint); } catch (e) { return { error: 'bad-endpoint' }; }
  const isLocalTest = endpointUrl.hostname === '127.0.0.1' || endpointUrl.hostname === 'localhost';
  if (endpointUrl.protocol !== 'https:' && !isLocalTest) return { error: 'endpoint-not-https' };
  if (!(await ed25519Supported())) return { error: 'crypto-ed25519-unsupported' };
  try {
    const res = await fetch(UPDATER.endpoint, { cache: 'no-store' });
    if (!res.ok) return { error: 'manifest-fetch-' + res.status };
    const raw = new Uint8Array(await res.arrayBuffer());
    if (raw.length > UPDATER_LIMITS.manifestBytes) return { error: 'manifest-too-large' };
    const manifest = JSON.parse(new TextDecoder().decode(raw));
    const schemaError = validateManifest(manifest);
    if (schemaError) return { error: schemaError };
    // replay/downgrade guard: only accept a manifest newer than the last applied one
    const state = updaterState();
    const stale = !!(state.manifestVersion && manifest.manifest_version <= state.manifestVersion);
    // a stale manifest is skipped for packs; its signed shell entry is still checked
    // (shell steps are idempotent: they compare the installed bundle version)
    if (stale && !(manifest.shell && shellPlugin())) return { skipped: 'stale-manifest' };
    const ok = UPDATER._verifyOverride ? await UPDATER._verifyOverride(manifest, raw) : await verifyManifest(manifest, raw);
    if (!ok) return { error: 'bad-signature' };
    let shellResult = null;
    if (manifest.shell) shellResult = await shellApply(manifest.shell, endpointUrl);
    if (stale) return { skipped: 'stale-manifest', shell: shellResult };
    const r = await applyManifest(manifest, endpointUrl, state);
    if (shellResult && r && typeof r === 'object') r.shell = shellResult;
    return r;
  } catch (e) {
    return { error: String(e && e.message || e) };
  }
}

function validateManifest(m) {
  if (!m || typeof m !== 'object') return 'manifest-not-object';
  if (m.format !== 1) return 'manifest-bad-format';
  if (!Number.isInteger(m.manifest_version) || m.manifest_version < 1) return 'manifest-bad-version';
  if (!Array.isArray(m.packs) || m.packs.length > UPDATER_LIMITS.maxPacks) return 'manifest-bad-packs';
  for (const p of m.packs) {
    if (!p || typeof p !== 'object') return 'pack-not-object';
    if (typeof p.id !== 'string' || !PACK_ID_RE.test(p.id) || p.id.indexOf('..') !== -1) return 'pack-bad-id';
    if (!Number.isInteger(p.version) || p.version < 1) return 'pack-bad-version';
    if (p.type !== 'json' && p.type !== 'media') return 'pack-bad-type';
    if (typeof p.url !== 'string' || !p.url || /^[a-z][a-z0-9+.-]*:/i.test(p.url) || p.url.indexOf('..') !== -1) return 'pack-bad-url';
    if (typeof p.sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(p.sha256)) return 'pack-bad-sha256';
  }
  return null;
}

let _ed25519probe = null;
async function ed25519Supported() {
  if (_ed25519probe) return _ed25519probe;
  _ed25519probe = (async () => {
    try {
      if (!crypto || !crypto.subtle) return false;
      await crypto.subtle.importKey('raw', new Uint8Array(32), { name: 'Ed25519' }, false, ['verify']);
      return true;
    } catch (e) { return false; }
  })();
  return _ed25519probe;
}

async function verifyManifest(manifest, rawBytes) {
  // Manifest carries {..., signed_bytes_sha256, signature_b64}; signature covers
  // the manifest body with the signature fields removed (canonical re-encode).
  try {
    const key = await crypto.subtle.importKey(
      'raw', b64ToBytes(UPDATER.publicKeyB64), { name: 'Ed25519' }, false, ['verify']);
    const body = Object.assign({}, manifest);
    const sig = body.signature_b64; delete body.signature_b64; delete body.signed_bytes_sha256;
    const canonical = new TextEncoder().encode(JSON.stringify(body));
    return await crypto.subtle.verify('Ed25519', key, b64ToBytes(sig), canonical);
  } catch (e) { return false; }
}

function updaterState() {
  try { return JSON.parse(localStorage.getItem(UPDATER.stateKey) || '{"applied":{},"rollback":{},"manifestVersion":0,"currentGen":0,"appliedGen":{}}'); }
  catch (e) { return { applied: {}, rollback: {}, manifestVersion: 0, currentGen: 0, appliedGen: {} }; }
}

/* ---- Signed web-shell updates (whole web folder, not only data packs) ----
   The signed manifest may carry a "shell" entry. The installed APK's native
   updater plugin downloads the zip, checks its SHA-256, extracts it with entry
   and byte caps, and switches to it on the next return from background. If the
   new bundle does not call shellBootConfirm() within seconds of starting, the
   plugin returns to the last good bundle (or the one built into the APK).
   Native code, icon, name and permissions never change this way (needs an APK).
   Gates here, all before any download: manifest signature (done by caller),
   plugin present, entry well-formed, same origin as the manifest over https,
   minimum installed app version, strictly newer than the running bundle, not a
   bundle the plugin already marked as failed. */
const SHELL_ZIP_MAX = 120 * 1024 * 1024;
const SHELL_ID_RE = /^zs-(\d{1,6})$/;
function shellPlugin() {
  try {
    if (UPDATER._shellOverride) return UPDATER._shellOverride;
    const C = window.Capacitor; if (!C) return null;
    return (C.registerPlugin ? C.registerPlugin('CapacitorUpdater') : (C.Plugins && C.Plugins.CapacitorUpdater)) || null;
  } catch (e) { return null; }
}
function shellSemverCmp(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d < 0 ? -1 : 1; }
  return 0;
}
function validateShell(sh) {
  if (!sh || typeof sh !== 'object') return 'shell-not-object';
  if (!Number.isInteger(sh.version) || sh.version < 1 || sh.version > 999999) return 'shell-bad-version';
  if (typeof sh.url !== 'string' || !sh.url || /^[a-z][a-z0-9+.-]*:/i.test(sh.url) || sh.url.indexOf('..') !== -1 || sh.url.indexOf('\\') !== -1) return 'shell-bad-url';
  if (typeof sh.sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(sh.sha256)) return 'shell-bad-sha256';
  if (!Number.isInteger(sh.size) || sh.size < 1 || sh.size > SHELL_ZIP_MAX) return 'shell-bad-size';
  if (sh.min_shell !== undefined && !(typeof sh.min_shell === 'string' && /^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(sh.min_shell))) return 'shell-bad-min';
  return null;
}
const SHELL_HIGHEST_KEY = 'zill.shell.highest';
const SHELL_HIGHEST_FILE = 'zill-shell-highest.txt';
/* The highest accepted shell number is kept in TWO places outside any web bundle's
   code: localStorage (same origin) and a small file in the app's native data
   directory (Capacitor Filesystem plugin, already in the app). The larger value
   wins, so losing one (origin change, storage clear) does not reopen a downgrade. */
function shellFs() {
  try { if (UPDATER._fsOverride) return UPDATER._fsOverride; const C = window.Capacitor; return (C && C.Plugins && C.Plugins.Filesystem) || null; } catch (e) { return null; }
}
async function shellHighest() {
  let a = 0, b = 0;
  try { a = parseInt(localStorage.getItem(SHELL_HIGHEST_KEY) || '0', 10) || 0; } catch (e) {}
  const fs = shellFs();
  if (fs) { try { const r = await fs.readFile({ path: SHELL_HIGHEST_FILE, directory: 'DATA', encoding: 'utf8' }); b = parseInt(String(r && r.data || '0'), 10) || 0; } catch (e) {} }
  return Math.max(a, b, 0);
}
async function shellSetHighest(n) {
  if (n <= await shellHighest()) return;
  try { localStorage.setItem(SHELL_HIGHEST_KEY, String(n)); } catch (e) {}
  const fs = shellFs();
  if (fs) { try { await fs.writeFile({ path: SHELL_HIGHEST_FILE, directory: 'DATA', data: String(n), encoding: 'utf8' }); } catch (e) {} }
}
async function shellCurrentNumber(CU) {
  try {
    const cur = await CU.current();
    const m = SHELL_ID_RE.exec(cur && cur.bundle && cur.bundle.version || '');
    return m ? +m[1] : 0;
  } catch (e) { return 0; }
}
/* The shell entry carries its own signature (shell.signature_b64) over the entry
   without that field, made with the separate shell key pinned above. Required in
   addition to the manifest signature: a leaked data-pack key cannot ship code. */
async function verifyShellEntry(sh) {
  try {
    if (typeof sh.signature_b64 !== 'string' || !sh.signature_b64) return false;
    const key = await crypto.subtle.importKey('raw', b64ToBytes(UPDATER.shellPublicKeyB64), { name: 'Ed25519' }, false, ['verify']);
    const body = Object.assign({}, sh); delete body.signature_b64;
    return await crypto.subtle.verify('Ed25519', key, b64ToBytes(sh.signature_b64), new TextEncoder().encode(JSON.stringify(body)));
  } catch (e) { return false; }
}
async function shellApply(sh, endpointUrl) {
  const CU = shellPlugin();
  if (!CU) return { skipped: 'no-shell-plugin' };
  const bad = validateShell(sh);
  if (bad) return { error: bad };
  if (!(await verifyShellEntry(sh))) return { error: 'shell-bad-signature' };
  try {
    const url = new URL(sh.url, endpointUrl);
    if (url.origin !== endpointUrl.origin) return { error: 'shell-cross-origin' };
    const isLocalTest = url.hostname === '127.0.0.1' || url.hostname === 'localhost';
    if (url.protocol !== 'https:' && !isLocalTest) return { error: 'shell-not-https' };
    if (sh.min_shell) {
      const bv = await CU.getBuiltinVersion();
      if (!bv || shellSemverCmp(bv.version, sh.min_shell) < 0) return { skipped: 'shell-needs-newer-app' };
    }
    const curN = Math.max(await shellCurrentNumber(CU), await shellHighest());
    if (sh.version <= curN) return { skipped: 'shell-not-newer' };
    const id = 'zs-' + sh.version;
    let known = [];
    try { const l = await CU.list(); known = (l && l.bundles) || []; } catch (e) {}
    const same = known.filter((b) => b && b.version === id);
    if (same.some((b) => b.status === 'error')) return { skipped: 'shell-failed-before' };
    if (same.length) return { skipped: 'shell-already-downloaded' };
    // a newer-or-equal pending bundle from an earlier check also blocks a re-download
    const pendingNewer = known.some((b) => b && b.status === 'pending' && SHELL_ID_RE.test(b.version) && +SHELL_ID_RE.exec(b.version)[1] >= sh.version);
    if (pendingNewer) return { skipped: 'shell-newer-pending' };
    const info = await CU.download({ url: url.href, version: id, checksum: sh.sha256 });
    await shellSetHighest(sh.version);   // accepted (hash verified by the plugin): never offer this number or lower again
    await CU.next({ id: info.id });
    return { downloaded: id };
  } catch (e) {
    return { error: 'shell-' + String(e && e.message || e).slice(0, 80) };
  }
}
/* Boot confirmation. Called late in startup. The new bundle is confirmed only if
   it survives a short window with: no uncaught script error,
   the nav drawn, localStorage working, the core content pack readable, and the
   updater functions present (so a later fix can still arrive). Any failure
   means notifyAppReady is NOT called and the plugin rolls back. */
const _bootErrors = [];
try {
  window.addEventListener('error', (e) => { _bootErrors.push(String(e && e.message || 'error')); });
} catch (e) {}
async function shellBootCheck() {
  const fails = [];
  try { localStorage.setItem('zill.boot.t', '1'); if (localStorage.getItem('zill.boot.t') !== '1') fails.push('storage'); localStorage.removeItem('zill.boot.t'); } catch (e) { fails.push('storage'); }
  if (typeof updaterCheck !== 'function' || typeof shellApply !== 'function' || typeof shellBootConfirm !== 'function') fails.push('updater-missing');
  if (!document.querySelectorAll('#bottomNav .nav-item').length) fails.push('nav');
  try { const j = await packLoadJson('core-ar', 'content/packs/core-ar.json'); if (!j || !j.advice) fails.push('core-pack'); } catch (e) { fails.push('core-pack'); }
  await new Promise((r) => setTimeout(r, 1500));
  if (_bootErrors.length) fails.push('errors:' + _bootErrors.length);
  return fails;
}
async function shellBootConfirm() {
  const CU = shellPlugin(); if (!CU) return false;
  try {
    const fails = await shellBootCheck();
    if (fails.length) return false;
    await CU.notifyAppReady();
    return true;
  } catch (e) { return false; }
}

async function applyManifest(manifest, endpointUrl, state) {
  // Phase 1: download and verify EVERY changed pack before writing anything.
  // A network, size or hash failure anywhere leaves the previous working
  // content fully intact (all-or-nothing across the manifest).
  const staged = [];
  for (const pack of manifest.packs) {
    const appliedVer = state.applied[pack.id] || 0;
    if (appliedVer >= pack.version) continue; // replay/downgrade guard
    const packUrl = new URL(pack.url, endpointUrl);
    if (packUrl.origin !== endpointUrl.origin) return { error: 'pack-origin-' + pack.id };
    const res = await fetch(packUrl.href);
    if (!res.ok) return { error: 'pack-fetch-' + pack.id };
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > UPDATER_LIMITS.packBytes) return { error: 'pack-too-large-' + pack.id };
    const hash = await sha256hex(bytes);
    if (hash !== pack.sha256) return { error: 'pack-hash-mismatch-' + pack.id };
    staged.push({ pack, bytes, appliedVer });
  }
  // Phase 2: write all verified packs under the NEXT generation key.
  // Nothing is visible to readers yet: activation is the single pointer
  // write below. A crash or write failure here leaves the previous
  // generation fully intact and consistent.
  const gen = (state.currentGen || 0) + 1;
  for (const { pack, bytes } of staged) {
    if (pack.type === 'media') {
      const prev = await PACK_STORE.getBlob('media/' + packKeyFor(pack.id));
      if (prev) await PACK_STORE.setBlob('prev/media/' + pack.id, prev);
      else await PACK_STORE.del('prev/media/' + pack.id);
      const ext = pack.id.slice(pack.id.lastIndexOf('.')).toLowerCase();
      const blob = new Blob([bytes], { type: MEDIA_TYPES[ext] || 'application/octet-stream' });
      if (!(await PACK_STORE.setBlob('media/g' + gen + '/' + pack.id, blob))) return { error: 'store-unavailable' };
    } else {
      const prev = await PACK_STORE.get(packKeyFor(pack.id));
      if (prev != null) await PACK_STORE.set('prev/' + pack.id, prev);
      else await PACK_STORE.del('prev/' + pack.id);
      const text = new TextDecoder().decode(bytes);
      if (!(await PACK_STORE.set('g' + gen + '/' + pack.id, text))) return { error: 'store-unavailable' };
    }
  }
  // Phase 3: atomic activation — ONE write flips every pack at once.
  const changed = [];
  for (const { pack, appliedVer } of staged) {
    state.rollback[pack.id] = appliedVer;
    state.applied[pack.id] = pack.version;
    state.appliedGen[pack.id] = gen;
    changed.push(pack.id + '@' + pack.version);
    packMediaDropCache(pack.id);
  }
  state.currentGen = gen;
  state.manifestVersion = manifest.manifest_version;
  localStorage.setItem(UPDATER.stateKey, JSON.stringify(state));
  return { applied: changed };
}

/* Roll back one pack to the pre-update state (one step). Restores the kept
   previous content when there was an earlier applied version, or removes the
   override entirely (bundled file serves again) when the update was the
   first. Works offline. A second consecutive rollback is refused: only one
   step of history is kept. */
async function updaterRollback(packId) {
  const state = updaterState();
  if (!(packId in state.rollback)) return false;
  const prev = state.rollback[packId];
  if (prev === 0) {
    // first applied version: point the pack back at the bundled file
    delete state.applied[packId];
    delete state.appliedGen[packId];
  } else {
    const gen = (state.currentGen || 0) + 1;
    const keptJson = await PACK_STORE.get('prev/' + packId);
    const keptBlob = await PACK_STORE.getBlob('prev/media/' + packId);
    if (keptJson != null) { if (!(await PACK_STORE.set('g' + gen + '/' + packId, keptJson))) return false; }
    if (keptBlob) { if (!(await PACK_STORE.setBlob('media/g' + gen + '/' + packId, keptBlob))) return false; }
    state.applied[packId] = prev;
    state.appliedGen[packId] = gen;
    state.currentGen = gen;
  }
  delete state.rollback[packId];
  await PACK_STORE.del('prev/' + packId);
  await PACK_STORE.del('prev/media/' + packId);
  packMediaDropCache(packId);
  localStorage.setItem(UPDATER.stateKey, JSON.stringify(state));
  return true;
}

/* "What's new" card: shown only when a signed 'whats-new' pack has been applied
   (no bundled copy exists, so nothing shows until an update delivers it).
   Plain text only: rendered with textContent, never as HTML. */
async function updaterShowNews() {
  const box = document.getElementById('zUpdNews'); if (!box) return;
  let j = null;
  try { j = await packLoadJson('whats-new', 'content/packs/whats-new.json'); } catch (e) { j = null; }
  box.textContent = '';
  if (!j || !Array.isArray(j.items) || !j.items.length) return;
  const h = document.createElement('h3'); h.className = 'rd-sec-title'; h.textContent = String(j.title || 'جديد من التحديث').slice(0, 80); box.appendChild(h);
  j.items.slice(0, 5).forEach(it => { const p = document.createElement('p'); p.className = 'rd-concl'; p.textContent = String(it && it.text || '').slice(0, 400); box.appendChild(p); });
}

/* Manual check from the settings row + throttled auto-check on launch.
   Auto-check stays silent: applied packs take effect on next screen load,
   failures stay invisible (bundled content keeps serving). */
async function updaterManualCheck() {
  const st = document.getElementById('zUpdSt');
  const ver = () => { try { return ' (رقم تحديث المحتوى عندك: ' + (updaterState().manifestVersion || 0) + ')'; } catch (e) { return ''; } };
  const say = (t) => { if (st) st.textContent = t + ver(); };
  if (!UPDATER.endpoint) { say('التحديثات مش متفعّلة في النسخة دي.'); return; }
  say('بندوّر على تحديث...');
  const r = await updaterCheck();
  if (r && r.applied && r.applied.length) say('نزل تحديث جديد. هيظهر مع أول شاشة تفتحها.');
  else if (r && Array.isArray(r.applied)) say('مفيش محتوى جديد، التطبيق متصل بالتحديثات.');
  else if (r && (r.skipped === 'stale-manifest' || r.skipped === 'no-endpoint')) say('مفيش تحديث جديد.');
  else say('التحديث مش متاح دلوقتي. المحتوى الموجود شغال زي ما هو.');
  updaterShowNews();
}

/* Automatic checks, no button. Runs when the app opens and when it comes
   back to the foreground (the WebView does nothing while the app is closed).
   Throttle 10 minutes: matches the host's 10-minute edge cache, so asking
   more often would only re-read the same file. Failures stay silent. */
const UPDATER_AUTO_MS = 10 * 60 * 1000;
let _autoCheckInFlight = false;
function updaterAutoCheck() {
  if (!UPDATER.endpoint) return;
  try {
    const last = +(localStorage.getItem('zill.updater.lastCheck') || 0);
    if (Date.now() - last < UPDATER_AUTO_MS) return;
    localStorage.setItem('zill.updater.lastCheck', String(Date.now()));
  } catch (e) {}
  if (_autoCheckInFlight) return;
  _autoCheckInFlight = true;
  updaterCheck().then((r) => {
    if (r && r.applied && r.applied.length) {
      try { if (typeof uiLabelsApply === 'function') uiLabelsApply(); } catch (e) {}
      try { updaterShowNews(); updaterShowStatus(); } catch (e) {}
    }
  }).catch(() => {}).finally(() => { _autoCheckInFlight = false; });
}
document.addEventListener('visibilitychange', () => { if (!document.hidden) updaterAutoCheck(); });

/* Set only by the test-build script; empty in source so release builds show nothing. */
const ZILL_BUILD = '0.9.22 (36) تجربة';
function updaterShowStatus() {
  const st = document.getElementById('zUpdSt'); if (!st) return;
  let n = 0; try { n = updaterState().manifestVersion || 0; } catch (e) {}
  st.textContent = 'التحديثات بتنزل لوحدها لما تفتح التطبيق. (رقم تحديث المحتوى عندك: ' + n + ')' + (ZILL_BUILD ? ' • نسخة التطبيق: ' + ZILL_BUILD : '');
  const CU = shellPlugin();
  if (st) st.textContent += ' • واجهة محدّثة تجريبية (٢)';
  if (CU) shellCurrentNumber(CU).then((k) => { if (k && st) st.textContent += ' • رقم الواجهة: ' + k; }).catch(() => {});
  if (ZILL_BUILD) {   // test builds only: proof that app data survives a shell switch or rollback
    let tok = ''; try { tok = localStorage.getItem('zill.test.token') || ''; if (!tok) { tok = String(1000 + Math.floor(Math.random() * 9000)); localStorage.setItem('zill.test.token', tok); } } catch (e) {}
    if (tok) st.textContent += ' • رمز الاختبار: ' + tok;
    shellHighest().then((h) => { if (h && st) st.textContent += ' • أعلى واجهة مقبولة: ' + h; }).catch(() => {});
  }
}

/* Interface labels from a signed data pack ("ui-labels"). Whitelisted keys
   only, Arabic letters and spaces only, short, rendered as plain text. No
   code is ever delivered. The accepted value is cached so the next launch
   draws the bar correctly at once; a rollback or removal clears it. */
const UI_LABEL_RE = /^[\u0600-\u06FF ]{1,20}$/;
const UI_LABEL_CACHE = 'zill.ui.labels';
const UI_LABEL_NAV_IDS = ['prayers'];
function zillUiLabel(id) {
  try {
    const v = (JSON.parse(localStorage.getItem(UI_LABEL_CACHE) || '{}') || {})[id];
    return (typeof v === 'string' && UI_LABEL_RE.test(v)) ? v : '';
  } catch (e) { return ''; }
}
async function uiLabelsApply() {
  let j = null;
  try { j = await packLoadJson('ui-labels', 'content/packs/ui-labels.json'); } catch (e) { j = null; }
  const out = {};
  if (j && j.nav && typeof j.nav === 'object') {
    UI_LABEL_NAV_IDS.forEach((id) => {
      const v = j.nav[id];
      if (typeof v === 'string' && UI_LABEL_RE.test(v.trim())) out[id] = v.trim();
    });
  }
  try { localStorage.setItem(UI_LABEL_CACHE, JSON.stringify(out)); } catch (e) {}
  document.querySelectorAll('#bottomNav .nav-item').forEach((b) => {
    const id = b.getAttribute('data-nav'); const lb = b.querySelector('.nav-lb'); if (!lb) return;
    if (!b.dataset.zl0) b.dataset.zl0 = lb.textContent;
    lb.textContent = out[id] || b.dataset.zl0;
  });
}

function b64ToBytes(b64) {
  const bin = atob(b64); const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function sha256hex(bytes) {
  const h = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(h)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ألعاب إضافية: صح ولا غلط (بشرح من شرح الأصحاح)، متاهة الفلك، دوّر على الكلمات.
   كل المحتوى متأصل في شرح الأصحاح (js/notes/b1.js) — حقائق نصية فقط. */

/* ---------- صح ولا غلط ---------- */
/* كل سؤال مبني على حقيقة من شرح الأصحاح؛ العبارات الغلط متعمدة والتوضيح بيصححها. */
const ZTF_POOL = [
  { q: 'الله خلق الإنسان على صورته، ذكر وأنثى.', ok: true, why: 'الإنسان هو الوحيد اللي اتقال عنه «على صورة الله»، واتخلق ذكرًا وأنثى في اليوم السادس.', ref: 'تكوين ١: ٢٦-٢٧' },
  { q: 'الله سمّى النور «نهار» والظلمة «ليل».', ok: true, why: 'في اليوم الأول: فصل الله بين النور والظلمة، وسمّى النور نهارًا والظلمة ليلًا.', ref: 'تكوين ١: ٣-٥' },
  { q: 'الله خلق الإنسان في اليوم الرابع.', ok: false, why: 'اليوم الرابع كان للنورين والنجوم؛ الإنسان اتخلق في اليوم السادس.', ref: 'تكوين ١: ١٤-١٩،٢٤-٣١' },
  { q: 'آدم هو اللي سمّى امرأته حواء.', ok: true, why: 'آدم سمّى امرأته حواء لأنها أم كل حي.', ref: 'تكوين ٣: ٢٠' },
  { q: 'أول سؤال قاله الله لآدم بعد الأكل كان: «أين أنت؟».', ok: true, why: 'أول كلام الله مع آدم بعد الأكل كان سؤال: «أين أنت؟» ثم «من أعلمك أنك عريان؟».', ref: 'تكوين ٣: ٩-١١' },
  { q: 'آدم قال لله إنه أكل لوحده ومحصلش من حد حاجة.', ok: false, why: 'بالعكس: آدم قال إن المرأة أعطته، والمرأة قالت إن الحية غرّتها — كل واحد حيل على اللي بعده.', ref: 'تكوين ٣: ١٢-١٣' },
  { q: 'الله حكم على الحية إنها تمشي على رجليها.', ok: false, why: 'الحكم كان إن الحية تمشي على بطنها وتأكل ترابًا.', ref: 'تكوين ٣: ١٤' },
  { q: 'نوح كان عمره خمس مئة سنة لما صار الطوفان.', ok: false, why: 'نوح كان عمره ست مئة سنة لما صار طوفان المياه على الأرض.', ref: 'تكوين ٧: ٦' },
  { q: 'اللي دخل الفلك كان تمن أشخاص: نوح وامرأته وبنوه التلاتة ونساؤهم.', ok: true, why: 'دخل ثمانية أشخاص: نوح وامرأته وبنوه الثلاثة ونساؤهم الثلاث.', ref: 'تكوين ٧: ٧،١٣' },
  { q: 'الرب هو اللي أغلق باب الفلك على نوح.', ok: true, why: 'النص بيقول: «وأغلق الرب عليه».', ref: 'تكوين ٧: ١٦' },
  { q: 'المطر في الطوفان استمر أربعين يوم وأربعين ليلة.', ok: true, why: 'كان المطر على الأرض أربعين يومًا وأربعين ليلة، والمياه تعاظمت مئة وخمسين يومًا.', ref: 'تكوين ٧: ١٢،٢٤' },
  { q: 'الله قال لنوح ياخد من كل الحيوانات اتنين اتنين بس.', ok: false, why: 'من البهائم الطاهرة سبعة سبعة ذكرًا وأنثى، ومن غير الطاهرة اثنين.', ref: 'تكوين ٧: ٢' },
  { q: 'علامة ميثاق الله مع نوح هي القوس في السحاب.', ok: true, why: 'علامة الميثاق قوس الله في السحاب، وكلما ظهرت يذكر الله ميثاقه الأبدي.', ref: 'تكوين ٩: ١٢-١٧' },
  { q: 'نوح لعن ابنه حام.', ok: false, why: 'اللعنة في كلام نوح اتوجهت لكنعان بن حام، مش لحام نفسه.', ref: 'تكوين ٩: ٢٢،٢٥' },
  { q: 'حام هو أبو كنعان.', ok: true, why: 'بنو نوح اللي خرجوا من الفلك: سام وحام ويافث، وحام هو أبو كنعان.', ref: 'تكوين ٩: ١٨' },
  { q: 'الناس بنت البرج في شنعار علشان تصلي فيه لله.', ok: false, why: 'بنوا المدينة والبرج علشان يصنعوا لأنفسهم اسمًا وميتبددوش على وجه الأرض.', ref: 'تكوين ١١: ٤' },
  { q: 'المدينة والبرج اتبنوا في أرض شنعار، والمكان اتسمّى بابل.', ok: true, why: 'دُعي اسمها بابل لأن الرب هناك بلبل لسان كل الأرض.', ref: 'تكوين ١١: ٢،٩' },
  { q: 'ساراي امرأة أبرام كان عندها ولاد كتير.', ok: false, why: 'النص بيقول إن ساراي كانت عاقرًا ليس لها ولد.', ref: 'تكوين ١١: ٣٠' },
  { q: 'متوشالح أطول الأعمار في أصحاح مواليد آدم: عاش ٩٦٩ سنة.', ok: true, why: 'متوشالح عاش ٩٦٩ سنة ومات، وهو أطول الأعمار في الأصحاح.', ref: 'تكوين ٥: ٢٧' }
];
const ZG3 = { tf: null, maze: null, ws: null };

function zgTF(root, st) {
  st = st || { ok: 0, n: 0, used: [] };
  const avail = ZTF_POOL.map((x, i) => i).filter(i => !st.used.includes(i));
  const idx = avail.length ? avail[Math.floor(Math.random() * avail.length)] : (st.used = [], Math.floor(Math.random() * ZTF_POOL.length));
  st.used.push(idx);
  const item = ZTF_POOL[idx];
  ZG3.tf = { idx, answered: false };
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p>' + item.q + '</p></div>' +
    '<div class="zg-opts"><div class="game-btn" id="ztfT" role="button">صح</div><div class="game-btn" id="ztfF" role="button">غلط</div></div><div id="ztff"></div>';
  const answer = pick => {
    if (ZG3.tf.answered) return; ZG3.tf.answered = true; st.n++;
    const right = pick === item.ok; if (right) st.ok++;
    const bT = root.querySelector('#ztfT'), bF = root.querySelector('#ztfF');
    const correctBtn = item.ok ? bT : bF, otherBtn = item.ok ? bF : bT;
    correctBtn.classList.add('right');
    otherBtn.classList.add(right ? 'dim' : 'wrong');
    root.querySelector('#ztff').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الإجابة الصح: ' + (item.ok ? 'صح' : 'غلط') + '. ') + item.why + ' <bdi>(' + item.ref + ')</bdi></p>' +
      '<div class="game-actions"><span class="game-btn" id="ztfn" role="button">السؤال اللي بعده</span></div>';
    root.querySelector('#ztfn').onclick = () => zgTF(root, st);
  };
  root.querySelector('#ztfT').onclick = () => answer(true);
  root.querySelector('#ztfF').onclick = () => answer(false);
}

/* ---------- متاهة الفلك ---------- */
/* متاهة بتكبر وتتعقّد مع كل فوز: طرق متفرعة، طرق مقفولة، وأكتر من طريق للفلك. حركة بالأسهم أو بسحب متصل على المتاهة. */
function mzGenerate(N) {
  const cells = [];
  for (let y = 0; y < N; y++) { const row = []; for (let x = 0; x < N; x++) row.push({ v: false, w: [true, true, true, true] }); cells.push(row); }
  const stack = [[0, 0]]; cells[0][0].v = true;
  const DIRS = [[0, -1, 0, 2], [1, 0, 1, 3], [0, 1, 2, 0], [-1, 0, 3, 1]];
  while (stack.length) {
    const [x, y] = stack[stack.length - 1];
    const opts = DIRS.filter(d => { const nx = x + d[0], ny = y + d[1]; return nx >= 0 && ny >= 0 && nx < N && ny < N && !cells[ny][nx].v; });
    if (!opts.length) { stack.pop(); continue; }
    const d = opts[Math.floor(Math.random() * opts.length)];
    const nx = x + d[0], ny = y + d[1];
    cells[y][x].w[d[2]] = false; cells[ny][nx].w[d[3]] = false;
    cells[ny][nx].v = true; stack.push([nx, ny]);
  }
  /* فتح كام جدار تاني عشان يبقى فيه أكتر من طريق وحلقات تلف */
  let extra = Math.round(N * N * 0.07);
  for (let t = 0; t < 400 && extra > 0; t++) {
    const x = Math.floor(Math.random() * N), y = Math.floor(Math.random() * N), d = DIRS[Math.floor(Math.random() * 4)];
    const nx = x + d[0], ny = y + d[1];
    if (nx < 0 || ny < 0 || nx >= N || ny >= N || !cells[y][x].w[d[2]]) continue;
    cells[y][x].w[d[2]] = false; cells[ny][nx].w[d[3]] = false; extra--;
  }
  return cells;
}
/* عدد الطرق المختلفة (من غير رجوع) للفلك + عدد الأفرع المقفولة: بنستخدمهم للاختبار */
function mzStats(cells, N) {
  const open = (x, y) => { const c = cells[y][x], r = []; if (!c.w[0]) r.push([x, y - 1]); if (!c.w[1]) r.push([x + 1, y]); if (!c.w[2]) r.push([x, y + 1]); if (!c.w[3]) r.push([x - 1, y]); return r; };
  let dead = 0, fork = 0;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const n = open(x, y).length; if (n === 1 && !(x === 0 && y === 0) && !(x === N - 1 && y === N - 1)) dead++; if (n >= 3) fork++; }
  const dist = [], q = [[0, 0]]; for (let y = 0; y < N; y++) dist.push(new Array(N).fill(-1)); dist[0][0] = 0;
  while (q.length) { const [x, y] = q.shift(); open(x, y).forEach(([a, b]) => { if (dist[b][a] < 0) { dist[b][a] = dist[y][x] + 1; q.push([a, b]); } }); }
  return { dead, fork, shortest: dist[N - 1][N - 1] };
}
function mzNew(root, st) {
  st = st || { won: 0, tries: 0 };
  const N = Math.min(11 + 2 * st.won, 17);
  let cells, stats, tries = 0;
  do { cells = mzGenerate(N); stats = mzStats(cells, N); tries++; } while (tries < 30 && stats.shortest < N * 1.6);
  const mz = { cells, N, stats, px: 0, py: 0, gx: N - 1, gy: N - 1, moves: 0, over: false };
  ZG3.maze = mz; st.tries++;
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.won) + '</p>' +
    '<canvas id="mzCv" width="360" height="360" style="width:100%;max-width:360px;display:block;margin:8px auto;touch-action:none"></canvas>' +
    '<div class="snake-pad" style="display:grid;grid-template-columns:repeat(3,64px);gap:6px;justify-content:center;direction:ltr">' +
    '<span></span><span class="game-btn" id="mzU" role="button">↑</span><span></span>' +
    '<span class="game-btn" id="mzL" role="button">←</span><span class="game-btn" id="mzD" role="button">↓</span><span class="game-btn" id="mzR" role="button">→</span></div>' +
    '<div id="mzf"></div>';
  const cv = root.querySelector('#mzCv');
  const trail = new Set(['0,0']);
  const draw = () => {
    const ctx = cv.getContext('2d'), s = cv.width / N, css = getComputedStyle(document.documentElement);
    const gold = css.getPropertyValue('--gold').trim() || '#e3b257';
    ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = 'rgba(227,178,87,.10)';
    trail.forEach(k => { const [x, y] = k.split(',').map(Number); ctx.fillRect(x * s, y * s, s, s); });
    ctx.strokeStyle = 'rgba(160,160,170,.8)'; ctx.lineWidth = 2; ctx.lineCap = 'round';
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const c = mz.cells[y][x], X = x * s, Y = y * s;
      ctx.beginPath();
      if (c.w[0]) { ctx.moveTo(X, Y); ctx.lineTo(X + s, Y); }
      if (c.w[1]) { ctx.moveTo(X + s, Y); ctx.lineTo(X + s, Y + s); }
      if (c.w[2]) { ctx.moveTo(X, Y + s); ctx.lineTo(X + s, Y + s); }
      if (c.w[3]) { ctx.moveTo(X, Y); ctx.lineTo(X, Y + s); }
      ctx.stroke();
    }
    const gx = (mz.gx + .5) * s, gy = (mz.gy + .5) * s;
    ctx.fillStyle = '#8a5a2b';
    ctx.beginPath(); ctx.moveTo(gx - s * .32, gy + s * .05); ctx.lineTo(gx + s * .32, gy + s * .05); ctx.lineTo(gx + s * .2, gy + s * .28); ctx.lineTo(gx - s * .2, gy + s * .28); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#a97b4f'; ctx.fillRect(gx - s * .16, gy - s * .2, s * .32, s * .24);
    ctx.beginPath(); ctx.moveTo(gx - s * .2, gy - s * .2); ctx.lineTo(gx + s * .2, gy - s * .2); ctx.lineTo(gx, gy - s * .36); ctx.closePath(); ctx.fill();
    ctx.fillStyle = gold; ctx.beginPath(); ctx.arc((mz.px + .5) * s, (mz.py + .5) * s, s * .3, 0, 7); ctx.fill();
    ctx.fillStyle = '#1a1a2e'; ctx.font = 'bold ' + Math.round(s * .42) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('ن', (mz.px + .5) * s, (mz.py + .55) * s);
  };
  const move = (dx, dy) => {
    if (mz.over) return false;
    const c = mz.cells[mz.py][mz.px];
    if ((dx === 1 && c.w[1]) || (dx === -1 && c.w[3]) || (dy === 1 && c.w[2]) || (dy === -1 && c.w[0])) return false;
    mz.px += dx; mz.py += dy; mz.moves++; trail.add(mz.px + ',' + mz.py);
    if (mz.px === mz.gx && mz.py === mz.gy) {
      mz.over = true; st.won++;
      root.querySelector('#mzf').innerHTML = '<p class="advice-src">وصل نوح للفلك ✓ «وأغلق الرب عليه» (تكوين ٧: ١٦)</p><div class="game-actions"><span class="game-btn" id="mzn" role="button">متاهة أصعب</span></div>';
      root.querySelector('#mzn').onclick = () => mzNew(root, st);
    }
    draw(); return true;
  };
  mz.move = move;
  root.querySelector('#mzU').onclick = () => move(0, -1);
  root.querySelector('#mzD').onclick = () => move(0, 1);
  root.querySelector('#mzL').onclick = () => move(-1, 0);
  root.querySelector('#mzR').onclick = () => move(1, 0);
  /* سحب متصل: كل ما الصباع يبعد نص خانة في اتجاه، نوح يتحرك خانة */
  let ax = 0, ay = 0, dragging = false;
  cv.addEventListener('pointerdown', e => { dragging = true; ax = e.clientX; ay = e.clientY; try { cv.setPointerCapture(e.pointerId); } catch (_) {} });
  cv.addEventListener('pointermove', e => {
    if (!dragging) return;
    const step = cv.getBoundingClientRect().width / N * 0.55;
    for (let k = 0; k < 4; k++) {
      const dx = e.clientX - ax, dy = e.clientY - ay;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < step) break;
      if (Math.abs(dx) > Math.abs(dy)) { const sx = dx > 0 ? 1 : -1; move(sx, 0); ax += sx * step * 1.8; }
      else { const sy = dy > 0 ? 1 : -1; move(0, sy); ay += sy * step * 1.8; }
    }
  });
  const end = () => { dragging = false; };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  draw();
}

/* ---------- دوّر على الكلمات ---------- */
const ZWS_BANK = ['نوح', 'الفلك', 'آدم', 'حواء', 'قايين', 'هابيل', 'شيث', 'أخنوخ', 'سام', 'حام', 'يافث', 'كنعان', 'بابل', 'شنعار', 'أبرام', 'ساراي', 'لوط', 'تارح', 'حاران', 'أور'];
const ZWS_N = 9, ZWS_LETTERS = 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي';
function zwsNew(root, st) {
  st = st || { done: 0 };
  const N = ZWS_N;
  const words = zgShuffle(ZWS_BANK).filter(w => w.length <= N).slice(0, 7);
  const grid = []; for (let y = 0; y < N; y++) grid.push(new Array(N).fill(''));
  const placed = [];
  const DIRS = [[1, 0], [0, 1], [1, 1], [-1, 1], [-1, 0], [0, -1], [-1, -1], [1, -1]];
  for (const w of words) {
    let okSpot = null;
    for (let tries = 0; tries < 300 && !okSpot; tries++) {
      const d = DIRS[Math.floor(Math.random() * DIRS.length)];
      const x0 = Math.floor(Math.random() * N), y0 = Math.floor(Math.random() * N);
      const xe = x0 + d[0] * (w.length - 1), ye = y0 + d[1] * (w.length - 1);
      if (xe < 0 || xe >= N || ye < 0 || ye >= N) continue;
      let fits = true;
      for (let i = 0; i < w.length; i++) { const x = x0 + d[0] * i, y = y0 + d[1] * i; if (grid[y][x] && grid[y][x] !== w[i]) { fits = false; break; } }
      if (fits) okSpot = { x0, y0, d };
    }
    if (!okSpot) continue;
    for (let i = 0; i < w.length; i++) grid[okSpot.y0 + okSpot.d[1] * i][okSpot.x0 + okSpot.d[0] * i] = w[i];
    placed.push({ w, x0: okSpot.x0, y0: okSpot.y0, dx: okSpot.d[0], dy: okSpot.d[1] });
  }
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!grid[y][x]) grid[y][x] = ZWS_LETTERS[Math.floor(Math.random() * ZWS_LETTERS.length)];
  const ws = { grid, placed, found: [] };
  ZG3.ws = ws;
  root.innerHTML = '<p class="advice-src zg-score"><span id="zwsc">٠</span> / ' + toArabicDigits(placed.length) + '</p>' +
    '<div class="zws-grid" id="zwsg" dir="rtl" style="touch-action:none;user-select:none;-webkit-user-select:none"></div>' +
    '<div class="zws-list" id="zwsl">' + placed.map(p => '<span class="zws-w" data-w="' + p.w + '">' + p.w + '</span>').join('') + '</div><div id="zwsf"></div>';
  const g = root.querySelector('#zwsg');
  const cellAt = [];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const c = document.createElement('div'); c.className = 'zws-cell'; c.textContent = grid[y][x];
    g.appendChild(c); cellAt.push(c);
  }
  const hitCell = (px, py) => {
    const r = g.getBoundingClientRect();
    for (let i = 0; i < cellAt.length; i++) { const b = cellAt[i].getBoundingClientRect(); if (px >= b.left - 1.5 && px <= b.right + 1.5 && py >= b.top - 1.5 && py <= b.bottom + 1.5) return { x: i % N, y: Math.floor(i / N) }; }
    return null;
  };
  /* من أول حرف، الخط بيتثبّت على أقرب اتجاه من ٨ اتجاهات حسب مكان صباعك */
  const lineTo = (a, p) => {
    const b = cellAt[a.y * N + a.x].getBoundingClientRect(), cx = (b.left + b.right) / 2, cy = (b.top + b.bottom) / 2;
    const b2 = cellAt[1].getBoundingClientRect(), b0 = cellAt[0].getBoundingClientRect(), b9 = cellAt[N].getBoundingClientRect();
    const pw = Math.abs(b0.left - b2.left) || b.width, ph = Math.abs(b9.top - b0.top) || b.height;
    const rtl = getComputedStyle(g).direction === 'rtl' ? -1 : 1, ux = rtl * (p.x - cx) / pw, uy = (p.y - cy) / ph;
    if (Math.hypot(ux, uy) < 0.6) return [[a.x, a.y]];
    const k = Math.round(Math.atan2(uy, ux) / (Math.PI / 4)), dx = Math.round(Math.cos(k * Math.PI / 4)), dy = Math.round(Math.sin(k * Math.PI / 4));
    const len = Math.max(1, Math.round((ux * dx + uy * dy) / (dx * dx + dy * dy)));
    const out = [[a.x, a.y]];
    for (let i = 1; i <= len; i++) { const x = a.x + dx * i, y = a.y + dy * i; if (x < 0 || y < 0 || x >= N || y >= N) break; out.push([x, y]); }
    return out;
  };
  let start = null, cur = [];
  const paint = line => { cellAt.forEach(c => c.classList.remove('sel')); line.forEach(([x, y]) => cellAt[y * N + x].classList.add('sel')); cur = line; };
  g.addEventListener('pointerdown', e => { const c = hitCell(e.clientX, e.clientY); if (!c) return; start = c; try { g.setPointerCapture(e.pointerId); } catch (_) {} paint([[c.x, c.y]]); e.preventDefault(); });
  g.addEventListener('pointermove', e => { if (!start) return; paint(lineTo(start, { x: e.clientX, y: e.clientY })); });
  const finish = () => {
    if (!start) return; start = null;
    const line = cur; cellAt.forEach(c => c.classList.remove('sel')); cur = [];
    if (line.length < 2) return;
    const str = line.map(([x, y]) => grid[y][x]).join('');
    const hit = ws.placed.find(p => !ws.found.includes(p.w) && (p.w === str || p.w === str.split('').reverse().join('')));
    if (!hit) return;
    ws.found.push(hit.w);
    line.forEach(([x, y]) => cellAt[y * N + x].classList.add('found'));
    const tag = root.querySelector('.zws-w[data-w="' + hit.w + '"]'); if (tag) tag.classList.add('found');
    root.querySelector('#zwsc').textContent = toArabicDigits(ws.found.length);
    if (ws.found.length === ws.placed.length) {
      st.done++;
      root.querySelector('#zwsf').innerHTML = '<p class="advice-src">لاقيتهم كلهم ✓</p><div class="game-actions"><span class="game-btn" id="zwsn" role="button">شبكة جديدة</span></div>';
      root.querySelector('#zwsn').onclick = () => zwsNew(root, st);
    }
  };
  g.addEventListener('pointerup', finish); g.addEventListener('pointercancel', () => { start = null; cellAt.forEach(c => c.classList.remove('sel')); });
}

/* ---------- لاقي الاختلافات: مشاهد مولّدة بالذكاء الاصطناعي، ٦ اختلافات في كل مشهد، الضغط من أي صورة ---------- */
/* x,y,نصف القطر كنسبة من عرض الصورة (y من عرضها هي كمان) */
const ZSD_SCENES = {"sd1": [[0.8771, 0.0856, 0.106], [0.366, 0.2072, 0.0825], [0.7486, 0.2376, 0.0742], [0.0552, 0.6768, 0.0631], [0.808, 0.6326, 0.077], [0.1727, 0.5594, 0.0797]], "sd2": [[0.8149, 0.1312, 0.1129], [0.2624, 0.0994, 0.0825], [0.1036, 0.5663, 0.0631], [0.9392, 0.6008, 0.0659], [0.5318, 0.6837, 0.0714], [0.5939, 0.3674, 0.0659]], "sd3": [[0.9047, 0.0483, 0.0852], [0.8425, 0.3619, 0.0742], [0.3729, 0.1865, 0.0922], [0.5801, 0.7113, 0.0687], [0.6215, 0.145, 0.0604], [0.6975, 0.5939, 0.0714]]};
const ZSD_ORDER = { q: [] };
function zsdNew(root, st) {
  st = st || { done: 0 };
  if (!ZSD_ORDER.q.length) ZSD_ORDER.q = zgShuffle(Object.keys(ZSD_SCENES));
  const key = ZSD_ORDER.q.pop(), diffs = ZSD_SCENES[key], found = [];
  ZG3.sd = { key, diffs, found };
  const imgBox = id => '<div class="zsd-img" id="' + id + '"><img src="img/' + key + '_' + id.slice(-1).toLowerCase() + '.jpg" alt="" draggable="false"><svg class="zsd-mk" viewBox="0 0 100 75" preserveAspectRatio="none"></svg></div>';
  root.innerHTML = '<p class="advice-src zg-score"><b id="zsdc">٠</b> / ' + toArabicDigits(diffs.length) + '</p>' + imgBox('zsdA') + imgBox('zsdB') + '<div id="zsdf"></div>';
  const mark = d => root.querySelectorAll('.zsd-mk').forEach(m => m.insertAdjacentHTML('beforeend', '<ellipse cx="' + (d[0] * 100) + '" cy="' + (d[1] * 100) + '" rx="' + (d[2] * 100 * 0.55) + '" ry="' + (d[2] * 100 * 0.55) + '" fill="none" stroke="#2E9E4F" stroke-width="0.9"/>'));
  const onTap = ev => {
    const el = ev.currentTarget, box = el.getBoundingClientRect();
    const x = (ev.clientX - box.left) / box.width, y = (ev.clientY - box.top) / box.width;
    const hit = diffs.find((d, i) => !found.includes(i) && Math.hypot(x - d[0], y - d[1]) <= d[2]);
    const f = root.querySelector('#zsdf');
    if (!hit) { f.textContent = ''; el.classList.add('miss'); setTimeout(() => el.classList.remove('miss'), 250); return; }
    found.push(diffs.indexOf(hit)); mark(hit);
    root.querySelector('#zsdc').textContent = toArabicDigits(found.length);
    if (found.length === diffs.length) {
      st.done++;
      f.innerHTML = '<p class="advice-src">لقيت الاختلافات كلها ✓</p><div class="game-actions"><span class="game-btn" id="zsdn" role="button">مشهد جديد</span></div>';
      root.querySelector('#zsdn').onclick = () => zsdNew(root, st);
    }
  };
  root.querySelectorAll('.zsd-img').forEach(el => el.addEventListener('click', onTap));
}

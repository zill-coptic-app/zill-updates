/* Emerald home skin (trial): switch with localStorage zill.skin = 'emerald' | 'classic'. Default emerald. */
(function () {
  const KEY = 'zill.skin', root = document.documentElement;
  const get = () => (localStorage.getItem(KEY) || 'emerald');
  function apply() { if (get() === 'emerald') root.setAttribute('data-skin', 'emerald'); else root.removeAttribute('data-skin'); }
  window.zSkin = function (v) { if (v) localStorage.setItem(KEY, v === 'classic' ? 'classic' : 'emerald'); apply(); build(); return get(); };
  apply();
  // featured tiles: label, target card id in the (hidden) section grid
  // tile: label (\n = line break), action, icon file. Destinations reuse the app's own routes.
  const TILES = [['الكتاب\nالمقدس', 'card:bible', 'book'], ['الألعاب', 'card:games2', 'gamepad'], ['الصلوات', 'nav:prayers', 'hands'], ['السنكسار', 'card:synax', 'church']];
  function build() {
    const dia = document.getElementById('emDia'), scr = document.getElementById('scr-home');
    if (!dia || !scr) return;
    if (!document.getElementById('emLogo')) {
      const l = document.createElement('div'); l.id = 'emLogo'; l.className = 'em-logo';
      l.innerHTML = '<img class="lg-d" src="img/skin/logo-dark.png" alt="ظل"><img class="lg-l" src="img/skin/logo-light.png" alt="ظل">';
      const g = scr.querySelector('.greet'); if (g) g.parentNode.insertBefore(l, g);
    }
    const ha = document.querySelector('#scr-home .hdr-actions');
    if (ha && !document.getElementById('emSearch')) {
      const b = document.createElement('span'); b.id = 'emSearch'; b.className = 'icon-btn'; b.setAttribute('role', 'button'); b.setAttribute('aria-label', 'بحث في الكتاب المقدس');
      b.innerHTML = '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15.5 15.5 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
      ha.appendChild(b);
    }
    const hqx = document.querySelector('#homeQuote .hq-tx');
    if (hqx) hqx.classList.toggle('em-short', (hqx.textContent || '').trim().length < 40);
    const hq = document.getElementById('homeQuote');
    if (hq && !hq.querySelector('.em-tab')) {
      const t = document.createElement('div'); t.className = 'em-tab';
      t.innerHTML = '<svg class="em-book" viewBox="0 3 64 42" aria-hidden="true"><defs><linearGradient id="emBkL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2a8a70"/><stop offset="1" stop-color="#0c4a3a"/></linearGradient><linearGradient id="emBkR" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a8a70"/><stop offset="1" stop-color="#0c4a3a"/></linearGradient></defs><path d="M2 11C16 5 26 7 32 12c6-5 16-7 30-1v29c-14-6-24-4-30 1-6-5-16-7-30-1Z" fill="#093b2e"/><path d="M5 13c12-4 21-2 26 3v23c-5-4-14-6-26-3Z" fill="url(#emBkL)"/><path d="M59 13c-12-4-21-2-26 3v23c5-4 14-6 26-3Z" fill="url(#emBkR)"/><path d="M8 19c8-2 15-1 20 2M8 25c8-2 15-1 20 2M8 31c8-2 15-1 20 2M56 19c-8-2-15-1-20 2M56 25c-8-2-15-1-20 2M56 31c-8-2-15-1-20 2" fill="none" stroke="#bfe6d4" stroke-opacity=".55" stroke-width="1.3" stroke-linecap="round"/><path d="M3 41c14-6 24-4 29 1 5-5 15-7 29-1" fill="none" stroke="#cfe9dc" stroke-opacity=".7" stroke-width="1.4" stroke-linecap="round"/></svg><span>آية اليوم</span>';
      hq.insertBefore(t, hq.firstChild);
    }
    dia.innerHTML = TILES.map((t, i) => '<div class="em-t em-t' + (i + 1) + '" role="button" data-em="' + t[1] + '"><span class="sq"></span><span class="in"><img src="img/skin/ic-' + t[2] + '.png" alt=""><span class="nm">' + t[0].replace('\n', '<br>') + '</span></span></div>').join('');
  }
  function go(a) {
    const k = a.indexOf(':'), type = a.slice(0, k), id = a.slice(k + 1);
    if (type === 'card') { const c = document.querySelector('#secGrid [data-sec="' + id + '"]'); if (c) c.click(); }
    else if (type === 'nav') { const n = document.querySelector('#bottomNav [data-nav="' + id + '"]'); if (n) n.click(); }
    else if (type === 'sec' && window.zillOpenSection) window.zillOpenSection(id);
  }
  document.addEventListener('click', function (ev) {
    const t = ev.target.closest && ev.target.closest('[data-em]');
    if (t) { go(t.getAttribute('data-em')); return; }
    if (ev.target.closest && ev.target.closest('#emSearch')) { const c = document.querySelector('#secGrid [data-sec="bible"]') || document.querySelector('[data-sec="bible"]'); if (c) c.click(); setTimeout(function () { const i = document.getElementById('bibleSearch'); if (i) i.focus(); }, 700); return; }
    if (ev.target.closest && ev.target.closest('#emMore')) { const s = document.getElementById('scr-home'); s.classList.toggle('em-more-open'); const g = document.getElementById('secGrid'); if (s.classList.contains('em-more-open') && g) g.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  });
  function init() { build(); const g = document.getElementById('secGrid'); if (g) new MutationObserver(build).observe(g, { childList: true }); const q = document.getElementById('hqTx'); if (q) new MutationObserver(build).observe(q, { childList: true, characterData: true, subtree: true }); }
  if (document.readyState !== 'loading') init(); else document.addEventListener('DOMContentLoaded', init);
})();

/* «مين الشخصية؟» — approved 01:33 (user: «ضيفه😂♥»): progressive hints about a
   Bible character, pick the answer, then a short explanation with the
   scriptural reference. Offline; explanations written for this app. */
const GAME = { pool: null, current: null, clueIdx: 0, answered: false };

const GAME_CHARACTERS = [
  { name: 'يوسف الصديق', clues: ['أبويا ادّاني بالطو ملوّن وإخواتي حسدوني.', 'اترميت في بير واتباعت، وبعدين اتسجنت على حاجة معملتهاش.', 'فسّرت أحلام وقمت أدير مصر في سنين الشبع والجوع.'],
    explain: 'يوسف ابن يعقوب، من البير للقصر: ربنا حوّل الأذى لخلاص لعيلته كلها، وقال لإخواته أنتم قصدتم لي شرا، أما الله فقصد به خيرا.',
    ref: { label: 'تكوين ٣٧ · ٣٩ · ٤١ · ٥٠', book: 1, ch: 37 } },
  { name: 'موسى', clues: ['اتحطيت في سفط من البردي على النيل وأنا طفل.', 'شفت عليقة مشتعلة ما بتحترقش وسمعت صوت ربنا منها.', 'قدت شعب إسرائيل وشق ربنا البحر قدامهم، وكتب على اللوحين الكلمات العشر.'],
    explain: 'موسى الكليم، قائد الخروج، اتكلم مع ربنا وجهًا لوجه كصديق.',
    ref: { label: 'خروج ٢ · ٣ · ١٤ · ٢٠ · ٣٤', book: 2, ch: 3 } },
  { name: 'داود', clues: ['كنت راعي غنم صغير في بيت لحم.', 'غلبت جاليات الجبار بمقلاع وخمس حجارة ملسى.', 'كتبت مزامير كتير وبقيت ملك إسرائيل.'],
    explain: 'داود النبي والملك، رجل حسب قلب الله، غلط وتاب وكتب أجمل صلوات التوبة في مزمور ٥٠.',
    ref: { label: '١ صموئيل ١٦ · ١٧', book: 9, ch: 17 } },
  { name: 'دانيال', clues: ['اتخطفت لبابل وأنا شاب ورفضت آكل من أكل الملك.', 'ربنا سدّ بؤ الأسود وأنا في الجب طول الليل.', 'فسّرت الكتابة اللي ظهرت على الحيطة في عزومة بيلشاصر.'],
    explain: 'دانيال النبي، رجل الصلاة: حتى لما الصلاة اتمنعت، فضل يصلي ثلاث مرات في اليوم زي عادته.',
    ref: { label: 'دانيال ١ · ٥ · ٦', book: 27, ch: 6 } },
  { name: 'يونان', clues: ['ربنا بعتني لنينوى وأنا هربت في مركب بالعكس.', 'الحوت بلعني وقعدت في بطنه تلت أيام وصليت من هناك.', 'اتضايقت لما ربنا رحم المدينة اللي تابت.'],
    explain: 'يونان النبي، قصته علامة قيامة المسيح زي ما قال ربنا يسوع نفسه، وبتعلّم إن رحمة ربنا أوسع من حساباتنا.',
    ref: { label: 'يونان ١ · ٢ · ٤', book: 32, ch: 2 } },
  { name: 'إيليا', clues: ['قولت للملك أخآب: لا طل ولا مطر إلا بقولي.', 'نار نزلت من السماء على الذبيحة في جبل الكرمل قدام أنبياء البعل.', 'مركبة وخيل من نار فصلت بيني وبين أليشع، وربنا أصعدني للسماء في العاصفة من غير ما أموت.'],
    explain: 'إيليا التشبيتي، نبي النار والصلاة، وظهر مع موسى على جبل التجلي جنب ربنا يسوع.',
    ref: { label: '١ ملوك ١٧ · ١٨ · ٢ ملوك ٢', book: 11, ch: 18 } },
  { name: 'أيوب', clues: ['كنت غني وأب بنين، وفي يوم واحد خسرت كل حاجة.', 'جسدي اتضرب بالقرح، وأصحابي جم يعزوني وقعدوا معايا ساكتين، وبعدين لاموني.', 'قلت: ربنا أعطى وربنا أخذ، وفي الآخر ربنا زاد عليا ضعف اللي كان معايا.'],
    explain: 'أيوب الصديق، أيقونة الصبر في التجربة: وسط كل اللي حصل، مزنّبش على ربنا ولا قال كلمة غلط فيه.',
    ref: { label: 'أيوب ١ · ٢ · ٤٢', book: 18, ch: 1 } },
  { name: 'إبراهيم', clues: ['ربنا ناداني أسيب أرضي وأهلي وأمشي وراه من غير ما أعرف فين.', 'وعدني إن نسلي يبقى زي نجوم السماء وأنا عجوز من غير عيال.', 'حطيت ابني الوحيد على المذبح طاعة، وربنا فداه بكبش.'],
    explain: 'إبراهيم أبو الآباء وأبو المؤمنين، آمن بالرب فحسبه له برا، وبضيافته استقبل ربنا في بلوطة ممرا.',
    ref: { label: 'تكوين ١٢ · ١٥ · ١٨ · ٢٢', book: 1, ch: 22 } },
  { name: 'نوح', clues: ['ربنا قالي اعمل فلك لأن الطوفان جاي.', 'دخلت أنا وعيلتي الفلك ومعانا من الحيوانات زي ما ربنا أمر.', 'بعد المية ربنا حط قوس قزح في السما علامة عهد.'],
    explain: 'نوح، الرجل البار في جيله، فلكه صار رمز للخلاص، وعهد قوس السحاب لسه بيفكرنا برحمة ربنا.',
    ref: { label: 'تكوين ٦ · ٧ · ٩', book: 1, ch: 6 } },
  { name: 'راعوث', clues: ['كنت موآبية غريبة، ورفضت أسيب حماتي الأرملة نعمي.', 'قولتها: شعبك شعبي وإلهك إلهي.', 'التقطت السنابل ورا الحصادين وبوعز اتجوزني، وبقيت من أجداد المسيح.'],
    explain: 'راعوث، الأمينة في الغربة، من سلسال نسب ربنا يسوع رغم إنها مش من إسرائيل — الباب مفتوح للكل.',
    ref: { label: 'راعوث ١ · ٢ · ٤ · متى ١', book: 8, ch: 1 } },
  { name: 'أستير', clues: ['كنت يتيمة يهودية وبقيت ملكة فارس.', 'خاطرت بحياتي ودخلت على الملك من غير إذن: لو هلكت فهلكت.', 'صومت أنا والشعب، وربنا قلب المؤامرة ونجّى شعبي من الإبادة.'],
    explain: 'أستير الملكة، وقفت قدام الملك بشجاعة، وربنا قلب المؤامرة لخلاص شعبها — ومن يعلم إن كنت لوقت مثل هذا وصلت إلى الملك.',
    ref: { label: 'أستير ٢ · ٤ · ٧ · ٨ · ٩', book: 17, ch: 4 } },
  { name: 'يوحنا المعمدان', clues: ['وثبت في بطن أمي أليصابات لما مريم زارتنا.', 'عشت في البرية لابس وبر جمل وبياكل جراد وعسل بري.', 'عمّدت ربنا يسوع في الأردن وقلت: هوذا حمل الله.'],
    explain: 'يوحنا المعمدان والسابق، أعظم مواليد النساء على لسان المسيح، وشهد للنور من سجن هيرودس لحد استشهاده.',
    ref: { label: 'متى ٣ · ١١ · ١٤ · لوقا ١ · يوحنا ١', book: 40, ch: 3 } },
  { name: 'بطرس', clues: ['كنت صياد سمك والمسيح سماني صياد ناس.', 'مشيت على المية ناحية يسوع، وغرقت لما شكيت.', 'أنكرت المسيح تلت مرات قبل ما الديك يصيح، ودمعت وبعدها بشرت يوم الخمسين.'],
    explain: 'بطرس الرسول، الصخرة اللي اتكسرت واتبنت تاني: قصته كلها رجعة بعد السقوط، ورسالته أتحبني أكثر من هؤلاء؟.',
    ref: { label: 'متى ٤ · ١٤ · ١٦ · ٢٦ · يوحنا ٢١ · أعمال ٢', book: 40, ch: 26 } },
  { name: 'بولس', clues: ['كنت بضطهد المسيحيين واسمي شاول الطرسوسي.', 'نور من السماء وقعني على طريق دمشق وسمعت صوت: لماذا تضطهدني؟', 'بقيت رسول الأمم، وكتبت رسائل كتير في العهد الجديد، وبعضها وأنا أسير.'],
    explain: 'بولس الرسول، المختار رغم ماضيه: نعمة الله اللي أنا عليه مش فاضية، ومن ماضيه خرج رسول الأمم.',
    ref: { label: 'أعمال ٩ · رومية ١١ · ١ كورنثوس ١٥ · أفسس ٣', book: 44, ch: 9 } },
  { name: 'توما', clues: ['كنت واحد من التلاميذ الاتناشر.', 'ما صدقتش القيامة غير لما أشوف أثر المسامير وأحط إيدي في جنبه.', 'لما التلاميذ قالولي «رأينا الرب» ما صدقتش، وبعد أسبوع لما شفته قولت له: ربي وإلهي.'],
    explain: 'توما الرسول، شكه قاده لأعظم اعتراف: ربي وإلهي. وردّ المسيح: طوبى للذين آمنوا ولم يروا.',
    ref: { label: 'يوحنا ٢٠', book: 43, ch: 20 } },
  { name: 'زكا', clues: ['كنت رئيس عشار، والناس شايفاني خاطي.', 'قصير في القامة، فطلعت على جميزة عشان أشوف يسوع وهو عدي.', 'يسوع قالي: انزل يا زكا لأنه ينبغي أن أمكث اليوم في بيتك، ووعدت أرد أربعة أضعاف لو كنت ظلمت حد.'],
    explain: 'زكا، اللقاء اللي غيّر الجيب والقلب: اليوم حصل خلاص لهذا البيت. التوبة الحقيقية بتبان في التصرف.',
    ref: { label: 'لوقا ١٩', book: 42, ch: 19 } }
];

const GAME_KEY = 'zill.game.seen';

function gameLoadSeen() { try { return JSON.parse(localStorage.getItem(GAME_KEY) || '[]'); } catch (e) { return []; } }
function gameSaveSeen(s) { localStorage.setItem(GAME_KEY, JSON.stringify(s)); }

/* Portrait mode: the answer options are public-domain pictures with the name under them (clues stay text, so the picture never gives the answer away).
   Only characters with a vetted picture take part; the others return when their picture is found. */
const GAME_IMG = { 'موسى': 'moses', 'داود': 'david', 'دانيال': 'daniel', 'يونان': 'jonah', 'إيليا': 'elijah', 'أيوب': 'job', 'راعوث': 'ruth', 'يوحنا المعمدان': 'john_baptist', 'بطرس': 'peter', 'بولس': 'paul', 'توما': 'thomas', 'زكا': 'zacchaeus' };
const GAME_POOL = () => GAME_CHARACTERS.map((c, i) => i).filter(i => GAME_IMG[GAME_CHARACTERS[i].name]);
/* Text bank (user file, 500 items): loaded lazily, text-only options. Old portrait characters keep numeric seen entries; bank entries are stored as their id strings in the same seen list. */
let GAME_BANK = null;
function gameBankLoad() {
  if (GAME_BANK !== null) return Promise.resolve(GAME_BANK);
  return packLoadJson('game-char-bank', 'content/packs/game-char-bank.json').then(p => { GAME_BANK = (p && p.items && p.items.length) ? p.items : []; return GAME_BANK; }).catch(() => { GAME_BANK = []; return GAME_BANK; });
}
function gameChar(cur) {
  if (typeof cur === 'number') return GAME_CHARACTERS[cur];
  const it = (GAME_BANK || []).find(x => x.id === cur); if (!it) return null;
  return { name: it.a, clues: [it.q].concat(it.h), explain: it.e, ref: { label: it.l, book: it.b, ch: it.c }, text: true, diff: it.d };
}
function gameShuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const gameTok = s => s.split(' ')[0];
function gameNext() {
  const seen = gameLoadSeen();
  const bank = GAME_BANK || [];
  const POOL = GAME_POOL().concat(bank.map(x => x.id));
  let avail = POOL.filter(i => !seen.includes(i));
  if (!avail.length) { gameSaveSeen([]); avail = POOL.slice(); }
  const idx = avail[Math.floor(Math.random() * avail.length)];
  GAME.current = idx; GAME.clueIdx = 0; GAME.answered = false;
  gameSaveSeen(seen.concat(idx));
  if (typeof idx === 'number') {
    const others = gameShuffle(GAME_POOL().filter(i => i !== idx));
    const opts = gameShuffle(others.slice(0, 3).concat(idx));
    return { character: GAME_CHARACTERS[idx], options: opts.map(i => GAME_CHARACTERS[i].name) };
  }
  const c = gameChar(idx), it = bank.find(x => x.id === idx), clueText = (it.q + ' ' + it.h.join(' '));
  const ok = x => x.id !== idx && gameTok(x.a) !== gameTok(it.a) && !it.a.includes(gameTok(x.a)) && !clueText.includes(gameTok(x.a)) && (x.b <= 39) === (it.b <= 39);
  let cand = gameShuffle(bank.filter(ok));
  const same = cand.filter(x => x.d === it.d); // prefer the same difficulty
  const pick = []; const names = new Set([it.a]);
  same.concat(cand).forEach(x => { if (pick.length < 3 && !names.has(x.a) && !pick.some(p => gameTok(p) === gameTok(x.a))) { pick.push(x.a); names.add(x.a); } });
  return { character: c, options: gameShuffle(pick.concat(it.a)), text: true };
}

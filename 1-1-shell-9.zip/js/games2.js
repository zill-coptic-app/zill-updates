/* More games: complete the verse, order the words, memory cards. Verses come from the bundled Bible pack (plain text). */
const ZG = { stats: {} };
function zgPool() {
  const out = [], pack = BIBLE.pack; if (!pack) return out;
  VERSE_REFS.forEach(([b, c, v]) => { const bk = pack.books.find(x => x.id === b), t = bk && bk.chapters[String(c)] && bk.chapters[String(c)][String(v)];
    if (!t) return; const words = t.split(/\s+/).filter(w => /[\u0621-\u064A]/.test(w));
    if (words.length >= 5 && words.length <= 14) out.push({ ref: bk.name + ' <bdi dir="ltr">' + toArabicDigits(c) + ':' + toArabicDigits(v) + '</bdi>', text: t, words }); });
  return out;
}
function zgShuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const zgClean = w => w.replace(/[^\u0621-\u064A]/g, '');

const ZGC = { bank: null, q: [] };
function zgComplete(root, st) {
  st = st || { ok: 0, n: 0 };
  if (ZGC.bank === null) { ZGC.bank = false; Promise.all([packLoadJson('game-complete-bank', 'content/packs/game-complete-bank.json'), packLoadJson('game-complete-meanings', 'content/packs/game-complete-meanings.json').catch(() => null)]).then(([p, mp]) => { ZGC.meanings = (mp && mp.m) || {}; ZGC.bank = (p && p.items && p.items.length) ? p.items : false; zgComplete(root, st); }).catch(() => { ZGC.bank = false; zgComplete(root, st); }); return; }
  if (Array.isArray(ZGC.bank)) return zgCompleteBank(root, st); const pool = zgPool(), v = pool[Math.floor(Math.random() * pool.length)];
  const idx = zgShuffle(v.words.map((w, i) => i).filter(i => i > 0 && zgClean(v.words[i]).length >= 4))[0];
  const ans = v.words[idx], clean = zgClean(ans);
  const others = zgShuffle([].concat(...pool.filter(x => x !== v).map(x => x.words)).filter(w => zgClean(w).length >= 3 && zgClean(w) !== clean).map(zgClean));
  ZG.cur = { ans: clean, text: v.text };
  const opts = zgShuffle([clean].concat(Array.from(new Set(others)).slice(0, 3)));
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p id="zgv">' + v.words.map((w, i) => i === idx ? '<span class="zg-blank">_____</span>' : w).join(' ') + '</p></div><div class="zg-opts" id="zgo"></div><div id="zgf"></div>';
  const o = root.querySelector('#zgo');
  opts.forEach(t => { const b = document.createElement('div'); b.className = 'game-btn'; b.setAttribute('role', 'button'); b.textContent = t;
    b.onclick = () => { if (root._done) return; root._done = 1; st.n++; const right = t === clean; if (right) st.ok++; zxpQ('verse', right);
      o.querySelectorAll('.game-btn').forEach(x => x.classList.add(x.textContent === clean ? 'right' : (x === b ? 'wrong' : 'dim')));
      root.querySelector('#zgv').textContent = v.text;
      root.querySelector('#zgf').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الكلمة الصح: ' + clean + ' · ') + v.ref + '</p><div class="game-actions"><span class="game-btn" id="zgn" role="button">الآية اللي بعدها</span></div>';
      root.querySelector('#zgn').onclick = () => { root._done = 0; zgComplete(root, st); }; };
    o.appendChild(b); });
}

/* Question bank (user-provided, 500 items): the start of the verse, four endings; the full verse, reference and the bank's explanation show after the answer. */
function zgCompleteBank(root, st) {
  if (!ZGC.q.length) ZGC.q = zgShuffle(ZGC.bank.map((_, i) => i));
  const it = ZGC.bank[ZGC.q.pop()], opts = zgShuffle(it.o.map((t, i) => ({ t, ok: i === it.a })));
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p id="zgv">' + it.s + ' <span class="zg-blank">_____</span></p></div><div class="zg-opts" id="zgo"></div><div id="zgf"></div>';
  const o = root.querySelector('#zgo'), ref = it.b + ' <bdi dir="ltr">' + toArabicDigits(it.c) + ':' + toArabicDigits(it.v) + '</bdi>';
  let done = false;
  opts.forEach(x => { const b = document.createElement('div'); b.className = 'game-btn'; b.setAttribute('role', 'button'); b.textContent = x.t;
    b.onclick = () => { if (done) return; done = true; st.n++; if (x.ok) st.ok++; zxpQ('verse', !!x.ok);
      o.querySelectorAll('.game-btn').forEach((y, i) => y.classList.add(opts[i].ok ? 'right' : (y === b ? 'wrong' : 'dim')));
      root.querySelector('#zgv').textContent = it.t;
      root.querySelector('#zgf').innerHTML = '<p class="advice-src">' + (x.ok ? 'صح ✓ ' : 'الإجابة الصح مظللة · ') + ref + '</p><p class="advice-src">' + (ZGC.meanings && ZGC.meanings[it.id] ? 'شرح مختصر للمعنى: ' + ZGC.meanings[it.id] : 'معلومة عن الآية: ' + it.x) + '</p><div class="game-actions"><span class="game-btn" id="zgn" role="button">الآية اللي بعدها</span></div>';
      root.querySelector('#zgn').onclick = () => zgComplete(root, st); };
    o.appendChild(b); });
}

const ZGO = { bank: null, q: [] };
function zgOrder(root, st) {
  st = st || { ok: 0, n: 0 };
  if (ZGO.bank === null) { ZGO.bank = false; packLoadJson('game-order-bank', 'content/packs/game-order-bank.json').then(p => { ZGO.bank = (p && p.items && p.items.length) ? p.items : false; zgOrder(root, st); }).catch(() => { ZGO.bank = false; zgOrder(root, st); }); return; }
  if (ZGO.bank === false && !ZGO._ld) { /* bank load pending or failed: fall through to the Bible-pool version below */ }
  if (Array.isArray(ZGO.bank)) return zgOrderBank(root, st);
  const pool = zgPool().filter(x => x.words.length <= 9), v = pool[Math.floor(Math.random() * pool.length)];
  const order = v.words.map(zgClean).filter(Boolean); let mix = zgShuffle(order); if (mix.join(' ') === order.join(' ')) mix = order.slice().reverse();
  let picked = [];
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="zg-ans" id="zga"></div><div class="zg-opts" id="zgo"></div><div id="zgf"></div>';
  const ans = root.querySelector('#zga'), o = root.querySelector('#zgo'), f = root.querySelector('#zgf');
  const draw = () => { ans.textContent = picked.map(i => mix[i]).join(' ') || 'اضغط الكلمة الأولى…'; o.innerHTML = '';
    mix.forEach((w, i) => { if (picked.includes(i)) return; const b = document.createElement('div'); b.className = 'game-btn'; b.setAttribute('role', 'button'); b.textContent = w;
      b.onclick = () => { picked.push(i); if (picked.length === mix.length) finish(); else draw(); }; o.appendChild(b); });
    f.innerHTML = picked.length && picked.length < mix.length ? '<div class="game-actions"><span class="game-btn ghost" id="zgu" role="button">تراجع</span></div>' : '';
    const u = f.querySelector('#zgu'); if (u) u.onclick = () => { picked.pop(); draw(); }; };
  const finish = () => { st.n++; const right = picked.map(i => mix[i]).join(' ') === order.join(' '); if (right) st.ok++; zxpQ('order', right); ans.textContent = picked.map(i => mix[i]).join(' '); o.innerHTML = '';
    f.innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الترتيب الصح: ') + (right ? '' : v.text + ' · ') + v.ref + '</p><div class="game-actions"><span class="game-btn" id="zgn" role="button">الآية اللي بعدها</span></div>';
    root.querySelector('#zgn').onclick = () => zgOrder(root, st); };
  draw();
}
/* Question bank (user-provided, 500 items): fragments are shuffled, the player taps them in order; the verse, reference and the bank's explanation show after the answer. */
function zgOrderBank(root, st) {
  if (!ZGO.q.length) ZGO.q = zgShuffle(ZGO.bank.map((_, i) => i));
  const it = ZGO.bank[ZGO.q.pop()], order = it.o.slice(); let mix = zgShuffle(it.f); if (mix.join('\u0001') === order.join('\u0001')) mix = order.slice().reverse();
  let picked = [];
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="zg-ans" id="zga"></div><div class="zg-opts" id="zgo"></div><div id="zgf"></div>';
  const ans = root.querySelector('#zga'), o = root.querySelector('#zgo'), f = root.querySelector('#zgf');
  const ref = it.b + ' <bdi dir="ltr">' + toArabicDigits(it.c) + ':' + toArabicDigits(it.v) + '</bdi>';
  const draw = () => { ans.textContent = picked.map(i => mix[i]).join(' ') || 'اضغط الجزء الأول…'; o.innerHTML = '';
    mix.forEach((w, i) => { if (picked.includes(i)) return; const b = document.createElement('div'); b.className = 'game-btn'; b.setAttribute('role', 'button'); b.textContent = w;
      b.onclick = () => { picked.push(i); if (picked.length === mix.length) finish(); else draw(); }; o.appendChild(b); });
    f.innerHTML = picked.length && picked.length < mix.length ? '<div class="game-actions"><span class="game-btn ghost" id="zgu" role="button">تراجع</span></div>' : '';
    const u = f.querySelector('#zgu'); if (u) u.onclick = () => { picked.pop(); draw(); }; };
  const finish = () => { st.n++; const right = picked.map(i => mix[i]).join(' ') === order.join(' '); if (right) st.ok++; zxpQ('order', right); ans.textContent = picked.map(i => mix[i]).join(' '); o.innerHTML = '';
    f.innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الترتيب الصح: ' + it.t + ' · ') + ref + '</p><p class="advice-src">' + it.x + '</p><div class="game-actions"><span class="game-btn" id="zgn" role="button">الآية اللي بعدها</span></div>';
    root.querySelector('#zgn').onclick = () => zgOrder(root, st); };
  draw();
}

function zgMemory(root) {
  const PICS = ['anthony', 'mina', 'paul_hermit', 'barbara', 'george', 'moses_black', 'athanasius', 'cyril'], sy = zgShuffle(PICS).slice(0, 6), deck = zgShuffle(sy.concat(sy)); let open = [], moves = 0, found = 0, lock = false;
  root.innerHTML = '<p class="advice-src"><span id="zgm">٠</span></p><div class="zg-mem" id="zgg"></div><div id="zgf"></div>';
  const g = root.querySelector('#zgg');
  deck.forEach((s, i) => { const c = document.createElement('div'); c.className = 'zg-card'; c.setAttribute('role', 'button'); c.dataset.s = s; c.textContent = '؟';
    c.onclick = () => { if (lock || c.classList.contains('up') || c.classList.contains('done')) return; c.classList.add('up'); c.innerHTML = '<img class="zg-pic" alt="" src="img/people/' + s + '.jpg">'; open.push(c);
      if (open.length === 2) { moves++; root.querySelector('#zgm').textContent = toArabicDigits(moves);
        if (open[0].dataset.s === open[1].dataset.s) { open.forEach(x => x.classList.add('done')); open = []; found++;
          if (found === sy.length) zxpDone('memory'), root.querySelector('#zgf').innerHTML = '<p class="advice-src">خلصت في ' + toArabicDigits(moves) + ' حركة ✓</p><div class="game-actions"><span class="game-btn" id="zgn" role="button">العب تاني</span></div>', root.querySelector('#zgn').onclick = () => zgMemory(root); }
        else { lock = true; setTimeout(() => { open.forEach(x => { x.classList.remove('up'); x.textContent = '؟'; }); open = []; lock = false; }, 700); } } };
    g.appendChild(c); });
}

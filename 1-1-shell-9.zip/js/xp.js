/* ظل: two separate point ledgers (Game XP, Growth XP) + streak + achievements.
   Pure logic, no DOM. Storage is injected (localStorage-like). All values are data tables.
   Local only: nothing here is verified by a server, a user can edit their own device data. */
(function (root) {
  'use strict';
  const GAME_LEVELS = [[1,'البذرة',0],[2,'النابت',100],[3,'الساعي',250],[4,'المثابر',450],[5,'الباحث',700],[6,'المستنير',1000],[7,'المنير',1400],[8,'المتألق',1900],[9,'المتميز',2500],[10,'المنارة',3200]];
  const GROW_LEVELS = [[1,'البداية',0],[2,'المواظب',100],[3,'المتأمل',300],[4,'المثابر',600],[5,'الثابت',1000],[6,'المجتهد',1500],[7,'المتعمق',2100],[8,'رفيق الكلمة',2900]];
  const GAME_PTS = { complete: 20, correct: 5, daily: 30, win: 40, hard: 50, login: 5, ach: 25 };
  const GROW_PTS = { chapter: 20, prayer: 15, verse: 5, goal: 10 };
  /* anti-farming caps per local day (chosen by the app, adjustable data) */
  const GAME_CAPS = { complete: 3, correct: 10 }; // per game id per day
  const STREAK_STEPS = [[1,'بداية الرحلة'],[3,'شارة الاستمرارية'],[7,'أسبوع من المواظبة'],[14,'أسبوعان من الاستمرار'],[30,'شهر من المواظبة'],[100,'إنجاز مميز'],[365,'عام من الاستمرارية']];
  const GOSPELS = { 40: 28, 41: 16, 42: 24, 43: 21 }; // Matthew, Mark, Luke, John chapter counts
  const GAMES = ['who', 'verse', 'order', 'memory', 'snake', 'maze', 'diff', 'tf', 'ws'];
  /* achievements as data: kind game|growth; test(state) -> bool */
  const ACH = [
    { id: 'g_first', kind: 'game', n: 'أول خطوة', d: 'إكمال أول لعبة', t: s => s.g.stats.completed >= 1 },
    { id: 'g_brain', kind: 'game', n: 'العقل اللامع', d: 'الإجابة عن 10 أسئلة متتالية بشكل صحيح', t: s => s.g.stats.bestRun >= 10 },
    { id: 'g_days7', kind: 'game', n: 'المثابر', d: 'اللعب لمدة 7 أيام متتالية', t: s => s.g.stats.bestPlayStreak >= 7 },
    { id: 'g_flawless', kind: 'game', n: 'لا يخطئ', d: 'إنهاء مرحلة دون أي خطأ', t: s => s.g.stats.flawless >= 1 },
    { id: 'g_explorer', kind: 'game', n: 'المستكشف', d: 'تجربة جميع الألعاب الموجودة بالتطبيق', t: s => GAMES.every(x => s.g.stats.tried[x]) },
    { id: 'g_1000', kind: 'game', n: 'جامع النقاط', d: 'الوصول إلى 1000 نقطة خبرة', t: s => s.g.total >= 1000 },
    { id: 'r_first', kind: 'growth', n: 'البداية', d: 'إكمال أول إصحاح', t: s => s.r.chaptersRead >= 1 },
    { id: 'r_d3', kind: 'growth', n: 'المواظب', d: 'إكمال القراءة والصلاة لمدة 3 أيام متتالية', t: s => s.r.longest >= 3 },
    { id: 'r_d7', kind: 'growth', n: 'أسبوع من المواظبة', d: 'إكمال 7 أيام', t: s => s.r.longest >= 7 },
    { id: 'r_c10', kind: 'growth', n: 'قارئ مثابر', d: 'قراءة 10 إصحاحات', t: s => s.r.chaptersRead >= 10 },
    { id: 'r_c30', kind: 'growth', n: 'قارئ متقدم', d: 'قراءة 30 إصحاحًا', t: s => s.r.chaptersRead >= 30 },
    { id: 'r_gospel', kind: 'growth', n: 'رحلة كاملة', d: 'قراءة إنجيل كامل', t: s => s.r.gospelDone },
    { id: 'r_goals30', kind: 'growth', n: 'شهر من المواظبة', d: 'إكمال 30 يومًا من الأهداف اليومية', t: s => s.r.goalDays >= 30 },
    { id: 'r_d365', kind: 'growth', n: 'عام من الاستمرارية', d: 'الوصول إلى 365 يومًا', t: s => s.r.longest >= 365 }
  ];
  const K = { g: 'zill.xp.game', r: 'zill.xp.growth', a: 'zill.xp.ach' };
  const pad = n => (n < 10 ? '0' : '') + n;
  function dkey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function dayNum(k) { const [y, m, d] = k.split('-').map(Number); return Math.round(Date.UTC(y, m - 1, d) / 86400000); }
  function levelOf(table, total) {
    let i = 0; for (let j = 0; j < table.length; j++) if (total >= table[j][2]) i = j;
    const cur = table[i], nxt = table[i + 1] || null;
    return { level: cur[0], name: cur[1], total, from: cur[2], next: nxt ? nxt[2] : null, nextName: nxt ? nxt[1] : null,
      pct: nxt ? Math.floor((total - cur[2]) * 100 / (nxt[2] - cur[2])) : 100, toNext: nxt ? nxt[2] - total : 0 };
  }
  function runLen(days, endKey) { let n = 0, d = dayNum(endKey); while (days[keyFromNum(d)]) { n++; d--; } return n; }
  function keyFromNum(n) { const t = new Date(n * 86400000); return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate()); }
  function longestRun(days) {
    const ks = Object.keys(days).sort(); let best = 0, cur = 0, prev = null;
    ks.forEach(k => { const n = dayNum(k); cur = (prev !== null && n === prev + 1) ? cur + 1 : 1; prev = n; if (cur > best) best = cur; });
    return best;
  }
  function create(storage, nowFn) {
    nowFn = nowFn || (() => new Date());
    function load(key, def) { try { const v = JSON.parse(storage.getItem(key)); return (v && typeof v === 'object') ? Object.assign(def, v) : def; } catch (e) { return def; } }
    const gdef = () => ({ total: 0, log: [], done: {}, stats: { completed: 0, run: 0, bestRun: 0, flawless: 0, tried: {}, playDays: {}, bestPlayStreak: 0, dailyDone: 0, wins: 0 } });
    const rdef = () => ({ total: 0, log: [], done: {}, chapters: {}, days: {}, goalDays: 0, longest: 0 });
    let g = load(K.g, gdef()), r = load(K.r, rdef()), ach = load(K.a, {});
    g.stats = Object.assign(gdef().stats, g.stats);
    function save() {
      const prune = o => { const ks = Object.keys(o).sort(); if (ks.length > 500) ks.slice(0, ks.length - 500).forEach(k => delete o[k]); };
      prune(g.done); prune(r.done);
      g.log = g.log.slice(-200); r.log = r.log.slice(-200);
      storage.setItem(K.g, JSON.stringify(g)); storage.setItem(K.r, JSON.stringify(r)); storage.setItem(K.a, JSON.stringify(ach));
    }
    const today = () => dkey(nowFn());
    const events = [];
    function addG(kind, pts, why) { g.total += pts; g.log.push([today(), kind, pts, why || '']); }
    function addR(kind, pts) { r.total += pts; r.log.push([today(), kind, pts]); }
    function state() { return { g, r }; }
    function refresh() { r.chaptersRead = Object.keys(r.chapters).length; r.gospelDone = Object.keys(GOSPELS).some(b => { for (let c = 1; c <= GOSPELS[b]; c++) if (!r.chapters[b + ':' + c]) return false; return true; }); }
    function checkAch() {
      refresh(); const s = state(); const out = [];
      ACH.forEach(a => {
        if (!ach[a.id] && a.t(s)) {
          ach[a.id] = today(); out.push(a);
          if (a.kind === 'game') addG('ach', GAME_PTS.ach, a.id); // growth achievements give no points: ledgers stay separate
        }
      });
      if (out.length) checkAch(); // a game achievement's own XP may unlock g_1000
      return out;
    }
    function lvlCheck(before, after, table, which, notes) {
      if (levelOf(table, after).level > levelOf(table, before).level) notes.push({ type: 'level', ledger: which, level: levelOf(table, after) });
    }
    function done(res) { return res; }
    /* ---- Game XP ---- */
    function game(ev, gameId, opt) {
      opt = opt || {}; const t = today(), notes = []; const before = g.total; let pts = 0, ok = false;
      if (gameId) g.stats.tried[gameId] = true;
      const cap = (name) => { const k = t + '|' + name + '|' + gameId; g.done[k] = (g.done[k] || 0) + 1; return g.done[k] <= GAME_CAPS[name]; };
      if (ev === 'login') { const k = t + '|login'; if (!g.done[k]) { g.done[k] = 1; pts = GAME_PTS.login; ok = true; } }
      else if (ev === 'complete') {
        g.stats.completed++; g.stats.playDays[t] = true;
        g.stats.bestPlayStreak = Math.max(g.stats.bestPlayStreak, longestRun(g.stats.playDays));
        if (opt.flawless) g.stats.flawless++;
        if (cap('complete')) { pts = GAME_PTS.complete; ok = true; }
      } else if (ev === 'correct') {
        g.stats.run++; g.stats.bestRun = Math.max(g.stats.bestRun, g.stats.run); g.stats.playDays[t] = true;
        if (cap('correct')) { pts = GAME_PTS.correct; ok = true; }
      } else if (ev === 'wrong') { g.stats.run = 0; }
      else if (ev === 'hard') { /* one award per distinct milestone key, never repeatable */ const k = 'hard|' + gameId + '|' + opt.key; if (opt.key && !g.done[k]) { g.done[k] = 1; pts = GAME_PTS.hard; ok = true; } }
      else if (ev === 'daily' || ev === 'win') { /* no daily challenge or challenge mode exists in the app: never triggered */ }
      if (pts) addG(ev, pts, gameId);
      const unlocked = checkAch(); unlocked.forEach(a => notes.push({ type: 'ach', id: a.id, n: a.n }));
      lvlCheck(before, g.total, GAME_LEVELS, 'game', notes);
      save(); return { awarded: ok ? pts : 0, notes, level: levelOf(GAME_LEVELS, g.total) };
    }
    /* ---- Growth XP: user marks completion manually, once per activity per local day ---- */
    function growth(act, opt) {
      opt = opt || {}; const t = today(), notes = []; const before = r.total; let pts = 0;
      const mark = k => { const kk = t + '|' + k; if (r.done[kk]) return false; r.done[kk] = 1; return true; };
      if (act === 'chapter') {
        if (opt.book && opt.chapter) { r.chapters[opt.book + ':' + opt.chapter] = r.chapters[opt.book + ':' + opt.chapter] || t; }
        if (mark('chapter')) { pts += GROW_PTS.chapter; r.days[t] = r.days[t] || {}; r.days[t].chapter = 1; }
      } else if (act === 'prayer') { if (mark('prayer')) { pts += GROW_PTS.prayer; r.days[t] = r.days[t] || {}; r.days[t].prayer = 1; } }
      else if (act === 'verse') { if (mark('verse')) { pts += GROW_PTS.verse; r.days[t] = r.days[t] || {}; r.days[t].verse = 1; } }
      if (pts) addR(act, pts);
      const dd = r.days[t];
      if (dd && dd.chapter && dd.prayer && mark('goal')) { addR('goal', GROW_PTS.goal); dd.goal = 1; pts += GROW_PTS.goal; r.goalDays++; notes.push({ type: 'goal' }); }
      const full = {}; Object.keys(r.days).forEach(k => { if (r.days[k].goal) full[k] = true; });
      r.longest = Math.max(r.longest, longestRun(full));
      const unlocked = checkAch(); unlocked.forEach(a => notes.push({ type: 'ach', id: a.id, n: a.n }));
      lvlCheck(before, r.total, GROW_LEVELS, 'growth', notes);
      save(); return { awarded: pts, notes, level: levelOf(GROW_LEVELS, r.total) };
    }
    function summary() {
      const full = {}; Object.keys(r.days).forEach(k => { if (r.days[k].goal) full[k] = true; });
      const cur = full[today()] ? runLen(full, today()) : runLen(full, keyFromNum(dayNum(today()) - 1));
      refresh(); const gospels = r.gospelDone;
      return { game: { total: g.total, level: levelOf(GAME_LEVELS, g.total), completed: g.stats.completed, ach: ACH.filter(a => a.kind === 'game' && ach[a.id]).length },
        growth: { total: r.total, level: levelOf(GROW_LEVELS, r.total), chapters: Object.keys(r.chapters).length, goalDays: r.goalDays, streak: cur, longest: r.longest, ach: ACH.filter(a => a.kind === 'growth' && ach[a.id]).length, gospelDone: gospels },
        achievements: ACH.map(a => ({ id: a.id, kind: a.kind, n: a.n, d: a.d, done: !!ach[a.id], date: ach[a.id] || null })) };
    }
    return { game, growth, summary, levelOf: (w, n) => levelOf(w === 'game' ? GAME_LEVELS : GROW_LEVELS, n), reload() { g = load(K.g, gdef()); r = load(K.r, rdef()); ach = load(K.a, {}); } };
  }
  const api = { create, GAME_LEVELS, GROW_LEVELS, GAME_PTS, GROW_PTS, GAME_CAPS, STREAK_STEPS, ACH, GOSPELS, GAMES, KEYS: K, levelOf: (w, n) => levelOf(w === 'game' ? GAME_LEVELS : GROW_LEVELS, n) };
  if (typeof module !== 'undefined') module.exports = api; else root.ZXP = api;
})(typeof window !== 'undefined' ? window : globalThis);

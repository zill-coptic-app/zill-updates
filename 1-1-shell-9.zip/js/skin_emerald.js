/* Emerald home skin (trial): switch with localStorage zill.skin = 'emerald' | 'classic'. Default emerald. */
(function () {
  const KEY = 'zill.skin', root = document.documentElement;
  const get = () => (localStorage.getItem(KEY) || 'emerald');
  function apply() { if (get() === 'emerald') root.setAttribute('data-skin', 'emerald'); else root.removeAttribute('data-skin'); }
  window.zSkin = function (v) { if (v) localStorage.setItem(KEY, v === 'classic' ? 'classic' : 'emerald'); apply(); if (window.zRefreshBars) window.zRefreshBars(); build(); return get(); };
  apply();
  window.addEventListener('load', function () { if (window.zRefreshBars) window.zRefreshBars(); });
  // featured tiles: label, target card id in the (hidden) section grid
  // tile: label (\n = line break), action, icon file. Destinations reuse the app's own routes.
  const TILES = [['الكتاب\nالمقدس', 'card:bible', 'book'], ['المنجلية', 'manj:x', 'manj'], ['الصلوات', 'nav:prayers', 'hands'], ['القطمارس', 'card:katameros', 'kat'], ['قسم\nالأطفال', 'card:kids', 'kids']];
  // المنجلية list: existing destinations open; the rest are shown honestly as not added yet
  const MANJ = [['الخولاجي', null], ['الأجبيه', 'agpeya'], ['دلال أسبوع الآلام', null], ['صلوات اللقان', null], ['صلاة القنديل', null], ['صلاة السجدة', null], ['صلوات القسم', null], ['القطمارس', 'katameros'], ['السنكسار اليومي', 'synax'], ['الإبصلمودية السنوية', null], ['الإبصلمودية الكيهكية', null]];
  function openManj() {
    let o = document.getElementById('emManj'); if (o) o.remove();
    o = document.createElement('div'); o.id = 'emManj'; o.className = 'em-manj';
    o.innerHTML = '<div class="em-manj-box" role="dialog"><div class="em-manj-h"><span>المنجلية</span><b id="emManjX" role="button" aria-label="إغلاق">×</b></div>' + MANJ.map(function (m, i) { return m[1] ? '<div class="em-manj-r" role="button" data-mj="' + m[1] + '">' + m[0] + '</div>' : '<div class="em-manj-r off"><span>' + m[0] + '</span><i>قريبًا</i></div>'; }).join('') + '</div>';
    document.body.appendChild(o);
    o.addEventListener('click', function (ev) { const r = ev.target.closest('[data-mj]'); if (r) { const id = r.getAttribute('data-mj'); o.remove(); const c = document.querySelector('#secGrid [data-sec="' + id + '"]'); if (c) c.click(); return; } if (ev.target === o || ev.target.closest('#emManjX')) o.remove(); });
  }

  // قسم الألعاب: one card in المزيد opening a sheet with الثعبان and مين الشخصية (their own screens/logic are unchanged)
  const GAMES = [['الثعبان', 'snake'], ['مين الشخصية؟', 'game'], ['ألعاب أكتر', 'games2']];
  function openGames() {
    let o = document.getElementById('emManj'); if (o) o.remove();
    o = document.createElement('div'); o.id = 'emManj'; o.className = 'em-manj';
    o.innerHTML = '<div class="em-manj-box" role="dialog"><div class="em-manj-h"><span>الألعاب</span><b id="emManjX" role="button" aria-label="إغلاق">×</b></div>' + GAMES.map(function (m) { return '<div class="em-manj-r" role="button" data-mj="' + m[1] + '">' + m[0] + '</div>'; }).join('') + '</div>';
    document.body.appendChild(o);
    o.addEventListener('click', function (ev) { const r = ev.target.closest('[data-mj]'); if (r) { const id = r.getAttribute('data-mj'); o.remove(); const c = document.querySelector('#secGrid [data-sec="' + id + '"]'); if (c) c.click(); return; } if (ev.target === o || ev.target.closest('#emManjX')) o.remove(); });
  }
  function ensureGamesCard() {
    const g = document.getElementById('secGrid'); if (!g || g.querySelector('[data-sec="games"]')) return;
    const src = g.querySelector('[data-sec="game"]'); if (!src) return;
    const c = src.cloneNode(true); c.setAttribute('data-sec', 'games'); c.removeAttribute('id');
    const nm = c.querySelector('.sec-name,.nm,h3,b'); if (nm) nm.textContent = 'الألعاب';
    const sb = c.querySelector('.sec-sub,.sub,small,span:last-child'); if (sb && sb !== nm) sb.textContent = 'الثعبان · مين الشخصية';
    src.parentNode.insertBefore(c, src);
  }
  (function () { const g = document.getElementById('secGrid'); if (g) { new MutationObserver(function () { ensureGamesCard(); }).observe(g, { childList: true }); ensureGamesCard(); } })();
  document.addEventListener('click', function (ev) { const c = ev.target.closest && ev.target.closest('#secGrid [data-sec="games"]'); if (c) { ev.stopPropagation(); ev.preventDefault(); openGames(); } }, true);

  function build() {
    const dia = document.getElementById('emDia'), scr = document.getElementById('scr-home');
    if (!dia || !scr) return;
    if (!document.getElementById('emLogo')) {
      const l = document.createElement('div'); l.id = 'emLogo'; l.className = 'em-logo';
      l.innerHTML = '<img class="lg-d" src="img/skin/logo-dark.png" alt="ظل"><img class="lg-l" src="img/skin/logo-light.png" alt="ظل"><div class="em-tag">مساحتك الروحية</div>';
      const g = scr.querySelector('.greet'); if (g) g.parentNode.insertBefore(l, g);
    }
    const ha = document.querySelector('#scr-home .hdr-actions');
    if (ha && !document.getElementById('emSearch')) {
      const b = document.createElement('span'); b.id = 'emSearch'; b.className = 'icon-btn'; b.setAttribute('role', 'button'); b.setAttribute('aria-label', 'بحث في الكتاب المقدس');
      b.innerHTML = '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15.5 15.5 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
      ha.appendChild(b);
    }
    const hqx = document.querySelector('#homeQuote .hq-tx');
    if (hqx) hqx.classList.toggle('em-short', (hqx.textContent || '').trim().length < 40);
    const hq = document.getElementById('homeQuote');
    if (hq && !hq.querySelector('.em-tab')) {
      const t = document.createElement('div'); t.className = 'em-tab';
      t.innerHTML = '<svg class="em-book" viewBox="0 3 64 42" aria-hidden="true"><defs><linearGradient id="emBkL" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2a8a70"/><stop offset="1" stop-color="#0c4a3a"/></linearGradient><linearGradient id="emBkR" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a8a70"/><stop offset="1" stop-color="#0c4a3a"/></linearGradient></defs><path d="M2 11C16 5 26 7 32 12c6-5 16-7 30-1v29c-14-6-24-4-30 1-6-5-16-7-30-1Z" fill="#093b2e"/><path d="M5 13c12-4 21-2 26 3v23c-5-4-14-6-26-3Z" fill="url(#emBkL)"/><path d="M59 13c-12-4-21-2-26 3v23c5-4 14-6 26-3Z" fill="url(#emBkR)"/><path d="M8 19c8-2 15-1 20 2M8 25c8-2 15-1 20 2M8 31c8-2 15-1 20 2M56 19c-8-2-15-1-20 2M56 25c-8-2-15-1-20 2M56 31c-8-2-15-1-20 2" fill="none" stroke="#bfe6d4" stroke-opacity=".55" stroke-width="1.3" stroke-linecap="round"/><path d="M3 41c14-6 24-4 29 1 5-5 15-7 29-1" fill="none" stroke="#cfe9dc" stroke-opacity=".7" stroke-width="1.4" stroke-linecap="round"/></svg><span>آية اليوم</span>';
      hq.insertBefore(t, hq.firstChild);
    }
    dia.innerHTML = TILES.map((t, i) => '<div class="em-t em-t' + (i + 1) + '" role="button" data-em="' + t[1] + '"><span class="sq"></span><span class="in"><img src="img/skin/ic-' + t[2] + '.png" alt=""><span class="nm">' + t[0].replace('\n', '<br>') + '</span></span></div>').join('');
  }
  function go(a) {
    const k = a.indexOf(':'), type = a.slice(0, k), id = a.slice(k + 1);
    if (type === 'manj') { openManj(); return; }
    if (type === 'card') { const c = document.querySelector('#secGrid [data-sec="' + id + '"]'); if (c) c.click(); }
    else if (type === 'nav') { const n = document.querySelector('#bottomNav [data-nav="' + id + '"]'); if (n) n.click(); }
    else if (type === 'sec' && window.zillOpenSection) window.zillOpenSection(id);
  }
  document.addEventListener('click', function (ev) {
    const t = ev.target.closest && ev.target.closest('[data-em]');
    if (t) { go(t.getAttribute('data-em')); return; }
    if (ev.target.closest && ev.target.closest('#emSearch')) { const c = document.querySelector('#secGrid [data-sec="bible"]') || document.querySelector('[data-sec="bible"]'); if (c) c.click(); setTimeout(function () { const i = document.getElementById('bibleSearch'); if (i) i.focus(); }, 700); return; }
    if (ev.target.closest && ev.target.closest('#emMore')) { const s = document.getElementById('scr-home'); s.classList.toggle('em-more-open'); const g = document.getElementById('secGrid'); if (s.classList.contains('em-more-open') && g) g.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  });

  // hymns screen: reference layout (restyle only; same player elements and ids)
  function hymnsInit() {
    const st = document.querySelector('#scr-hymns .hp-stage'); if (!st || st.getAttribute('data-em')) return; st.setAttribute('data-em', '1');
    const arm = document.getElementById('hpArm');
    if (arm) { arm.setAttribute('viewBox', '0 0 120 140'); arm.innerHTML = '<defs><linearGradient id="emg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F6DDA0"/><stop offset=".5" stop-color="#C99A3E"/><stop offset="1" stop-color="#8A6420"/></linearGradient><radialGradient id="emp" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#E7F3EA" stop-opacity=".95"/><stop offset="1" stop-color="#8FB8A2" stop-opacity=".75"/></radialGradient></defs><circle cx="96" cy="16" r="14" fill="url(#emp)" stroke="url(#emg)" stroke-width="2.5"/><circle cx="96" cy="16" r="5" fill="url(#emg)"/><path d="M96 16 L38 104" stroke="url(#emg)" stroke-width="5.5" stroke-linecap="round" fill="none"/><path d="M28 98 l16 -6 l9 14 l-16 9z" fill="url(#emg)"/>'; }
    const notes = document.createElement('div'); notes.className = 'hp-notes';
    const nt = (x, y, k) => '<g transform="translate(' + x + ' ' + y + ')" fill="#E9C074"><ellipse cx="0" cy="0" rx="5" ry="3.6" transform="rotate(-20)"/><path d="M4 -2 V-20" stroke="#E9C074" stroke-width="1.8" fill="none"/>' + (k ? '<path d="M4 -20 q9 3 7 12 q-1 -6 -7 -7z"/>' : '<path d="M4 -20 H15 M4 -15 H15" stroke="#E9C074" stroke-width="2.2"/><path d="M15 -20 V-10"  stroke="#E9C074" stroke-width="1.8"/><ellipse cx="11" cy="-8" rx="5" ry="3.6" transform="rotate(-20 11 -8)"/>') + '</g>';
    notes.innerHTML = '<svg viewBox="0 0 390 260" preserveAspectRatio="none"><g fill="none" stroke="#E9C074" stroke-opacity=".55" stroke-width="1"><path d="M0 120 C40 95 85 85 120 100"/><path d="M0 128 C40 103 85 93 120 108"/><path d="M0 136 C40 111 85 101 120 116"/><path d="M270 100 C310 78 350 74 390 92"/><path d="M270 108 C310 86 350 82 390 100"/><path d="M270 116 C310 94 350 90 390 108"/></g>' + nt(22, 132, 1) + nt(52, 96, 0) + nt(82, 100, 1) + nt(350, 120, 1) + nt(322, 86, 1) + '</svg>';
    st.insertBefore(notes, st.firstChild);
    const np = document.querySelector('#scr-hymns .hp-np'), pr = document.querySelector('#scr-hymns .hp-prog'), ct = document.querySelector('#scr-hymns .hp-ctrl');
    if (np && pr && ct && !document.getElementById('hpCard')) { const c = document.createElement('div'); c.id = 'hpCard'; c.className = 'hp-card'; np.parentNode.insertBefore(c, np); c.appendChild(np); c.appendChild(pr); c.appendChild(ct); }
  }
  function init() { hymnsInit(); build(); const g = document.getElementById('secGrid'); if (g) new MutationObserver(build).observe(g, { childList: true }); const q = document.getElementById('hqTx'); if (q) new MutationObserver(build).observe(q, { childList: true, characterData: true, subtree: true }); }
  if (document.readyState !== 'loading') init(); else document.addEventListener('DOMContentLoaded', init);
})();

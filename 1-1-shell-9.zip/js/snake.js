/* الثعبان والتفاح — user request 01:27 («التعبان اللي بياكل التفاح»). Offline canvas game. */
const SNAKE = { timer: null, dir: [1, 0], next: [1, 0], body: [], apple: null, score: 0, N: 12, R: 10, over: false };
function snakeBest() { return +(localStorage.getItem('zill.snake.best') || 0); }
function snakeReset() {
  SNAKE.body = [[5, 5], [4, 5], [3, 5]]; SNAKE.dir = [1, 0]; SNAKE.next = [1, 0]; SNAKE.score = 0; SNAKE.over = false;
  snakeApple();
}
function snakeApple() {
  let a;
  do { a = [Math.floor(Math.random() * SNAKE.N), Math.floor(Math.random() * SNAKE.R)]; }
  while (SNAKE.body.some(b => b[0] === a[0] && b[1] === a[1]));
  SNAKE.apple = a;
}
function snakeTurn(dx, dy) {
  if (dx === -SNAKE.dir[0] && dy === -SNAKE.dir[1]) return;
  SNAKE.next = [dx, dy];
}
function snakeStep() {
  if (SNAKE.over) return;
  SNAKE.dir = SNAKE.next;
  const N = SNAKE.N, R = SNAKE.R;
  // walls wrap: leaving one edge re-enters from the opposite edge. Only hitting its own body ends the game.
  const h = [(SNAKE.body[0][0] + SNAKE.dir[0] + N) % N, (SNAKE.body[0][1] + SNAKE.dir[1] + R) % R];
  const tail = SNAKE.body[SNAKE.body.length - 1];
  const eats = h[0] === SNAKE.apple[0] && h[1] === SNAKE.apple[1];
  if (SNAKE.body.some(b => b[0] === h[0] && b[1] === h[1] && (eats || b !== tail))) {
    SNAKE.over = true; snakeStop(); if (SNAKE.score >= 3 && window.zxpDone) zxpDone("snake");
    if (SNAKE.score > snakeBest()) localStorage.setItem('zill.snake.best', String(SNAKE.score));
    snakeDraw(); return;
  }
  SNAKE.body.unshift(h);
  if (eats) { SNAKE.score++; if (SNAKE.score > snakeBest()) localStorage.setItem('zill.snake.best', String(SNAKE.score)); snakeApple(); } else SNAKE.body.pop();
  snakeDraw();
}
function snakeStop() { if (SNAKE.timer) { clearInterval(SNAKE.timer); SNAKE.timer = null; } }
function snakeStart() { snakeStop(); snakeReset(); snakeDraw(); SNAKE.timer = setInterval(snakeStep, 190); }
function snakeDraw() {
  const cv = document.getElementById('snakeCv'); if (!cv) return;
  const ctx = cv.getContext('2d'), s = cv.width / SNAKE.N, N = SNAKE.N, R = SNAKE.R;
  const em = document.documentElement.getAttribute('data-skin') === 'emerald';
  const css = getComputedStyle(document.documentElement);
  ctx.clearRect(0, 0, cv.width, cv.height);
  for (let y = 0; y < R; y++) for (let x = 0; x < N; x++) {
    ctx.fillStyle = em ? ((x + y) % 2 ? '#0f4a38' : '#0a3a2b') : ((x + y) % 2 ? 'rgba(127,127,127,.14)' : 'rgba(127,127,127,.07)');
    ctx.fillRect(x * s, y * s, s, s);
  }
  // apple: two lobes, shading, highlight, stem and leaf
  const ax = (SNAKE.apple[0] + .5) * s, ay = (SNAKE.apple[1] + .56) * s;
  const ag = ctx.createRadialGradient(ax - s * .12, ay - s * .12, s * .03, ax, ay, s * .5); ag.addColorStop(0, '#ff6a5c'); ag.addColorStop(.55, '#d3261f'); ag.addColorStop(1, '#8e1410');
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.45)'; ctx.shadowBlur = s * .14; ctx.shadowOffsetY = s * .05;
  ctx.fillStyle = ag; ctx.beginPath(); ctx.arc(ax - s * .13, ay, s * .34, 0, 7); ctx.arc(ax + s * .13, ay, s * .34, 0, 7); ctx.arc(ax, ay + s * .08, s * .34, 0, 7); ctx.fill(); ctx.restore();
  ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(ax - s * .2, ay - s * .12, s * .07, s * .12, .6, 0, 7); ctx.fill();
  ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = s * .07; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(ax, ay - s * .22); ctx.quadraticCurveTo(ax + s * .02, ay - s * .38, ax + s * .08, ay - s * .46); ctx.stroke();
  ctx.fillStyle = '#4fae4a'; ctx.beginPath(); ctx.ellipse(ax + s * .22, ay - s * .42, s * .2, s * .1, -.45, 0, 7); ctx.fill();
  ctx.strokeStyle = '#2f7a30'; ctx.lineWidth = s * .02; ctx.beginPath(); ctx.moveTo(ax + s * .08, ay - s * .38); ctx.lineTo(ax + s * .36, ay - s * .49); ctx.stroke();
  // body: raised cream tiles
  const rr = (x, y, w, h, r) => { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); };
  const tile = (b, head) => {
    const x = b[0] * s + s * .05, y = b[1] * s + s * .05, w = s * .9;
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = s * .12; ctx.shadowOffsetY = s * .05;
    const g = ctx.createLinearGradient(x, y, x, y + w); g.addColorStop(0, '#fff6d6'); g.addColorStop(1, em ? '#d9c690' : '#c7b27a');
    ctx.fillStyle = g; rr(x, y, w, w, s * (head ? .36 : .24)); ctx.fill(); ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = s * .035; rr(x + s * .04, y + s * .04, w - s * .08, w - s * .08, s * .2); ctx.stroke();
  };
  for (let i = SNAKE.body.length - 1; i >= 1; i--) tile(SNAKE.body[i], false);
  tile(SNAKE.body[0], true);
  const hd = SNAKE.body[0], d = SNAKE.dir, cx = (hd[0] + .5) * s, cy = (hd[1] + .5) * s, px = -d[1], py = d[0];
  // tongue
  ctx.strokeStyle = '#d6322e'; ctx.lineWidth = s * .06; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx + d[0] * s * .46, cy + d[1] * s * .46); ctx.lineTo(cx + d[0] * s * .68, cy + d[1] * s * .68); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx + d[0] * s * .68, cy + d[1] * s * .68); ctx.lineTo(cx + d[0] * s * .8 + px * s * .1, cy + d[1] * s * .8 + py * s * .1); ctx.moveTo(cx + d[0] * s * .68, cy + d[1] * s * .68); ctx.lineTo(cx + d[0] * s * .8 - px * s * .1, cy + d[1] * s * .8 - py * s * .1); ctx.stroke();
  // eyes: white, pupil, glint
  for (const k of [-1, 1]) {
    const ex = cx + d[0] * s * .12 + px * k * s * .2, ey = cy + d[1] * s * .12 + py * k * s * .2;
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex, ey, s * .15, 0, 7); ctx.fill();
    ctx.fillStyle = '#10261c'; ctx.beginPath(); ctx.arc(ex + d[0] * s * .04, ey + d[1] * s * .04, s * .09, 0, 7); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex - s * .02, ey - s * .03, s * .025, 0, 7); ctx.fill();
  }
  const sc = document.getElementById('snakeScore');
  if (sc) sc.textContent = 'أكبر نتيجة: ' + toArabicDigits(Math.max(snakeBest(), SNAKE.score)) + ' · النتيجة: ' + toArabicDigits(SNAKE.score);
  const ov = document.getElementById('snakeOver'); if (ov) ov.hidden = !SNAKE.over;
}

/* Hymns/praise player (vinyl design approved by the owner on 2026-11-27).
   Library source: window.ZILL_HYMNS = [{title, kind, src, dur?}] (bundled/offline files). It is EMPTY today:
   no hymn audio exists in the app, so the screen shows an honest empty state. The Gregorian liturgy download is a separate feature. */
(function () {
  'use strict';
  const AD = (n) => String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
  const fmt = (t) => { if (!isFinite(t) || t < 0) t = 0; return AD(Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0')); };
  const $ = (id) => document.getElementById(id);
  const ICO_PLAY = '<svg class="ic"><use href="#hi-play"/></svg>';
  const ICO_PAUSE = '<svg class="ic" viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';
  let lib = [], cur = -1, aud = null, loop = false, wired = false;
  // local-only favourites (this device): keyed by file path, else title
  const FKEY = 'zill.hymnfavs';
  const fkey = (t) => String((t && (t.src || t.title)) || '');
  const favs = () => { try { return JSON.parse(localStorage.getItem(FKEY) || '[]'); } catch (e) { return []; } };
  const isFav = (t) => favs().indexOf(fkey(t)) >= 0;
  const toggleFav = (t) => { const a = favs(), k = fkey(t), i = a.indexOf(k); if (!k) return; if (i >= 0) a.splice(i, 1); else a.push(k); try { localStorage.setItem(FKEY, JSON.stringify(a)); } catch (e) {} };
  const HEART = '<svg class="ic hp-hs" viewBox="0 0 24 24"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.4 4.8 6.6 4.8c2 0 3.5 1.1 5.4 3.2 1.9-2.1 3.4-3.2 5.4-3.2 3.2 0 5.2 3.2 3.9 6.5-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>';
  const lengthOf = () => lib.length;
  const playing = () => !!(aud && !aud.paused && !aud.ended);

  function paint() {
    const n = lengthOf(), on = playing();
    const list = $('hpList');
    list.innerHTML = n ? lib.map((t, i) => '<div class="hp-tr' + (i === cur ? ' on' : '') + '" role="button" data-hp="' + i + '"><div class="hp-no">' + AD(i + 1) + '</div><div class="hp-tt"><div class="hp-n">' + t.title + '</div><div class="hp-k">' + (t.kind || '') + '</div></div>' +
      (i === cur && on ? '<span class="hp-eq"><i></i><i></i><i></i></span>' : '') + (t.dur ? '<div class="hp-du"><bdi>' + fmt(t.dur) + '</bdi></div>' : '') + '<span class="hp-hr' + (isFav(t) ? ' on' : '') + '" role="button" data-hf="' + i + '" aria-label="مفضلة">' + HEART + '</span></div>').join('')
      : '<div class="hp-empty">لسه مفيش ألحان ولا مدائح جوه التطبيق.<br>هتظهر هنا لما تتضاف، وتشتغل بدون نت.</div>';
    list.querySelectorAll('[data-hp]').forEach(el => el.onclick = () => play(+el.getAttribute('data-hp')));
    list.querySelectorAll('[data-hf]').forEach(el => el.onclick = (ev) => { ev.stopPropagation(); const t = lib[+el.getAttribute('data-hf')]; if (t) { toggleFav(t); paint(); } });
    const hf = $('hpFav'); if (hf) { hf.innerHTML = HEART; hf.classList.toggle('on', cur >= 0 && !!lib[cur] && isFav(lib[cur])); hf.setAttribute('aria-disabled', cur >= 0 ? 'false' : 'true'); }
    $('hpT').textContent = cur >= 0 ? lib[cur].title : (n ? 'اختار لحن' : 'لسه مفيش ألحان');
    $('hpA').textContent = cur >= 0 ? (lib[cur].kind || '') : (n ? 'اضغط على لحن من القائمة' : 'الترانيم والمدائح هتظهر هنا لما تتضاف');
    $('hpTopSub').textContent = '';
    const pp = $('hpPP'); pp.innerHTML = on ? ICO_PAUSE : ICO_PLAY; pp.setAttribute('aria-label', on ? 'إيقاف مؤقت' : 'تشغيل');
    ['hpPP', 'hpNext', 'hpPrev', 'hpLoop'].forEach(id => $(id).setAttribute('aria-disabled', n ? 'false' : 'true'));
    $('hpLoop').classList.toggle('on', loop);
    document.querySelector('#scr-hymns .hp-stage').classList.toggle('playing', on);
    if (!on && cur < 0) { $('hpFill').style.width = '0'; $('hpKnob').style.left = '0'; $('hpCur').textContent = AD('0:00'); $('hpDur').textContent = ''; }
  }
  function tick() {
    if (!aud) return; const d = aud.duration || 0, c = aud.currentTime || 0, f = d ? Math.min(100, 100 * c / d) : 0;
    $('hpFill').style.width = f + '%'; $('hpKnob').style.left = f + '%'; $('hpCur').textContent = fmt(c); $('hpDur').textContent = d ? fmt(d) : '';
  }
  function ensureAudio() {
    if (aud) return;
    aud = new Audio(); aud.preload = 'auto';
    aud.addEventListener('timeupdate', tick); aud.addEventListener('loadedmetadata', tick);
    aud.addEventListener('play', paint); aud.addEventListener('pause', paint);
    aud.addEventListener('ended', () => { if (!loop && cur + 1 < lib.length) play(cur + 1); else paint(); });
    aud.addEventListener('error', () => { $('hpStat').textContent = 'مقدرتش أشغّل الملف ده.'; paint(); });
  }
  async function play(i) {
    if (!lib[i]) return; ensureAudio(); cur = i; aud.loop = loop; aud.src = lib[i].src; $('hpStat').textContent = '';
    try { await aud.play(); } catch (e) { $('hpStat').textContent = 'مقدرتش أشغّل الملف ده.'; }
    paint();
  }
  function step(d) { const n = lengthOf(); if (!n) return; play(cur < 0 ? 0 : (cur + d + n) % n); }
  function wire() {
    if (wired) return; wired = true;
    $('hpBack').onclick = () => window.zShowScreen('home');
    $('hpPP').onclick = () => { if (!lengthOf()) return; if (cur < 0) { play(0); return; } if (aud.paused) aud.play(); else aud.pause(); };
    if ($('hpFav')) $('hpFav').onclick = () => { if (cur < 0 || !lib[cur]) return; toggleFav(lib[cur]); paint(); };
    $('hpNext').onclick = () => step(1); $('hpPrev').onclick = () => step(-1);
    $('hpLoop').onclick = () => { if (!lengthOf()) return; loop = !loop; if (aud) aud.loop = loop; paint(); };
    $('hpBar').addEventListener('click', ev => { if (!aud || !aud.duration) return; const r = $('hpBar').getBoundingClientRect(); aud.currentTime = Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * aud.duration; tick(); });
  }
  function open() { lib = Array.isArray(window.ZILL_HYMNS) ? window.ZILL_HYMNS : []; wire(); window.zShowScreen('hymns'); paint(); }
  window.zHymnPlayer = { open, setLibrary(a) { lib = a; cur = -1; if (aud) aud.pause(); paint(); } };
})();

/* Backup + restore of the user's own app state (theme, settings, favorites,
   reading position, suggestions, scores) as JSON text.
   Export: one tap copies the text out.
   Restore: paste -> validate (fmt:1, allowlist, shapes, size caps) -> review
   what was found -> explicit confirm -> write. All-or-nothing: any error
   means nothing is written. Values are stored as literal strings via
   setItem only; nothing is ever parsed into the DOM or executed. */
(function () {
  const KEYS = ['zill.theme', 'zill.settings', 'zill.game.seen', 'zill.favs', 'zill.resume', 'zill.suggest', 'zill.snake.best', 'zill.maze.best', 'zill.maze.cur', 'zill.xp.game', 'zill.xp.growth', 'zill.xp.ach'];
  const LABELS = {
    'zill.theme': 'المظهر',
    'zill.settings': 'الإعدادات',
    'zill.game.seen': 'تقدّم الألعاب',
    'zill.favs': 'المفضلة',
    'zill.resume': 'مكان القراءة',
    'zill.suggest': 'الاقتراحات',
    'zill.snake.best': 'أعلى نتيجة في اللعبة',
    'zill.maze.best': 'أعلى مستوى في متاهة نوح',
    'zill.maze.cur': 'مستوى متاهة نوح الحالي',
    'zill.xp.game': 'نقاط الألعاب',
    'zill.xp.growth': 'نقاط النمو الروحي',
    'zill.xp.ach': 'الإنجازات'
  };
  const SHAPE = {
    'zill.settings': v => isObj(JSON.parse(v)),
    'zill.favs': v => Array.isArray(JSON.parse(v)),
    'zill.maze.best': v => /^\d{1,6}$/.test(v),
    'zill.maze.cur': v => /^\d{1,6}$/.test(v),
    'zill.xp.game': v => { const o = JSON.parse(v); return isObj(o) && Number.isFinite(o.total) && o.total >= 0 && Array.isArray(o.log); },
    'zill.xp.growth': v => { const o = JSON.parse(v); return isObj(o) && Number.isFinite(o.total) && o.total >= 0 && Array.isArray(o.log); },
    'zill.xp.ach': v => isObj(JSON.parse(v))
  };
  const MAX_TOTAL = 256 * 1024, MAX_VALUE = 64 * 1024;
  function isObj(o) { return o !== null && typeof o === 'object' && !Array.isArray(o); }

  window.zBackupText = function () {
    const d = {}; KEYS.forEach(k => { try { const v = localStorage.getItem(k); if (v !== null) d[k] = v; } catch (e) {} });
    return JSON.stringify({ app: 'zill', fmt: 1, exported: new Date().toISOString(), data: d });
  };

  function validateImport(text) {
    const errors = [], rejectedKeys = [];
    if (typeof text !== 'string' || !text.trim()) return { ok: false, errors: ['empty'] };
    if (text.length > MAX_TOTAL) return { ok: false, errors: ['too-large'] };
    let o;
    try { o = JSON.parse(text); } catch (e) { return { ok: false, errors: ['bad-json'] }; }
    if (!isObj(o) || o.app !== 'zill' || o.fmt !== 1 || !isObj(o.data)) return { ok: false, errors: ['bad-envelope'] };
    const out = {};
    for (const [k, v] of Object.entries(o.data)) {
      if (!KEYS.includes(k)) { rejectedKeys.push(k); continue; }
      if (typeof v !== 'string' || v.length > MAX_VALUE) { errors.push(k); continue; }
      if (SHAPE[k]) {
        try { if (!SHAPE[k](v)) { errors.push(k); continue; } } catch (e) { errors.push(k); continue; }
      }
      out[k] = v;
    }
    if (errors.length) return { ok: false, errors, rejectedKeys };
    return { ok: true, data: out, rejectedKeys };
  }

  let reviewed = null; // validated payload awaiting explicit confirm

  document.addEventListener('click', async ev => {
    const t = ev.target && ev.target.closest ? ev.target : null;
    if (!t) return;

    if (t.closest('#zBkBtn')) {
      const txt = window.zBackupText(), box = document.getElementById('zBkBox'), st = document.getElementById('zBkSt');
      box.hidden = false; box.value = txt; let ok = false;
      try { if (navigator.share) { await navigator.share({ text: txt }); ok = 'share'; } } catch (e) {}
      if (!ok) { try { await navigator.clipboard.writeText(txt); ok = 'clip'; } catch (e) {} }
      if (!ok) { try { box.focus(); box.select(); ok = document.execCommand('copy') ? 'clip' : false; } catch (e) {} }
      st.textContent = ok === 'share' ? 'اتفتحت قائمة المشاركة وتم الإرسال منها. احتفظ بالنص في مكان آمن.'
        : ok === 'clip' ? 'اتنسخ النص. الصقه في مكان آمن.'
        : 'النص جهز تحت، لسه مش منسوخ. اضغط عليه واختار نسخ واحفظه.';
      return;
    }

    if (t.closest('#zRsChk')) {
      const box = document.getElementById('zRsBox'), st = document.getElementById('zRsSt'), go = document.getElementById('zRsGo');
      reviewed = null; go.hidden = true;
      const r = validateImport(box.value);
      if (!r.ok || !Object.keys(r.data || {}).length) {
        st.textContent = 'النص ده مش نسخة صحيحة من التطبيق. اتأكد إنك ناسخ النص كله.';
        return;
      }
      reviewed = r;
      const found = Object.keys(r.data).map(k => {
        let n = LABELS[k] || k, c = '';
        if (k === 'zill.favs') { try { const n = JSON.parse(r.data[k]).length; c = ' (' + (typeof toArabicDigits === 'function' ? toArabicDigits(n) : n) + ' عنصر)'; } catch (e) {} }
        return n + c;
      });
      st.textContent = 'النسخة سليمة. اللي هيترجّع: ' + found.join('، ') + '.' +
        (r.rejectedKeys.length ? ' فيه ' + r.rejectedKeys.length + ' حاجة مش معروفة هتتجاهل.' : '') +
        ' لو موافق اضغط «استرجع البيانات دي».';
      go.hidden = false;
      return;
    }

    if (t.closest('#zRsGo')) {
      const st = document.getElementById('zRsSt'), go = document.getElementById('zRsGo');
      if (!reviewed || !reviewed.ok) { st.textContent = 'راجع النص الأول.'; return; }
      const snapshot = Object.keys(reviewed.data).map(k => [k, localStorage.getItem(k)]);
      try {
        for (const [k, v] of Object.entries(reviewed.data)) localStorage.setItem(k, v);
      } catch (e) {
        for (const [k, v] of snapshot) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e2) {} }
        st.textContent = 'مقدرناش نكتب البيانات على الجهاز، ورجّعنا اللي كان موجود زي ما هو. مساحة التخزين ممكن تكون مليانة.';
        return;
      }
      reviewed = null; go.hidden = true;
      st.textContent = 'اترجعت بياناتك ✓ بيجهّز التطبيق من الأول...';
      setTimeout(() => { try { location.reload(); } catch (e) {} }, 1200);
      return;
    }
  });
})();

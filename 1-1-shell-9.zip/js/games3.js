/* ألعاب إضافية: صح ولا غلط (بشرح من شرح الأصحاح)، متاهة الفلك، دوّر على الكلمات.
   كل المحتوى متأصل في شرح الأصحاح (js/notes/b1.js) — حقائق نصية فقط. */

/* ---------- صح ولا غلط ---------- */
/* كل سؤال مبني على حقيقة من شرح الأصحاح؛ العبارات الغلط متعمدة والتوضيح بيصححها. */
const ZTF_POOL = [
  { q: 'الله خلق الإنسان على صورته، ذكر وأنثى.', ok: true, why: 'الإنسان هو الوحيد اللي اتقال عنه «على صورة الله»، واتخلق ذكرًا وأنثى في اليوم السادس.', ref: 'تكوين ١: ٢٦-٢٧' },
  { q: 'الله سمّى النور «نهار» والظلمة «ليل».', ok: true, why: 'في اليوم الأول: فصل الله بين النور والظلمة، وسمّى النور نهارًا والظلمة ليلًا.', ref: 'تكوين ١: ٣-٥' },
  { q: 'الله خلق الإنسان في اليوم الرابع.', ok: false, why: 'اليوم الرابع كان للنورين والنجوم؛ الإنسان اتخلق في اليوم السادس.', ref: 'تكوين ١: ١٤-١٩،٢٤-٣١' },
  { q: 'آدم هو اللي سمّى امرأته حواء.', ok: true, why: 'آدم سمّى امرأته حواء لأنها أم كل حي.', ref: 'تكوين ٣: ٢٠' },
  { q: 'أول سؤال قاله الله لآدم بعد الأكل كان: «أين أنت؟».', ok: true, why: 'أول كلام الله مع آدم بعد الأكل كان سؤال: «أين أنت؟» ثم «من أعلمك أنك عريان؟».', ref: 'تكوين ٣: ٩-١١' },
  { q: 'آدم قال لله إنه أكل لوحده ومحصلش من حد حاجة.', ok: false, why: 'بالعكس: آدم قال إن المرأة أعطته، والمرأة قالت إن الحية غرّتها — كل واحد حيل على اللي بعده.', ref: 'تكوين ٣: ١٢-١٣' },
  { q: 'الله حكم على الحية إنها تمشي على رجليها.', ok: false, why: 'الحكم كان إن الحية تمشي على بطنها وتأكل ترابًا.', ref: 'تكوين ٣: ١٤' },
  { q: 'نوح كان عمره خمس مئة سنة لما صار الطوفان.', ok: false, why: 'نوح كان عمره ست مئة سنة لما صار طوفان المياه على الأرض.', ref: 'تكوين ٧: ٦' },
  { q: 'اللي دخل الفلك كان تمن أشخاص: نوح وامرأته وبنوه التلاتة ونساؤهم.', ok: true, why: 'دخل ثمانية أشخاص: نوح وامرأته وبنوه الثلاثة ونساؤهم الثلاث.', ref: 'تكوين ٧: ٧،١٣' },
  { q: 'الرب هو اللي أغلق باب الفلك على نوح.', ok: true, why: 'النص بيقول: «وأغلق الرب عليه».', ref: 'تكوين ٧: ١٦' },
  { q: 'المطر في الطوفان استمر أربعين يوم وأربعين ليلة.', ok: true, why: 'كان المطر على الأرض أربعين يومًا وأربعين ليلة، والمياه تعاظمت مئة وخمسين يومًا.', ref: 'تكوين ٧: ١٢،٢٤' },
  { q: 'الله قال لنوح ياخد من كل الحيوانات اتنين اتنين بس.', ok: false, why: 'من البهائم الطاهرة سبعة سبعة ذكرًا وأنثى، ومن غير الطاهرة اثنين.', ref: 'تكوين ٧: ٢' },
  { q: 'علامة ميثاق الله مع نوح هي القوس في السحاب.', ok: true, why: 'علامة الميثاق قوس الله في السحاب، وكلما ظهرت يذكر الله ميثاقه الأبدي.', ref: 'تكوين ٩: ١٢-١٧' },
  { q: 'نوح لعن ابنه حام.', ok: false, why: 'اللعنة في كلام نوح اتوجهت لكنعان بن حام، مش لحام نفسه.', ref: 'تكوين ٩: ٢٢،٢٥' },
  { q: 'حام هو أبو كنعان.', ok: true, why: 'بنو نوح اللي خرجوا من الفلك: سام وحام ويافث، وحام هو أبو كنعان.', ref: 'تكوين ٩: ١٨' },
  { q: 'الناس بنت البرج في شنعار علشان تصلي فيه لله.', ok: false, why: 'بنوا المدينة والبرج علشان يصنعوا لأنفسهم اسمًا وميتبددوش على وجه الأرض.', ref: 'تكوين ١١: ٤' },
  { q: 'المدينة والبرج اتبنوا في أرض شنعار، والمكان اتسمّى بابل.', ok: true, why: 'دُعي اسمها بابل لأن الرب هناك بلبل لسان كل الأرض.', ref: 'تكوين ١١: ٢،٩' },
  { q: 'ساراي امرأة أبرام كان عندها ولاد كتير.', ok: false, why: 'النص بيقول إن ساراي كانت عاقرًا ليس لها ولد.', ref: 'تكوين ١١: ٣٠' },
  { q: 'متوشالح أطول الأعمار في أصحاح مواليد آدم: عاش ٩٦٩ سنة.', ok: true, why: 'متوشالح عاش ٩٦٩ سنة ومات، وهو أطول الأعمار في الأصحاح.', ref: 'تكوين ٥: ٢٧' }
];
const ZG3 = { tf: null, maze: null, ws: null };
/* Question bank (user-provided): statement, true/false, then the correct answer, his explanation and the reference. */
function zgTFBank(root, st) {
  if (!ZTB.q.length) ZTB.q = zgShuffle(ZTB.bank.map((_, i) => i));
  const it = ZTB.bank[ZTB.q.pop()];
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p>' + it.q + '</p></div>' +
    '<div class="zg-opts"><div class="game-btn" id="ztfT" role="button">صح</div><div class="game-btn" id="ztfF" role="button">غلط</div></div><div id="ztff"></div>';
  let done = false;
  const ref = it.b + ' <bdi dir="ltr">' + toArabicDigits(it.c) + ':' + toArabicDigits(it.v) + '</bdi>';
  const answer = pick => {
    if (done) return; done = true; st.n++;
    const right = pick === it.a; if (right) st.ok++; zxpQ('tf', right);
    const bT = root.querySelector('#ztfT'), bF = root.querySelector('#ztfF');
    (it.a ? bT : bF).classList.add('right'); (it.a ? bF : bT).classList.add(right ? 'dim' : 'wrong');
    root.querySelector('#ztff').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الإجابة الصح: ' + (it.a ? 'صح' : 'غلط') + '. ') + it.x + ' <bdi>(' + ref + ')</bdi></p>' +
      '<div class="game-actions"><span class="game-btn" id="ztfn" role="button">السؤال اللي بعده</span></div>';
    root.querySelector('#ztfn').onclick = () => zgTF(root, st);
  };
  root.querySelector('#ztfT').onclick = () => answer(true);
  root.querySelector('#ztfF').onclick = () => answer(false);
}

const ZTB = { bank: null, q: [] };
function zgTF(root, st) {
  st = st || { ok: 0, n: 0, used: [] };
  if (ZTB.bank === null) { ZTB.bank = false; packLoadJson('game-tf-bank', 'content/packs/game-tf-bank.json').then(p => { ZTB.bank = (p && p.items && p.items.length) ? p.items : false; zgTF(root, st); }).catch(() => { ZTB.bank = false; zgTF(root, st); }); return; }
  if (Array.isArray(ZTB.bank)) return zgTFBank(root, st);
  const avail = ZTF_POOL.map((x, i) => i).filter(i => !st.used.includes(i));
  const idx = avail.length ? avail[Math.floor(Math.random() * avail.length)] : (st.used = [], Math.floor(Math.random() * ZTF_POOL.length));
  st.used.push(idx);
  const item = ZTF_POOL[idx];
  ZG3.tf = { idx, answered: false };
  root.innerHTML = '<p class="advice-src zg-score">' + toArabicDigits(st.ok) + ' / ' + toArabicDigits(st.n) + '</p>' +
    '<div class="synax-tx"><p>' + item.q + '</p></div>' +
    '<div class="zg-opts"><div class="game-btn" id="ztfT" role="button">صح</div><div class="game-btn" id="ztfF" role="button">غلط</div></div><div id="ztff"></div>';
  const answer = pick => {
    if (ZG3.tf.answered) return; ZG3.tf.answered = true; st.n++;
    const right = pick === item.ok; if (right) st.ok++; zxpQ('tf', right);
    const bT = root.querySelector('#ztfT'), bF = root.querySelector('#ztfF');
    const correctBtn = item.ok ? bT : bF, otherBtn = item.ok ? bF : bT;
    correctBtn.classList.add('right');
    otherBtn.classList.add(right ? 'dim' : 'wrong');
    root.querySelector('#ztff').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓ ' : 'الإجابة الصح: ' + (item.ok ? 'صح' : 'غلط') + '. ') + item.why + ' <bdi>(' + item.ref + ')</bdi></p>' +
      '<div class="game-actions"><span class="game-btn" id="ztfn" role="button">السؤال اللي بعده</span></div>';
    root.querySelector('#ztfn').onclick = () => zgTF(root, st);
  };
  root.querySelector('#ztfT').onclick = () => answer(true);
  root.querySelector('#ztfF').onclick = () => answer(false);
}

/* ---------- متاهة الفلك (متاهة نوح) ---------- */
/* مستويات بلا سقف: الحجم بيكبر لحد ٦٠×٦٠، الحلقات (الطرق البديلة) بتقل لحد ما تبقى طريق واحد، وبعد المستوى ٨ بيظهر ضباب بيضيّق الرؤية لحد ٣ خانات. كل متاهة ليها حل دايمًا (بنحفر الجدران بس، مش بنقفل). */
function mzParams(L) {
  /* كل المقاييس بتتحرك مع كل مستوى (مفيش هضبة): الحجم لحد ١٥٠×١٥٠، نصف قطر الرؤية بيضيق باستمرار لحد ١٫٣ خانة عند ١٠٠٠،
     وكل ما المستوى يعلى المتاهة بتبقى أكتر تفرّعًا (طرق مسدودة أكتر) بدل الممرات الطويلة السهلة. */
  return {
    N: Math.min(150, Math.round(7 + Math.pow(L, 0.7))),
    loops: Math.max(0, 0.06 - L * 0.001),
    fog: L < 10 ? 0 : (k => Math.max(0.8, k <= 20 ? 5.5 - 0.1 * k : 3.5 - 0.034 * (k - 20)))(Math.floor((L - 10) / 10)),
    newest: Math.max(0.6, 0.92 - L * 0.0003),  /* احتمال كمّل في نفس الممر: قل = تفرّع أكتر */
    minShort: 1.2 + Math.min(2.2, L * 0.0025)    /* أقل طول للحل كنسبة من الحجم */
  };
}
function mzGenerate(N, loops, newest) {
  if (newest == null) newest = 0.9;
  const cells = [];
  for (let y = 0; y < N; y++) { const row = []; for (let x = 0; x < N; x++) row.push({ v: false, w: [true, true, true, true] }); cells.push(row); }
  const list = [[0, 0]]; cells[0][0].v = true;
  const DIRS = [[0, -1, 0, 2], [1, 0, 1, 3], [0, 1, 2, 0], [-1, 0, 3, 1]];
  while (list.length) {
    const i = Math.random() < newest ? list.length - 1 : Math.floor(Math.random() * list.length);
    const [x, y] = list[i];
    const opts = DIRS.filter(d => { const nx = x + d[0], ny = y + d[1]; return nx >= 0 && ny >= 0 && nx < N && ny < N && !cells[ny][nx].v; });
    if (!opts.length) { list.splice(i, 1); continue; }
    const d = opts[Math.floor(Math.random() * opts.length)];
    const nx = x + d[0], ny = y + d[1];
    cells[y][x].w[d[2]] = false; cells[ny][nx].w[d[3]] = false;
    cells[ny][nx].v = true; list.push([nx, ny]);
  }
  let extra = Math.round(N * N * loops);
  for (let t = 0; t < extra * 6 + 20 && extra > 0; t++) {
    const x = Math.floor(Math.random() * N), y = Math.floor(Math.random() * N), d = DIRS[Math.floor(Math.random() * 4)];
    const nx = x + d[0], ny = y + d[1];
    if (nx < 0 || ny < 0 || nx >= N || ny >= N || !cells[y][x].w[d[2]]) continue;
    cells[y][x].w[d[2]] = false; cells[ny][nx].w[d[3]] = false; extra--;
  }
  return cells;
}
function mzStats(cells, N) {
  const open = (x, y) => { const c = cells[y][x], r = []; if (!c.w[0]) r.push([x, y - 1]); if (!c.w[1]) r.push([x + 1, y]); if (!c.w[2]) r.push([x, y + 1]); if (!c.w[3]) r.push([x - 1, y]); return r; };
  let dead = 0, fork = 0;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const n = open(x, y).length; if (n === 1 && !(x === 0 && y === 0) && !(x === N - 1 && y === N - 1)) dead++; if (n >= 3) fork++; }
  const dist = []; for (let y = 0; y < N; y++) dist.push(new Array(N).fill(-1)); dist[0][0] = 0;
  const q = [[0, 0]]; let h = 0;
  while (h < q.length) { const [x, y] = q[h++]; open(x, y).forEach(([a, b]) => { if (dist[b][a] < 0) { dist[b][a] = dist[y][x] + 1; q.push([a, b]); } }); }
  return { dead, fork, shortest: dist[N - 1][N - 1] };
}
function mzLoad(k) { return Math.max(0, parseInt(localStorage.getItem(k) || '0', 10) || 0); }
function mzNew(root, st) {
  st = st || {};
  if (!st.level) st.level = Math.max(1, mzLoad('zill.maze.cur'));
  const L = st.level, P = mzParams(L), N = P.N;
  let cells, stats, tries = 0;
  do { cells = mzGenerate(N, P.loops, P.newest); stats = mzStats(cells, N); tries++; } while (tries < 8 && stats.shortest < N * P.minShort);
  const mz = { cells, N, stats, level: L, fog: P.fog, px: 0, py: 0, gx: N - 1, gy: N - 1, moves: 0, over: false };
  ZG3.maze = mz;
  const V = Math.min(N, 11);
  root.innerHTML = '<div class="mz-scene"><p class="mz-hud"><span>المستوى <b>' + toArabicDigits(L) + '</b></span><span>أعلى مستوى أكملته: <b>' + toArabicDigits(mzLoad('zill.maze.best')) + '</b></span></p>' +
    '<canvas id="mzCv" width="720" height="720" style="touch-action:none"></canvas>' +
    '<div class="snake-pad mz-pad"><span class="game-btn" id="mzU" role="button">↑</span><div><span class="game-btn" id="mzL" role="button">←</span><span class="game-btn" id="mzD" role="button">↓</span><span class="game-btn" id="mzR" role="button">→</span></div></div>' +
    '<div id="mzf"></div></div>';
  const cv = root.querySelector('#mzCv');
  const trail = new Set(['0,0']);
  const draw = () => {
    const ctx = cv.getContext('2d'), M = 14, s = (cv.width - 2 * M) / V;
    const cx0 = Math.max(0, Math.min(N - V, mz.px - Math.floor(V / 2))), cy0 = Math.max(0, Math.min(N - V, mz.py - Math.floor(V / 2)));
    const gold = '#F0C768';
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.translate(M, M);
    for (let y = 0; y < V; y++) for (let x = 0; x < V; x++) { ctx.fillStyle = (x + y + cx0 + cy0) % 2 ? '#14573F' : '#124B37'; ctx.fillRect(x * s, y * s, s, s); }
    ctx.fillStyle = 'rgba(240,199,104,.12)';
    trail.forEach(k => { const [tx, ty] = k.split(',').map(Number); if (tx >= cx0 && tx < cx0 + V && ty >= cy0 && ty < cy0 + V) ctx.fillRect((tx - cx0) * s, (ty - cy0) * s, s, s); });
    const walls = (col, lw, ox, oy) => {
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.lineCap = 'round'; ctx.beginPath();
      for (let y = 0; y < V; y++) for (let x = 0; x < V; x++) {
        const c = mz.cells[y + cy0][x + cx0], X = x * s + ox, Y = y * s + oy;
        if (c.w[0]) { ctx.moveTo(X, Y); ctx.lineTo(X + s, Y); }
        if (c.w[1]) { ctx.moveTo(X + s, Y); ctx.lineTo(X + s, Y + s); }
        if (c.w[2]) { ctx.moveTo(X, Y + s); ctx.lineTo(X + s, Y + s); }
        if (c.w[3]) { ctx.moveTo(X, Y); ctx.lineTo(X, Y + s); }
      }
      ctx.stroke();
    };
    const lw = Math.max(5, s * .17);
    walls('rgba(0,0,0,.45)', lw, lw * .35, lw * .5);
    walls('#D9CFAE', lw, 0, 0);
    walls('#F6EFD3', lw * .5, -lw * .1, -lw * .12);
    // goal: the ark chest
    if (mz.gx >= cx0 && mz.gx < cx0 + V && mz.gy >= cy0 && mz.gy < cy0 + V) {
      const gx = (mz.gx - cx0 + .5) * s, gy = (mz.gy - cy0 + .55) * s;
      ctx.save(); ctx.shadowColor = 'rgba(255,210,90,.9)'; ctx.shadowBlur = s * .35;
      ctx.fillStyle = '#A8672A'; ctx.fillRect(gx - s * .27, gy - s * .12, s * .54, s * .3);
      ctx.beginPath(); ctx.moveTo(gx - s * .27, gy - s * .12); ctx.quadraticCurveTo(gx, gy - s * .42, gx + s * .27, gy - s * .12); ctx.fill(); ctx.restore();
      ctx.strokeStyle = gold; ctx.lineWidth = s * .04; ctx.strokeRect(gx - s * .27, gy - s * .12, s * .54, s * .3);
      ctx.fillStyle = gold; ctx.fillRect(gx - s * .03, gy - s * .22, s * .06, s * .24); ctx.fillRect(gx - s * .1, gy - s * .15, s * .2, s * .05);
    }
    // player: golden orb
    const ox = (mz.px - cx0 + .5) * s, oy = (mz.py - cy0 + .5) * s;
    const og = ctx.createRadialGradient(ox - s * .08, oy - s * .1, s * .02, ox, oy, s * .3); og.addColorStop(0, '#FFF1B0'); og.addColorStop(.5, '#F0B93A'); og.addColorStop(1, '#B07A12');
    ctx.save(); ctx.shadowColor = 'rgba(255,215,100,.95)'; ctx.shadowBlur = s * .4; ctx.fillStyle = og; ctx.beginPath(); ctx.arc(ox, oy, s * .27, 0, 7); ctx.fill(); ctx.restore();
    // fog of war: unexplored cells beyond the sight radius are hidden
    if (mz.fog) {
      for (let y = 0; y < V; y++) for (let x = 0; x < V; x++) {
        const gx2 = x + cx0, gy2 = y + cy0, d = Math.hypot(gx2 - mz.px, gy2 - mz.py);
        let a = Math.min(1, Math.max(0, (d - mz.fog + 1) / 1.6)) * .97;
        if (trail.has(gx2 + ',' + gy2)) a = Math.min(a, .55);
        if (a > 0.01) { ctx.fillStyle = 'rgba(4,22,16,' + a.toFixed(3) + ')'; ctx.fillRect(x * s - .5, y * s - .5, s + 1, s + 1); }
      }
    }
  };
  const move = (dx, dy) => {
    if (mz.over) return false;
    const c = mz.cells[mz.py][mz.px];
    if ((dx === 1 && c.w[1]) || (dx === -1 && c.w[3]) || (dy === 1 && c.w[2]) || (dy === -1 && c.w[0])) return false;
    mz.px += dx; mz.py += dy; mz.moves++; trail.add(mz.px + ',' + mz.py);
    if (mz.px === mz.gx && mz.py === mz.gy) {
      mz.over = true; zxpDone('maze', { hardKey: (L % 10 === 0) ? 'L' + L : null });
      if (L > mzLoad('zill.maze.best')) localStorage.setItem('zill.maze.best', String(L));
      localStorage.setItem('zill.maze.cur', String(L + 1));
      root.querySelector('#mzf').innerHTML = '<p class="advice-src">وصل نوح للفلك ✓ «وأغلق الرب عليه» (تكوين ٧: ١٦)</p><div class="game-actions"><span class="game-btn" id="mzn" role="button">المستوى ' + toArabicDigits(L + 1) + ' ←</span></div>';
      root.querySelector('#mzn').onclick = () => mzNew(root, { level: L + 1 });
    }
    draw(); return true;
  };
  mz.move = move;
  root.querySelector('#mzU').onclick = () => move(0, -1);
  root.querySelector('#mzD').onclick = () => move(0, 1);
  root.querySelector('#mzL').onclick = () => move(-1, 0);
  root.querySelector('#mzR').onclick = () => move(1, 0);
  /* سحب متصل: كل ما الصباع يبعد نص خانة في اتجاه، نوح يتحرك خانة */
  let ax = 0, ay = 0, dragging = false;
  cv.addEventListener('pointerdown', e => { dragging = true; ax = e.clientX; ay = e.clientY; try { cv.setPointerCapture(e.pointerId); } catch (_) {} });
  cv.addEventListener('pointermove', e => {
    if (!dragging) return;
    const step = cv.getBoundingClientRect().width / V * 0.55;
    for (let k = 0; k < 4; k++) {
      const dx = e.clientX - ax, dy = e.clientY - ay;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < step) break;
      if (Math.abs(dx) > Math.abs(dy)) { const sx = dx > 0 ? 1 : -1; move(sx, 0); ax += sx * step * 1.8; }
      else { const sy = dy > 0 ? 1 : -1; move(0, sy); ay += sy * step * 1.8; }
    }
  });
  const end = () => { dragging = false; };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  draw();
}

/* ---------- دوّر على الكلمات ---------- */
const ZWS_BANK = ['نوح', 'الفلك', 'آدم', 'حواء', 'قايين', 'هابيل', 'شيث', 'أخنوخ', 'سام', 'حام', 'يافث', 'كنعان', 'بابل', 'شنعار', 'أبرام', 'ساراي', 'لوط', 'تارح', 'حاران', 'أور'];
const ZWS_N = 9, ZWS_LETTERS = 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي';
function zwsNew(root, st) {
  st = st || { done: 0 };
  const N = ZWS_N;
  const words = zgShuffle(ZWS_BANK).filter(w => w.length <= N).slice(0, 7);
  const grid = []; for (let y = 0; y < N; y++) grid.push(new Array(N).fill(''));
  const placed = [];
  const DIRS = [[1, 0], [0, 1], [1, 1], [-1, 1], [-1, 0], [0, -1], [-1, -1], [1, -1]];
  for (const w of words) {
    let okSpot = null;
    for (let tries = 0; tries < 300 && !okSpot; tries++) {
      const d = DIRS[Math.floor(Math.random() * DIRS.length)];
      const x0 = Math.floor(Math.random() * N), y0 = Math.floor(Math.random() * N);
      const xe = x0 + d[0] * (w.length - 1), ye = y0 + d[1] * (w.length - 1);
      if (xe < 0 || xe >= N || ye < 0 || ye >= N) continue;
      let fits = true;
      for (let i = 0; i < w.length; i++) { const x = x0 + d[0] * i, y = y0 + d[1] * i; if (grid[y][x] && grid[y][x] !== w[i]) { fits = false; break; } }
      if (fits) okSpot = { x0, y0, d };
    }
    if (!okSpot) continue;
    for (let i = 0; i < w.length; i++) grid[okSpot.y0 + okSpot.d[1] * i][okSpot.x0 + okSpot.d[0] * i] = w[i];
    placed.push({ w, x0: okSpot.x0, y0: okSpot.y0, dx: okSpot.d[0], dy: okSpot.d[1] });
  }
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (!grid[y][x]) grid[y][x] = ZWS_LETTERS[Math.floor(Math.random() * ZWS_LETTERS.length)];
  const ws = { grid, placed, found: [] };
  ZG3.ws = ws;
  root.innerHTML = '<p class="advice-src zg-score"><span id="zwsc">٠</span> / ' + toArabicDigits(placed.length) + '</p>' +
    '<div class="zws-grid" id="zwsg" dir="rtl" style="touch-action:none;user-select:none;-webkit-user-select:none"></div>' +
    '<div class="zws-list" id="zwsl">' + placed.map(p => '<span class="zws-w" data-w="' + p.w + '">' + p.w + '</span>').join('') + '</div><div id="zwsf"></div>';
  const g = root.querySelector('#zwsg');
  const cellAt = [];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const c = document.createElement('div'); c.className = 'zws-cell'; c.textContent = grid[y][x];
    g.appendChild(c); cellAt.push(c);
  }
  const hitCell = (px, py) => {
    const r = g.getBoundingClientRect();
    for (let i = 0; i < cellAt.length; i++) { const b = cellAt[i].getBoundingClientRect(); if (px >= b.left - 1.5 && px <= b.right + 1.5 && py >= b.top - 1.5 && py <= b.bottom + 1.5) return { x: i % N, y: Math.floor(i / N) }; }
    return null;
  };
  /* من أول حرف، الخط بيتثبّت على أقرب اتجاه من ٨ اتجاهات حسب مكان صباعك */
  const lineTo = (a, p) => {
    const b = cellAt[a.y * N + a.x].getBoundingClientRect(), cx = (b.left + b.right) / 2, cy = (b.top + b.bottom) / 2;
    const b2 = cellAt[1].getBoundingClientRect(), b0 = cellAt[0].getBoundingClientRect(), b9 = cellAt[N].getBoundingClientRect();
    const pw = Math.abs(b0.left - b2.left) || b.width, ph = Math.abs(b9.top - b0.top) || b.height;
    const rtl = getComputedStyle(g).direction === 'rtl' ? -1 : 1, ux = rtl * (p.x - cx) / pw, uy = (p.y - cy) / ph;
    if (Math.hypot(ux, uy) < 0.6) return [[a.x, a.y]];
    const k = Math.round(Math.atan2(uy, ux) / (Math.PI / 4)), dx = Math.round(Math.cos(k * Math.PI / 4)), dy = Math.round(Math.sin(k * Math.PI / 4));
    const len = Math.max(1, Math.round((ux * dx + uy * dy) / (dx * dx + dy * dy)));
    const out = [[a.x, a.y]];
    for (let i = 1; i <= len; i++) { const x = a.x + dx * i, y = a.y + dy * i; if (x < 0 || y < 0 || x >= N || y >= N) break; out.push([x, y]); }
    return out;
  };
  let start = null, cur = [];
  const paint = line => { cellAt.forEach(c => c.classList.remove('sel')); line.forEach(([x, y]) => cellAt[y * N + x].classList.add('sel')); cur = line; };
  g.addEventListener('pointerdown', e => { const c = hitCell(e.clientX, e.clientY); if (!c) return; start = c; try { g.setPointerCapture(e.pointerId); } catch (_) {} paint([[c.x, c.y]]); e.preventDefault(); });
  g.addEventListener('pointermove', e => { if (!start) return; paint(lineTo(start, { x: e.clientX, y: e.clientY })); });
  const finish = () => {
    if (!start) return; start = null;
    const line = cur; cellAt.forEach(c => c.classList.remove('sel')); cur = [];
    if (line.length < 2) return;
    const str = line.map(([x, y]) => grid[y][x]).join('');
    const hit = ws.placed.find(p => !ws.found.includes(p.w) && (p.w === str || p.w === str.split('').reverse().join('')));
    if (!hit) return;
    ws.found.push(hit.w);
    line.forEach(([x, y]) => cellAt[y * N + x].classList.add('found'));
    const tag = root.querySelector('.zws-w[data-w="' + hit.w + '"]'); if (tag) tag.classList.add('found');
    root.querySelector('#zwsc').textContent = toArabicDigits(ws.found.length);
    if (ws.found.length === ws.placed.length) {
      st.done++; zxpDone('ws');
      root.querySelector('#zwsf').innerHTML = '<p class="advice-src">لاقيتهم كلهم ✓</p><div class="game-actions"><span class="game-btn" id="zwsn" role="button">شبكة جديدة</span></div>';
      root.querySelector('#zwsn').onclick = () => zwsNew(root, st);
    }
  };
  g.addEventListener('pointerup', finish); g.addEventListener('pointercancel', () => { start = null; cellAt.forEach(c => c.classList.remove('sel')); });
}

/* ---------- لاقي الاختلافات: مشاهد مولّدة بالذكاء الاصطناعي، ٦ اختلافات في كل مشهد، الضغط من أي صورة ---------- */
/* x,y,نصف القطر كنسبة من عرض الصورة (y من عرضها هي كمان) */
const ZSD_SCENES = {"sd1": [[0.8771, 0.0856, 0.106], [0.366, 0.2072, 0.0825], [0.7486, 0.2376, 0.0742], [0.0552, 0.6768, 0.0631], [0.808, 0.6326, 0.077], [0.1727, 0.5594, 0.0797]], "sd2": [[0.8149, 0.1312, 0.1129], [0.2624, 0.0994, 0.0825], [0.1036, 0.5663, 0.0631], [0.9392, 0.6008, 0.0659], [0.5318, 0.6837, 0.0714], [0.5939, 0.3674, 0.0659]], "sd3": [[0.9047, 0.0483, 0.0852], [0.8425, 0.3619, 0.0742], [0.3729, 0.1865, 0.0922], [0.5801, 0.7113, 0.0687], [0.6215, 0.145, 0.0604], [0.6975, 0.5939, 0.0714]], "sd4": [[0.347, 0.081, 0.05], [0.928, 0.158, 0.05], [0.37, 0.217, 0.05], [0.533, 0.527, 0.05], [0.943, 0.532, 0.055], [0.765, 0.659, 0.053]], "sdg01": [[0.304, 0.0338, 0.05], [0.406, 0.048, 0.05], [0.051, 0.2025, 0.05], [0.208, 0.2363, 0.05], [0.189, 0.6675, 0.05], [0.95, 0.465, 0.07]], "sdg02": [[0.1, 0.15, 0.1], [0.81, 0.6525, 0.07], [0.325, 0.6075, 0.05], [0.675, 0.0225, 0.05], [0.96, 0.375, 0.06]], "sdg03": [[0.33, 0.615, 0.06], [0.24, 0.0562, 0.05], [0.115, 0.1875, 0.08], [0.15, 0.57, 0.08], [0.66, 0.4688, 0.05], [0.85, 0.66, 0.06]], "sdg04": [[0.69, 0.06, 0.05], [0.1, 0.285, 0.1], [0.705, 0.45, 0.05], [0.11, 0.5025, 0.1], [0.83, 0.5887, 0.08], [0.235, 0.585, 0.06]], "sdg05": [[0.12, 0.2475, 0.07], [0.14, 0.54, 0.08], [0.92, 0.1125, 0.12], [0.68, 0.0525, 0.05], [0.85, 0.2475, 0.05], [0.86, 0.63, 0.09]], "sdg06": [[0.19, 0.33, 0.08], [0.69, 0.18, 0.05], [0.47, 0.3975, 0.05], [0.58, 0.0525, 0.05], [0.86, 0.465, 0.1], [0.92, 0.075, 0.05]], "sdg07": [[0.35, 0.1425, 0.1], [0.54, 0.15, 0.13], [0.63, 0.4125, 0.06], [0.22, 0.6, 0.15], [0.77, 0.0825, 0.05], [0.93, 0.36, 0.06]], "sdg09": [[0.11, 0.6375, 0.05], [0.45, 0.1725, 0.07], [0.42, 0.06, 0.06], [0.6, 0.555, 0.1], [0.15, 0.48, 0.12], [0.91, 0.21, 0.06]], "sdg10": [[0.07, 0.27, 0.07], [0.31, 0.5625, 0.1], [0.075, 0.42, 0.05], [0.87, 0.075, 0.06], [0.87, 0.5887, 0.05], [0.94, 0.42, 0.05]], "sdg12": [[0.15, 0.3975, 0.05], [0.33, 0.375, 0.05], [0.67, 0.3075, 0.09], [0.49, 0.03, 0.05], [0.57, 0.075, 0.05], [0.855, 0.4125, 0.05], [0.15, 0.15, 0.17], [0.85, 0.585, 0.09]], "sdg14": [[0.65, 0.5475, 0.09], [0.85, 0.42, 0.1], [0.79, 0.09, 0.08], [0.125, 0.12, 0.05], [0.9, 0.6, 0.06], [0.92, 0.225, 0.15]], "sdg15": [[0.22, 0.0825, 0.08], [0.42, 0.1275, 0.05], [0.11, 0.54, 0.09], [0.94, 0.585, 0.06], [0.07, 0.1125, 0.09]], "sdg16": [[0.44, 0.2025, 0.05], [0.1, 0.4875, 0.05], [0.07, 0.1875, 0.06], [0.75, 0.645, 0.06], [0.92, 0.135, 0.18], [0.305, 0.045, 0.06]], "sdg17": [[0.65, 0.225, 0.07], [0.9, 0.2025, 0.08], [0.2, 0.4875, 0.17], [0.52, 0.6, 0.07], [0.85, 0.0525, 0.05], [0.52, 0.345, 0.15], [0.85, 0.615, 0.08]], "sdg18": [[0.19, 0.5175, 0.06], [0.68, 0.1087, 0.05], [0.87, 0.225, 0.05], [0.92, 0.4875, 0.1], [0.19, 0.2475, 0.07], [0.93, 0.315, 0.09]], "sdg19": [[0.14, 0.075, 0.07], [0.66, 0.3225, 0.06], [0.5, 0.3225, 0.05], [0.89, 0.6, 0.09], [0.37, 0.33, 0.07], [0.89, 0.0675, 0.08]], "sdg08": [[0.52, 0.0675, 0.05], [0.34, 0.0525, 0.055], [0.37, 0.1725, 0.05], [0.88, 0.4275, 0.07], [0.95, 0.5475, 0.07], [0.86, 0.075, 0.07]], "sdg13": [[0.07, 0.495, 0.1], [0.6, 0.615, 0.07], [0.295, 0.0375, 0.07], [0.7, 0.3, 0.1], [0.9, 0.4875, 0.12], [0.52, 0.585, 0.12]], "sdg23": [[0.75, 0.615, 0.13], [0.47, 0.3975, 0.07], [0.075, 0.225, 0.07], [0.17, 0.0525, 0.05], [0.95, 0.345, 0.1], [0.6, 0.1275, 0.12]], "sdg24": [[0.59, 0.4425, 0.08], [0.2, 0.6225, 0.08], [0.88, 0.0825, 0.05], [0.76, 0.3225, 0.1], [0.92, 0.285, 0.12], [0.92, 0.54, 0.07]], "sdg20": [[0.8, 0.3975, 0.1], [0.93, 0.42, 0.12], [0.745, 0.1125, 0.05], [0.12, 0.0675, 0.06], [0.86, 0.0525, 0.06], [0.115, 0.5475, 0.07]], "sdg27": [[0.38, 0.3, 0.05], [0.32, 0.075, 0.2], [0.56, 0.495, 0.07], [0.9, 0.1875, 0.15], [0.68, 0.0675, 0.05], [0.057, 0.5625, 0.07]], "sdg25": [[0.52, 0.2625, 0.07], [0.53, 0.06, 0.07], [0.1, 0.45, 0.15], [0.97, 0.4125, 0.06], [0.91, 0.5025, 0.05], [0.96, 0.2775, 0.06]], "sdg28": [[0.38, 0.6375, 0.06], [0.2, 0.63, 0.12], [0.17, 0.045, 0.05], [0.91, 0.105, 0.07], [0.12, 0.4275, 0.08], [0.82, 0.6675, 0.06]], "sdg29": [[0.64, 0.0675, 0.05], [0.12, 0.15, 0.1], [0.79, 0.06, 0.06], [0.6, 0.5625, 0.06], [0.2, 0.51, 0.05], [0.89, 0.405, 0.05], [0.93, 0.4312, 0.05]], "sdg30": [[0.42, 0.0525, 0.05], [0.57, 0.375, 0.05], [0.14, 0.075, 0.05], [0.9, 0.36, 0.06], [0.25, 0.06, 0.05], [0.88, 0.075, 0.12]], "sdg33": [[0.12, 0.1725, 0.08], [0.87, 0.0675, 0.06], [0.46, 0.225, 0.09], [0.53, 0.5025, 0.07], [0.82, 0.3, 0.06], [0.27, 0.1725, 0.07]], "sdg34": [[0.13, 0.09, 0.08], [0.31, 0.0825, 0.05], [0.14, 0.3975, 0.05], [0.46, 0.6075, 0.06], [0.94, 0.465, 0.07], [0.07, 0.5625, 0.08], [0.39, 0.5025, 0.06]], "sdg37": [[0.49, 0.075, 0.08], [0.94, 0.1125, 0.07], [0.93, 0.5175, 0.09], [0.38, 0.615, 0.08], [0.46, 0.4725, 0.06]], "sdg38": [[0.14, 0.1125, 0.12], [0.74, 0.045, 0.06], [0.9, 0.1125, 0.06], [0.91, 0.39, 0.07], [0.18, 0.255, 0.05], [0.89, 0.6825, 0.1], [0.02, 0.285, 0.05]], "sdg40": [[0.21, 0.1125, 0.05], [0.25, 0.51, 0.05], [0.21, 0.39, 0.05], [0.11, 0.51, 0.07], [0.83, 0.09, 0.15], [0.78, 0.255, 0.05]], "sdg41": [[0.17, 0.105, 0.14], [0.62, 0.39, 0.09], [0.11, 0.465, 0.08], [0.94, 0.1275, 0.06], [0.91, 0.5175, 0.06], [0.83, 0.6525, 0.05]], "sdg42": [[0.23, 0.06, 0.06], [0.12, 0.285, 0.08], [0.07, 0.465, 0.08], [0.03, 0.54, 0.06], [0.71, 0.5625, 0.09], [0.91, 0.5625, 0.07], [0.95, 0.225, 0.05]], "sdg43": [[0.35, 0.03, 0.05], [0.44, 0.225, 0.05], [0.25, 0.2475, 0.08], [0.06, 0.5175, 0.06], [0.82, 0.165, 0.26], [0.94, 0.4425, 0.07]], "sdg44": [[0.09, 0.1125, 0.1], [0.34, 0.06, 0.06], [0.29, 0.2025, 0.07], [0.13, 0.3225, 0.06], [0.08, 0.54, 0.09], [0.9, 0.5025, 0.08]], "sdg45": [[0.1, 0.1125, 0.06], [0.6, 0.06, 0.07], [0.65, 0.255, 0.08], [0.17, 0.5625, 0.08], [0.67, 0.5625, 0.09], [0.89, 0.6075, 0.1]], "sdg46": [[0.08, 0.1125, 0.06], [0.47, 0.0375, 0.1], [0.14, 0.375, 0.08], [0.35, 0.3525, 0.06], [0.28, 0.3825, 0.05], [0.93, 0.5625, 0.09]], "sdg47": [[0.13, 0.105, 0.06], [0.37, 0.1875, 0.05], [0.52, 0.54, 0.07], [0.355, 0.5325, 0.05], [0.14, 0.585, 0.07], [0.9, 0.615, 0.08]], "sdg48": [[0.77, 0.06, 0.06], [0.86, 0.2775, 0.05], [0.47, 0.42, 0.05], [0.33, 0.6375, 0.07], [0.74, 0.6375, 0.08], [0.1, 0.5025, 0.09]]};
const ZSD_ORDER = { q: [] };
function zsdNew(root, st) {
  st = st || { done: 0 };
  if (!ZSD_ORDER.q.length) ZSD_ORDER.q = zgShuffle(Object.keys(ZSD_SCENES));
  const key = ZSD_ORDER.q.pop(), diffs = ZSD_SCENES[key], found = [];
  ZG3.sd = { key, diffs, found };
  const imgBox = id => '<div class="zsd-img" id="' + id + '"><img src="img/' + key + '_' + id.slice(-1).toLowerCase() + '.jpg" alt="" draggable="false"><svg class="zsd-mk" viewBox="0 0 100 75" preserveAspectRatio="none"></svg></div>';
  root.innerHTML = '<p class="advice-src zg-score"><b id="zsdc">٠</b> / ' + toArabicDigits(diffs.length) + '</p>' + imgBox('zsdA') + imgBox('zsdB') + '<div id="zsdf"></div>';
  const mark = d => root.querySelectorAll('.zsd-mk').forEach(m => m.insertAdjacentHTML('beforeend', '<ellipse cx="' + (d[0] * 100) + '" cy="' + (d[1] * 100) + '" rx="' + (d[2] * 100 * 0.55) + '" ry="' + (d[2] * 100 * 0.55) + '" fill="none" stroke="#2E9E4F" stroke-width="0.9"/>'));
  const onTap = ev => {
    const el = ev.currentTarget, box = el.getBoundingClientRect();
    const x = (ev.clientX - box.left) / box.width, y = (ev.clientY - box.top) / box.width;
    const hit = diffs.reduce((bst, d, i) => { const dd = Math.hypot(x - d[0], y - d[1]); return (dd <= d[2] && (!bst || dd / d[2] < bst.q)) ? { d, i, q: dd / d[2] } : bst; }, null); const hitD = hit && !found.includes(hit.i) ? hit.d : null; const hitOld = hit && found.includes(hit.i);
    const f = root.querySelector('#zsdf');
    if (hitOld) return; if (!hitD) { f.textContent = ''; el.classList.add('miss'); setTimeout(() => el.classList.remove('miss'), 250); return; }
    found.push(diffs.indexOf(hitD)); mark(hitD);
    root.querySelector('#zsdc').textContent = toArabicDigits(found.length);
    if (found.length === diffs.length) {
      st.done++; zxpDone('diff');
      f.innerHTML = '<p class="advice-src">لقيت الاختلافات كلها ✓</p><div class="game-actions"><span class="game-btn" id="zsdn" role="button">مشهد جديد</span></div>';
      root.querySelector('#zsdn').onclick = () => zsdNew(root, st);
    }
  };
  root.querySelectorAll('.zsd-img').forEach(el => el.addEventListener('click', onTap));
}

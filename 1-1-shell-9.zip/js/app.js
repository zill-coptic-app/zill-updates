/* ظِلّ — app shell logic: theme, dates, router, home rendering. */
(function () {
  const THEME_KEY = 'zill.theme';
  const root = document.documentElement;
  const THEME_VARS = ['--bg1','--bg2','--bg3','--text','--gold','--gold2','--on-gold','--card-bg','--card-border','--dash','--muted'];
  const THEME_VAR_RE = /^[#a-zA-Z0-9 .,()%-]{1,60}$/;
  /* Palettes are pack-updatable content (theme-config pack). The bundled two
     mirror the stylesheet defaults (vars null = let the stylesheet rule);
     a verified update can add/replace palettes without an APK release. */
  let THEMES = [ { id: 'dark', name: 'داكن', base: 'dark', vars: null }, { id: 'light', name: 'فاتح', base: 'light', vars: null } ];
  function sanitizeThemes(list) {
    const out = [], seen = new Set();
    for (const t of Array.isArray(list) ? list : []) {
      if (!t || typeof t.id !== 'string' || !/^[a-z0-9-]{1,24}$/.test(t.id) || seen.has(t.id)) continue;
      if (typeof t.name !== 'string' || !t.name.trim() || t.name.length > 40) continue;
      const vars = {}; let n = 0, bad = 0;
      for (const k of Object.keys(t.vars || {})) {
        if (!THEME_VARS.includes(k)) { bad++; continue; }
        const v = String(t.vars[k] == null ? '' : t.vars[k]);
        if (!THEME_VAR_RE.test(v) || /url|expression|\/\//i.test(v)) { bad++; continue; }
        vars[k] = v; n++;
      }
      if (bad > 0 || n < 5) continue; // any suspect value rejects the whole palette; a palette must carry the core colors
      seen.add(t.id);
      out.push({ id: t.id, name: t.name.trim(), base: t.base === 'light' ? 'light' : 'dark', vars });
      if (out.length >= 12) break;
    }
    return out;
  }
  function themeById(id) { return THEMES.find(x => x.id === id) || THEMES.find(x => x.id === 'dark') || THEMES[0]; }
  function applyTheme(theme, noStore) {
    const t = themeById(theme);
    root.setAttribute('data-theme', t.base === 'light' ? 'light' : 'dark');
    THEME_VARS.forEach(k => root.style.removeProperty(k));
    if (t.vars) for (const k of Object.keys(t.vars)) root.style.setProperty(k, t.vars[k]);
    const light = t.base === 'light';
    const logo = document.getElementById('brandLogo'); if (logo) logo.src = light ? 'assets/img/logo_zill_light.png' : 'assets/img/logo_zill.png';
    if (!noStore) localStorage.setItem(THEME_KEY, t.id);
    const emBars = localStorage.getItem('zill.skin') !== 'classic' && !(t.vars && t.vars['--bg1']);
    const barColor = emBars ? (light ? '#EFF1DD' : '#0A2F26') : ((t.vars && t.vars['--bg1']) || (light ? '#FAF6EC' : '#101731'));
    try { const C = window.Capacitor, B = C && (C.registerPlugin ? C.registerPlugin('ZillBars') : C.Plugins && C.Plugins.ZillBars);
      if (B) B.set({ color: barColor, light }).catch(() => {}); } catch (e) {}
  }
  window.zRefreshBars = () => { try { applyTheme(localStorage.getItem(THEME_KEY) || 'dark', true); } catch (e) {} };
  window.zThemes = () => THEMES.map(t => ({ id: t.id, name: t.name }));
  async function initThemeConfig(saved, qp) {
    try {
      const cfg = await packLoadJson('theme-config', 'content/packs/theme-config.json');
      const list = sanitizeThemes(cfg && cfg.themes);
      if (list.length) THEMES = list;
    } catch (e) {}
    applyTheme(qp || saved || 'dark');
  }

  function initTheme() {
    const qp = new URLSearchParams(location.search).get('theme');
    const saved = localStorage.getItem(THEME_KEY);
    /* A saved palette may come from an updated pack not loaded yet: paint the
       default visually now, but never clobber the saved id before the pack
       config arrives (initThemeConfig re-applies with storage). */
    if (THEMES.some(t => t.id === (qp || saved))) applyTheme(qp || saved);
    else applyTheme('dark', true);
    try { applyReading(); } catch (e) {} try { applyFx(); } catch (e) {}
    initThemeConfig(saved, qp);
    initHomeCards();
    const btn = document.getElementById('btnTheme');
    if (btn) btn.addEventListener('click', () => {
      applyTheme(root.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
    });
  }

  function initDates() {
    const now = new Date(); /* Home date = the real civil date until midnight */
    const c = toCoptic(now);
    const chip = document.getElementById('copticChip');
    const greg = document.getElementById('gregDate');
    if (chip) chip.textContent = toArabicDigits(c.day) + ' ' + c.monthName + ' ' + toArabicDigits(c.year);
    if (greg) greg.textContent = formatGregorianAr(now);
  }

  const SECTIONS = [
    { id: 'bible',   name: 'الكتاب المقدس', sub: 'نص وصوت',        icon: '<svg viewBox="0 0 24 24"><path d="M12 6.5C10 4.8 7 4.5 4.5 5.2v13c2.5-.7 5.5-.4 7.5 1.3 2-1.7 5-2 7.5-1.3v-13C17 4.5 14 4.8 12 6.5Zm0 0v13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>' },
    { id: 'katameros', name: 'القطمارس',    sub: 'قراءات اليوم',   icon: '<svg viewBox="0 0 24 24"><path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3Z M8 8h7M8 11.5h7M8 15h4.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'today',   name: 'صلاة اليوم',    sub: 'آية وأصحاح',      icon: '<svg viewBox="0 0 24 24"><path d="M12 3v18M7 8h10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>' },
    { id: 'doctrine', name: 'العقيدة', sub: 'شرح واختبر نفسك', icon: '<svg viewBox="0 0 24 24"><path d="M12 3v18M6 9h12M8 21h8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="6" r="1.4" fill="currentColor"/></svg>' },
    { id: 'kids', name: 'قسم الأطفال', sub: 'حكايات بالصور (نموذج)', icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.4" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c.6-3.6 3.4-5.4 7-5.4s6.4 1.8 7 5.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'games2', name: 'ألعاب أكتر', sub: 'آيات وذاكرة', icon: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="13" y="4" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="13" width="7" height="7" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M16.5 14v6M13.5 17h6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'game',    name: 'مين الشخصية؟',  sub: 'لعبة تخمين',      icon: '<svg viewBox="0 0 24 24"><path d="M9.2 9a2.9 2.9 0 1 1 4 2.7c-.9.4-1.2 1-1.2 1.9M12 17.4v.1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>' },
    { id: 'snake',   name: 'الثعبان',       sub: 'لعبة تسلية',      icon: '<svg viewBox="0 0 24 24"><path d="M5 17c0-3 3-3 5-3s4 0 4-3-3-3-3-5 2-3 5-3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="18" cy="4.5" r="1.2" fill="currentColor"/></svg>' },
    { id: 'synax',   name: 'السنكسار',      sub: 'تذكارات القديسين', icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="9" r="4.4" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5.5 20c.8-3.4 3.4-5.2 6.5-5.2s5.7 1.8 6.5 5.2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'bios', name: 'السِّيَر', sub: 'قصص وحياة شخصيات', icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.4" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c.6-3.6 3.4-5.6 7-5.6s6.4 2 7 5.6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'fathers', name: 'أقوال وتأملات', sub: 'الآباء وعبارات عميقة', icon: '<svg viewBox="0 0 24 24"><path d="M7 8h4v4H8.5c0 1.6.8 2.5 2.5 2.7V17c-3-.2-4.5-2-4.5-5V8Zm7 0h4v4h-2.5c0 1.6.8 2.5 2.5 2.7V17c-3-.2-4.5-2-4.5-5V8Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>' },
    { id: 'crisis',  name: 'الأزمات',       sub: 'نصايح لوقت الشدة', icon: '<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>' },
    { id: 'agpeya',  name: 'الأجبية',       sub: 'صلوات السواعي',  icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="7.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 13V8.5M12 3v2M9 3h6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'tasbeha', name: 'التسبحة',       sub: 'ألحان ومدائح',    icon: '<svg viewBox="0 0 24 24"><path d="M9 18.5V6.8l9-2.3V16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.8" cy="18.5" r="2.3" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="15.8" cy="16" r="2.3" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>' },
    { id: 'books',   name: 'كتب وتفاسير',   sub: 'مكتبة روحية',     icon: '<svg viewBox="0 0 24 24"><path d="M5 5.5A1.5 1.5 0 0 1 6.5 4H19v14.5H6.5A1.5 1.5 0 0 0 5 20Z M5 18.5V5.5M9 8.5h6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>' },
    { id: 'suggest', name: 'اقتراحاتك', sub: 'اكتب اللي محتاجه', icon: '<svg viewBox="0 0 24 24"><path d="M4 20l1-4L16 5l3 3L8 19z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>' }
  ];


  /* Pack-driven home cards: a signed pack can reorder, hide, rename or
     re-icon the existing cards, and add cards whose ONLY target is a story
     (bundled or declared by the same pack). Icons come from a fixed registry
     (never pack-supplied markup). Any structural poison rejects the whole
     file; the bundled default is an empty overlay, so the look is unchanged. */
  const CARD_ICONS = {
    star: '<svg viewBox="0 0 24 24"><path d="M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8-5.3-2.8-5.3 2.8 1-5.8L3.5 9.7l5.9-.9Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M10 8.5v7l6-3.5Z" fill="currentColor"/></svg>',
    gift: '<svg viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="11" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 9v11M4 13.5h16M12 9c-4 0-5-2.5-3.5-3.5C10 4.5 12 7 12 9Zm0 0c4 0 5-2.5 3.5-3.5C14 4.5 12 7 12 9Z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
    bookopen: '<svg viewBox="0 0 24 24"><path d="M12 6.5C10 4.8 7 4.5 4.5 5.2v13c2.5-.7 5.5-.4 7.5 1.3 2-1.7 5-2 7.5-1.3v-13C17 4.5 14 4.8 12 6.5Zm0 0v13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };
  SECTIONS.forEach(s => { CARD_ICONS['sec:' + s.id] = s.icon; });
  const BUNDLED_STORIES = ['joseph_s1'];
  let HOME_OVER = null;   // validated overlay from the pack
  let HOME_ADD = [];      // validated added cards

  function sanitizeCardsCfg(cfg) {
    if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg)) return null;
    const known = SECTIONS.map(s => s.id);
    const txt = v => (typeof v === 'string' && v.length >= 1 && v.length <= 40 && !/[<>&"\\]/.test(v)) ? v : null;
    const out = { order: [], hide: [], rename: {}, icons: {}, add: [], stories: [] };
    if (cfg.stories !== undefined) {
      if (!Array.isArray(cfg.stories) || cfg.stories.length > 20 || cfg.stories.some(x => typeof x !== 'string' || !/^[a-z][a-z0-9_]{1,30}$/.test(x))) return null;
      out.stories = cfg.stories.slice();
    }
    if (cfg.order !== undefined) {
      if (!Array.isArray(cfg.order) || cfg.order.some(x => !known.includes(x)) || new Set(cfg.order).size !== cfg.order.length) return null;
      out.order = cfg.order.slice();
    }
    if (cfg.hide !== undefined) {
      if (!Array.isArray(cfg.hide) || cfg.hide.some(x => !known.includes(x))) return null;
      out.hide = cfg.hide.slice();
    }
    if (cfg.rename !== undefined) {
      if (!cfg.rename || typeof cfg.rename !== 'object' || Array.isArray(cfg.rename)) return null;
      for (const k of Object.keys(cfg.rename)) {
        if (!known.includes(k)) return null;
        const v = cfg.rename[k]; if (!v || typeof v !== 'object' || Array.isArray(v)) return null;
        const r = {};
        if (v.name !== undefined) { const t = txt(v.name); if (!t) return null; r.name = t; }
        if (v.sub !== undefined) { const t = txt(v.sub); if (!t) return null; r.sub = t; }
        out.rename[k] = r;
      }
    }
    if (cfg.icons !== undefined) {
      if (!cfg.icons || typeof cfg.icons !== 'object' || Array.isArray(cfg.icons)) return null;
      for (const k of Object.keys(cfg.icons)) {
        if (!known.includes(k) || typeof cfg.icons[k] !== 'string' || !CARD_ICONS[cfg.icons[k]]) return null;
        out.icons[k] = cfg.icons[k];
      }
    }
    if (cfg.add !== undefined) {
      if (!Array.isArray(cfg.add) || cfg.add.length > 6) return null;
      for (const c of cfg.add) {
        if (!c || typeof c !== 'object' || Array.isArray(c)) return null;
        if (typeof c.id !== 'string' || !/^pk_[a-z0-9_]{2,24}$/.test(c.id)) return null;
        if (known.includes(c.id) || out.add.some(x => x.id === c.id)) return null;
        const nm = txt(c.name); if (!nm) return null;
        let sb = '';
        if (c.sub !== undefined) { const t = txt(c.sub); if (!t) return null; sb = t; }
        const ic = (typeof c.icon === 'string' && CARD_ICONS[c.icon]) ? c.icon : 'star';
        const t = c.target;
        if (!t || typeof t !== 'object' || Array.isArray(t) || t.type !== 'story') return null;
        if (typeof t.id !== 'string' || !(BUNDLED_STORIES.includes(t.id) || out.stories.includes(t.id))) return null;
        out.add.push({ id: c.id, name: nm, sub: sb, icon: CARD_ICONS[ic], target: { type: 'story', id: t.id } });
      }
    }
    return out;
  }

  function mergedSections() {
    const base = SECTIONS.map(s => Object.assign({}, s));
    if (!HOME_OVER) return base;
    const ov = HOME_OVER;
    base.forEach(s => {
      const r = ov.rename[s.id];
      if (r) { if (r.name) s.name = r.name; if (r.sub) s.sub = r.sub; }
      if (ov.icons[s.id]) s.icon = CARD_ICONS[ov.icons[s.id]];
    });
    let list = base.filter(s => !ov.hide.includes(s.id));
    if (ov.order.length) {
      const pos = id => { const i = ov.order.indexOf(id); return i < 0 ? ov.order.length + SECTIONS.findIndex(x => x.id === id) : i; };
      list = list.slice().sort((a, b) => pos(a.id) - pos(b.id));
    }
    return list.concat(HOME_ADD.map(c => ({ id: c.id, name: c.name, sub: c.sub, icon: c.icon })));
  }

  async function initHomeCards() {
    try {
      const cfg = await packLoadJson('home-cards', 'content/packs/home-cards.json');
      const clean = sanitizeCardsCfg(cfg);
      if (clean) { HOME_OVER = clean; HOME_ADD = clean.add; renderSections(); }
    } catch (e) {}
  }

  const NAV = [
    { id: 'home',    label: 'الرئيسية', icon: '<svg viewBox="0 0 24 24"><path d="M4 11.5 12 4l8 7.5M6.5 10v9h11v-9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' },
    { id: 'book',    label: 'الكتاب',   icon: '<svg viewBox="0 0 24 24"><path d="M12 6.5C10 4.8 7 4.5 4.5 5.2v13c2.5-.7 5.5-.4 7.5 1.3 2-1.7 5-2 7.5-1.3v-13C17 4.5 14 4.8 12 6.5Zm0 0v13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' },
    { id: 'prayers', label: 'الصلوات',  icon: '<svg viewBox="0 0 24 24"><path d="M12 3v18M7 8h10M9.5 8V6.2M14.5 8V6.2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="12" r="8.6" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>' },
    { id: 'mine',    label: 'قراءاتي',  icon: '<svg viewBox="0 0 24 24"><path d="M6 4h12v16l-3-2-3 2-3-2-3 2Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>' }
  ];

  function renderSections() {
    const grid = document.getElementById('secGrid');
    if (!grid) return;
    grid.innerHTML = mergedSections().filter(s => !hiddenSections().includes(s.id)).map(s =>
      '<div class="sec-card" data-sec="' + s.id + '" role="button"><span class="sec-ic">' + s.icon + '</span>' +
      '<span class="sec-name">' + s.name + '</span></div>'
    ).join('');
  }

  function renderNav() {
    const nav = document.getElementById('bottomNav');
    if (!nav) return;
    if (nav.parentNode !== document.body) document.body.appendChild(nav);
    nav.innerHTML = NAV.map((n, i) =>
      '<button class="nav-item' + (i === 0 ? ' active' : '') + '" data-nav="' + n.id + '">' +
      '<span class="nav-ic">' + n.icon + '</span><span class="nav-lb">' + ((typeof zillUiLabel === 'function' && zillUiLabel(n.id)) || n.label) + '</span></button>'
    ).join('') + '<span class="nav-pill" id="navPill" aria-hidden="true"></span>';
    requestAnimationFrame(() => updateNavFor('home'));
  }

  // Glass capsule behind the active tab. Moves with transform only; no layout animation.
  function setNavActive(id, instant) {
    const nav = document.getElementById('bottomNav'), pill = document.getElementById('navPill');
    if (!nav || !pill) return;
    const items = nav.querySelectorAll('[data-nav]');
    let target = null;
    items.forEach(b => { const on = b.getAttribute('data-nav') === id; b.classList.toggle('active', on); if (on) target = b; });
    if (!target || !target.offsetWidth) return;
    const w = 72;
    pill.style.width = w + 'px';
    if (instant || !motionOn()) { pill.style.transition = 'none'; }
    pill.style.transform = 'translateX(' + Math.round(target.offsetLeft + target.offsetWidth / 2 - w / 2) + 'px)';
    if (instant || !motionOn()) { void pill.offsetWidth; pill.style.transition = ''; }
  }

  // Main tabs: home, bible list (book), favourites (mine), prayers placeholder. Other screens hide the bar.
  function navTabFor(id) {
    if (id === 'home') return 'home';
    if (id === 'bible') return 'book';
    if (id === 'favs') return 'mine';
    if (id === 'hymns' && document.documentElement.getAttribute('data-skin') === 'emerald') return 'home';
    if (id === 'read') {
      const t = document.getElementById('readTitle');
      if (t && t.firstChild && (t.firstChild.textContent === 'الصلوات' || t.firstChild.textContent === 'الأجبية')) return 'prayers';
    }
    return null;
  }
  function updateNavFor(id) {
    const nav = document.getElementById('bottomNav'); if (!nav) return;
    const tab = navTabFor(id);
    const wasShown = nav.dataset.shown === '1';
    nav.hidden = !tab;
    nav.dataset.shown = tab ? '1' : '0';
    if (tab) requestAnimationFrame(() => setNavActive(tab, !wasShown));
  }

  let KAT_SHOWN = katDate().toDateString() + '|' + new Date().toDateString();
  const katKey = () => katDate().toDateString() + '|' + new Date().toDateString();
  let TODAY = null; // { coptic, day } for the real civil day
  let KATV = null;  // Katameros view: after 17:00 = today's Matins+Liturgy + tomorrow's Vespers (the liturgical day starts at sunset)
  async function refreshKat() {
    TODAY = await readingsForDate(new Date());
    KATV = null;
    const kd = katDate(), nd = new Date();
    if (kd.getDate() !== nd.getDate() && TODAY && TODAY.day) {
      const tm = await readingsForDate(kd);
      const ves = tm && tm.day && (tm.day.sections || []).find(s => s.title === 'العشية' && (s.subs || []).some(u => (u.readings || []).some(r => (r.passages || []).length)));
      if (ves) {
        const rest = (TODAY.day.sections || []).filter(s => s.title !== 'العشية');
        KATV = { coptic: TODAY.coptic, day: Object.assign({}, TODAY.day, { sections: rest.concat([Object.assign({}, ves, { title: 'عشية ' + toArabicDigits(kd.getDate()) + ' ' + GREG_MONTHS_AR[kd.getMonth()] })]) }) };
      }
    }
  }

  function renderReadings() {
    const rows = document.getElementById('readingsRows');
    if (!rows) return;
    const KV = KATV || TODAY; const items = KV && KV.day ? readingRowsForDay(KV.day) : [];
    const eveEl = document.getElementById('readingsEve');
    if (eveEl) { const kd = katDate(), nd = new Date(); const eve = !!KATV; eveEl.hidden = !eve; if (eve) eveEl.textContent = 'العشية: قراءات ليلة ' + formatGregorianAr(kd) + ' (باكر والقداس لليوم)'; }
    if (!items.length) {
      rows.innerHTML = '<div class="rd-row"><span class="rd-ref" style="opacity:.65">قراءات النهاردة مش متوفرة في النسخة دي.</span></div>';
      return;
    }
    rows.innerHTML = items.map((r, i) =>
      '<div class="rd-row" data-row="' + i + '" role="button"><span class="rd-tag">' + packText(r.tag) + '</span><span class="rd-ref">' + (r.label) + '</span></div>'
    ).join('');
    rows.querySelectorAll('[data-row]').forEach(el => {
      el.addEventListener('click', () => {
        const r = items[+el.getAttribute('data-row')];
        openDayReadings(r.secIdx, r.subIdx);
      });
    });
  }


  /* tap the home verse: full designed view + share as image (same card the share export draws; no app controls in the image) */
  function openVerseView() {
    const tx = document.getElementById('hqTx'), src = document.getElementById('hqSrc'); if (!tx || !tx.textContent) return;
    const text = tx.textContent.replace(/^[«»\s]+|[«»\s]+$/g, ''), ref = src.textContent.trim();
    let ov = document.getElementById('vOver');
    if (!ov) {
      ov = document.createElement('div'); ov.id = 'vOver'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'آية اليوم');
      ov.innerHTML = '<div class="vo-card"><img id="voImg" alt=""></div><div class="vo-msg" id="voMsg" role="status"></div><div class="vo-row"><button data-vo="img">شارك كصورة</button><button data-vo="copy">نسخ</button><button data-vo="save">حفظ الصورة</button><button data-vo="x">إغلاق</button></div>';
      document.body.appendChild(ov);
      ov.addEventListener('click', async ev => {
        const b = ev.target.closest('[data-vo]'); if (!b) { if (ev.target === ov) ov.hidden = true; return; }
        const k = b.dataset.vo; if (k === 'x') { ov.hidden = true; return; }
        const t = ov.dataset.t, r = ov.dataset.r, msg = document.getElementById('voMsg');
        const res = k === 'copy' ? await zCopy(t, r) : k === 'save' ? await zSaveImage(t, r) : await zShareImage(t, r);
        msg.textContent = ({ copied: 'اتنسخت الآية مع المرجع', shared: '', cancelled: '', saved: 'اتحفظت الصورة', savefail: 'ما نفعش. جرّب تاني', downloaded: 'اتحفظت الصورة', failed: 'ما نفعش. جرّب تاني', toolong: 'الآية طويلة على الصورة' })[res] || '';
      });
    }
    ov.dataset.t = text; ov.dataset.r = ref; document.getElementById('voMsg').textContent = '';
    ov.hidden = false;
    verseCanvas(text, ref).then(c => { if (c) document.getElementById('voImg').src = c.toDataURL('image/png'); else document.getElementById('voMsg').textContent = 'الآية طويلة على الصورة'; });
  }
  (function () { const hq = document.getElementById('homeQuote'); if (hq) { hq.setAttribute('role', 'button'); hq.addEventListener('click', openVerseView); } })();

  async function renderHomeQuote() {
    const box = document.getElementById('homeQuote'); if (!box) return;
    try {
      const Q = (await packLoadJson('quotes-ar', 'content/packs/quotes-ar.json')).verses || [];
      const F = (typeof ZX !== 'undefined' && ZX.fathers) || [];
      const pool = Q.map(q => ({ k: 'v', q })).concat(F.map(f => ({ k: 'f', f })));
      if (!pool.length) return;
      // mix: every 4th day a father saying, otherwise a verse
      const di = dayIndex(new Date());
      const useF = false; // fathers' sayings stay out of the hero until quotation provenance is checked
      const it = useF ? { k: 'f', f: F[Math.floor(di / 4) % F.length] } : { k: 'v', q: Q[di % Q.length] };
      const tx = document.getElementById('hqTx'), src = document.getElementById('hqSrc');
      if (it.k === 'v') {
        const tash = (typeof setLoad === 'function' ? setLoad().tash : '1') !== '0';
        tx.textContent = tash ? it.q.t : it.q.p;
        src.innerHTML = packText(it.q.r).replace(/^(.+?)\s*(\d+):(\d+)$/, (m, n, c, v) => n + ' <bdi dir="ltr">' + toArabicDigits(c) + ':' + toArabicDigits(v) + '</bdi>');
      } else {
        tx.textContent = '«' + it.f.ar + '»';
        src.textContent = it.f.who;
      }
      box.hidden = false;
    } catch (e) {}
  }

  function renderAdvice(pack) {
    const card = document.getElementById('adviceCard');
    if (!card) return;
    const a = adviceForToday(pack, new Date());
    if (!a) return;
    document.getElementById('adviceCat').textContent = a.crisis;
    document.getElementById('adviceTx').textContent = a.tip.replace(/\n/g, ' ، ');
    const av = document.getElementById('adviceVs'); if (av) { if (a.verse) { av.textContent = '«' + a.verse + '» ' + toArabicDigits(a.vref); av.hidden = false; } else av.hidden = true; }
    card.hidden = false;
  }

  const SCREENS = ['home', 'read', 'bible', 'favs', 'game', 'snake', 'settings', 'hymns'];
  // Navigation motion: transform + opacity only (cheap on weak phones). Old screen leaves as a static ghost copy.
  let NAV_STACK = ['home'], NAV_ORIGIN = { x: 0.5, y: 0.5 };
  document.addEventListener('pointerdown', ev => { NAV_ORIGIN = { x: ev.clientX / window.innerWidth, y: ev.clientY / window.innerHeight }; }, true);
  function motionOn() { return document.documentElement.dataset.motion !== '0'; }
  function showScreen(id) {
    updateNavFor(id);
    if (id !== 'snake' && typeof snakeStop === 'function') snakeStop();
    const curEl = SCREENS.map(s => document.getElementById('scr-' + s)).find(e => e && !e.hidden);
    const curId = curEl ? curEl.id.replace('scr-', '') : null;
    SCREENS.forEach(s => { document.getElementById('scr-' + s).hidden = (s !== id); });
    if (!curEl || curId === id || !motionOn() || !curEl.animate) return;
    let back = false;
    if (id === 'home') { back = true; NAV_STACK = ['home']; }
    else if (NAV_STACK.length > 1 && NAV_STACK[NAV_STACK.length - 2] === id) { back = true; NAV_STACK.pop(); }
    else NAV_STACK.push(id);
    const nextEl = document.getElementById('scr-' + id);
    const ghost = curEl.cloneNode(true); ghost.removeAttribute('id'); ghost.querySelectorAll('[id]').forEach(n => n.removeAttribute('id'));
    ghost.hidden = false; ghost.setAttribute('aria-hidden', 'true'); ghost.style.pointerEvents = 'none'; ghost.style.zIndex = back ? '5' : '1'; nextEl.style.zIndex = back ? '1' : '5';
    document.body.appendChild(ghost);
    const o = (NAV_ORIGIN.x * 100).toFixed(0) + '% ' + (NAV_ORIGIN.y * 100).toFixed(0) + '%';
    const ease = 'cubic-bezier(.2,.8,.2,1)', dur = 320;
    // RTL: going forward the new page slides in from the left edge; going back it returns from the right. Transform + opacity only.
    const inKf = back ? [{ opacity: 0, transform: 'translate3d(28%,0,0)' }, { opacity: 1, transform: 'none' }] : [{ opacity: 0, transform: 'translate3d(-28%,0,0)' }, { opacity: 1, transform: 'none' }];
    const outKf = back ? [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translate3d(-18%,0,0)' }] : [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translate3d(18%,0,0)' }];
    nextEl.style.transformOrigin = o; ghost.style.transformOrigin = o;
    nextEl.animate(inKf, { duration: dur, easing: ease }).finished.then(() => { nextEl.style.zIndex = ''; nextEl.style.transformOrigin = ''; }).catch(() => {});
    ghost.animate(outKf, { duration: dur * 0.85, easing: ease, fill: 'forwards' }).finished.then(() => ghost.remove()).catch(() => ghost.remove());
    setTimeout(() => { if (ghost.isConnected) ghost.remove(); }, dur + 150);
  }
  function applyFx() {
    const st = setLoad(), r = document.documentElement.dataset;
    const weak = (navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2);
    const rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    r.motion = st.fx !== undefined ? st.fx : (rm ? '0' : '1'); /* user choice wins; otherwise respect the OS reduced-motion accessibility setting; no hardware-based auto-disable */
    r.glass = st.fg !== undefined ? st.fg : (weak ? '0' : '1');
  }

  function copticDateLine(c) {
    return toArabicDigits(c.day) + ' ' + c.monthName + ' ' + toArabicDigits(c.year);
  }

  // Context of what the read screen currently shows (for favorites).
  let READ_CTX = null;

  function setReadCtx(ctx) {
    READ_CTX = ctx; try { clearVerseSel(); } catch (e) {}
    const btn = document.getElementById('readFav'); if (btn) btn.style.visibility = ctx ? 'visible' : 'hidden';
    if (btn) btn.classList.toggle('faved', !!(ctx && favsHas(ctx.id)));
  }

  function openDayReadings(secIdx, subIdx, target) {
    const t = target || KATV || TODAY;
    if (!t || !t.day) return;
    const head = document.getElementById('readTitle');
    head.firstChild.textContent = 'قراءات اليوم';
    document.getElementById('readSub').textContent = copticDateLine(t.coptic);
    document.getElementById('readHead').textContent =
      (t.day.title ? t.day.title + ' — ' : '') + formatGregorianAr(new Date(t.day.gregorian + 'T12:00:00'));
    const rbEl = document.getElementById('readBody');
    const parts = daySectionsList(t.day);
    if (secIdx === undefined && parts.length > 1) {
      rbEl.innerHTML = '<select id="dayTabs" class="agp-sel sec-sel" aria-label="العناوين">' + parts.map(p => '<option value="' + p.si + '">' + p.title + '</option>').join('') + '</select><div id="dayPart">' + dayReadingsHTML(t.day, parts[0].si) + '</div>';
      document.getElementById('dayTabs').onchange = e => {
        document.getElementById('dayPart').innerHTML = dayReadingsHTML(t.day, +e.target.value);
        const rs = document.querySelector('#scr-read .read-scroll'); if (rs) rs.scrollTop = 0;
      };
    } else rbEl.innerHTML = dayReadingsHTML(t.day, secIdx, subIdx);
    const c = t.coptic;
    setReadCtx({
      id: 'day:' + c.year + '-' + c.month + '-' + c.day + ':' + (secIdx === undefined ? 'full' : secIdx + ':' + subIdx),
      kind: 'day', cy: c.year, cm: c.month, cd: c.day, si: secIdx, ui: subIdx,
      title: 'قراءات ' + copticDateLine(c)
    });
    showScreen('read');
  }

  async function openSynax(cm, cd, cy) {
    const fake = new Date(2026, 0, 1);
    const { entries } = await synaxEntries(cm, cd);
    const coptic = { year: cy || (TODAY ? TODAY.coptic.year : 1743), month: cm, day: cd, monthName: COPTIC_MONTHS[cm - 1] };
    const head = document.getElementById('readTitle');
    head.firstChild.textContent = 'السنكسار';
    document.getElementById('readSub').textContent = copticDateLine(coptic);
    document.getElementById('readHead').textContent = 'تذكارات اليوم';
    document.getElementById('readBody').innerHTML = entries.length
      ? entries.map(e => '<h2 class="rd-sec-title">' + packText(e.title) + '</h2><div class="synax-tx">' + packSanHtml(e.text) + '</div>').join('')
      : '<p class="rd-intro">مفيش تذكار مسجل لليوم ده.</p>';
    sectionize(document.getElementById('readBody'));
    setReadCtx({ id: 'synax:' + cm + '-' + cd, kind: 'synax', cm, cd, cy: coptic.year, title: 'سنكسار ' + copticDateLine(coptic) });
    showScreen('read');
  }

  async function openSynaxToday() {
    const c = toCoptic(new Date());
    await openSynax(c.month, c.day, c.year);
  }



  /* الأجبية: texts baked by tools/bake_agpeya.py from the MIT-licensed coptic.io data (Arabic). Gospel passages and Psalm 50 come from the app's Van Dyck pack. */
  let AGPEYA = null;
  async function agpeyaLoad() {
    if (AGPEYA) return AGPEYA;
    try { AGPEYA = await packLoadJson('agpeya-ar', 'content/packs/agpeya-ar.json'); } catch (e) {}
    /* الستار وصلوات أخرى: ملف منفصل (مصادره في الحقل source)، لو اتعذّر تحميله باقي الأجبية تفضل شغالة */
    if (AGPEYA) { try { const X = await packLoadJson('agpeya-other-ar', 'content/packs/agpeya-other-ar.json'); (X.hours || []).forEach(h => { if (!AGPEYA.hours.some(y => y.id === h.id)) AGPEYA.hours.push(h); }); } catch (e) {} }
    return AGPEYA;
  }
  const agEsc = s => String(s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  /* الأجبية: pick the prayer, then the part inside it; parts are in the prayer's own order. Swipe right on empty space = next part. */
  const AG = { hour: 'prime', i: 0 };
  const AG_ORDER = ['prime', 'terce', 'sext', 'none', 'vespers', 'compline', 'midnight', 'veil', 'other'];
  const agNum = n => toArabicDigits(n);
  function agLabel(s, i) { return agNum(i + 1) + '. ' + s.t + (s.r ? ' (' + s.r.replace(/\d+/g, m => agNum(m)) + ')' : ''); }
  async function openAgpeya(hour) {
    const P = await agpeyaLoad();
    if (!P) { zxShow('الأجبية', 'صلوات السواعي', 'تعذّر التحميل', '<p class="rd-intro">جرّب مرة تانية.</p>', 'home'); return; }
    if (hour) { AG.hour = hour; AG.i = 0; }
    const hs = AG_ORDER.map(id => P.hours.find(h => h.id === id)).filter(Boolean);
    zxShow('الأجبية', 'صلوات السواعي', 'اختار الصلاة وبعدها الجزء',
      '<div class="agp-sels"><select id="agHour" class="agp-sel" aria-label="الصلاة">' + hs.map(h => '<option value="' + h.id + '">' + agEsc(h.n) + '</option>').join('') + '</select>' +
      '<select id="agSec" class="agp-sel" aria-label="الجزء"></select></div>' +
      '<div id="agBody" class="agp-body"></div>' +
      '<div class="agp-nav"><span class="game-btn ghost" id="agPrev" role="button">السابق</span><span class="agp-pos" id="agPos"></span><span class="game-btn" id="agNext" role="button">التالي</span></div>' +
      '<p class="rd-intro agp-note">خدمات نصف الليل الثلاث لسه مش مضافة.</p>', 'home');
    document.getElementById('agHour').value = AG.hour;
    document.getElementById('agHour').onchange = e => { AG.hour = e.target.value; AG.i = 0; agRender(); };
    document.getElementById('agSec').onchange = e => { AG.i = +e.target.value; agRender(true); };
    document.getElementById('agPrev').onclick = () => agStep(-1);
    document.getElementById('agNext').onclick = () => agStep(1);
    const body = document.getElementById('agBody'); let t0 = null;
    body.addEventListener('touchstart', e => { t0 = e.touches.length === 1 ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : null; }, { passive: true });
    body.addEventListener('touchend', e => { if (!t0) return; const t = e.changedTouches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y; t0 = null;
      if (Math.abs(dx) > 60 && Math.abs(dx) > 1.6 * Math.abs(dy)) agStep(dx > 0 ? 1 : -1); }, { passive: true });
    agRender();
  }
  function agStep(d) { const h = AGPEYA.hours.find(x => x.id === AG.hour); const n = AG.i + d; if (!h || n < 0 || n >= h.s.length) return; AG.i = n; agRender(true); }
  function agRender(keepScroll) {
    const h = AGPEYA.hours.find(x => x.id === AG.hour); if (!h) return;
    if (AG.i >= h.s.length) AG.i = 0;
    const sel = document.getElementById('agSec');
    if (sel.dataset.h !== h.id) { sel.innerHTML = h.s.map((s, i) => '<option value="' + i + '">' + agEsc(agLabel(s, i)) + '</option>').join(''); sel.dataset.h = h.id; }
    sel.value = String(AG.i);
    const s = h.s[AG.i];
    document.getElementById('agBody').innerHTML = (AG.i === 0 && h.intro ? '<p class="rd-intro">' + agEsc(h.intro) + '</p>' : '') +
      '<h2 class="rd-sec-title">' + agEsc(s.t) + '</h2>' + (s.r ? '<p class="rd-ref-line">' + agEsc(s.r.replace(/\d+/g, m => agNum(m))) + '</p>' : '') +
      '<div class="synax-tx">' + s.p.map(x => '<p>' + agEsc(typeof x === 'string' ? x : (x && x.text) || '') + '</p>').join('') + '</div>';
    document.getElementById('agPos').textContent = agNum(AG.i + 1) + ' / ' + agNum(h.s.length);
    document.getElementById('agPrev').style.visibility = AG.i === 0 ? 'hidden' : 'visible';
    document.getElementById('agNext').style.visibility = AG.i === h.s.length - 1 ? 'hidden' : 'visible';
    const GAP = { vespers: 'مزامير هذه الساعة لسه مش مضافة في النسخة دي.', compline: 'مزامير هذه الساعة لسه ناقصة في النسخة دي (المزمور المذكور فقط).' };
    if (GAP[h.id] && AG.i === 0) document.getElementById('agBody').insertAdjacentHTML('afterbegin', '<p class="rd-intro" style="color:var(--gold,#e6b450)">' + GAP[h.id] + '</p>');
    const rs = document.querySelector('#scr-read .read-scroll'); if (rs && !keepScroll) rs.scrollTop = 0; else if (rs) rs.scrollTop = 0;
  }

  function zxLink(u, t) { return '<a class="zx-link" href="' + u + '" rel="noopener noreferrer"><bdi dir="ltr">' + t + '</bdi></a>'; }
  /* Every heading in a content screen goes into one dropdown; pick it and read only that part. */
  function sectionize(rb) {
    if (!rb) return;
    const kids = Array.from(rb.children);
    const hs = kids.filter(k => k.tagName === 'H2' && k.classList.contains('rd-sec-title'));
    if (hs.length < 2) return;
    const pre = [], secs = []; let cur = null;
    kids.forEach(k => { if (hs.includes(k)) { cur = { t: k.textContent, nodes: [] }; secs.push(cur); k.remove(); } else if (cur) cur.nodes.push(k); else pre.push(k); });
    const sel = document.createElement('select'); sel.className = 'agp-sel sec-sel'; sel.setAttribute('aria-label', 'العناوين');
    sel.innerHTML = secs.map((s, i) => '<option value="' + i + '">' + agEsc(s.t) + '</option>').join('');
    const panes = secs.map(s => { const d = document.createElement('div'); d.className = 'sec-pane'; s.nodes.forEach(n => d.appendChild(n)); return d; });
    const show = i => panes.forEach((d, j) => { d.hidden = j !== i; });
    sel.onchange = () => { show(+sel.value); const rs = document.querySelector('#scr-read .read-scroll'); if (rs) rs.scrollTop = 0; };
    rb.innerHTML = ''; pre.forEach(n => rb.appendChild(n)); rb.appendChild(sel); panes.forEach(d => rb.appendChild(d)); show(0);
  }
  window.zxShowPage = function (t, s, h, html, back) { return zxShow(t, s, h, html, back); };
  window.zxOpenChapterOfDay = async function () { const pack = await bibleLoad(); if (!pack) return; const c = chapterOfDay(pack, new Date()); BIBLE.book = c.book; openBibleChapter(c.ch); READ_BACK = 'home'; };
  function zxShow(title, sub, head, html, back) {
    document.getElementById('readTitle').firstChild.textContent = title;
    document.getElementById('readSub').textContent = /^سؤال/.test(sub) ? sub : '';
    document.getElementById('readHead').textContent = /^(اختار|اقتراح جديد|نموذج أول)/.test(head) ? '' : head;
    document.getElementById('readBody').innerHTML = html; sectionize(document.getElementById('readBody'));
    setReadCtx(null); READ_BACK = back; showScreen('read');
    const rb = document.getElementById('readBody'); if (rb && rb.animate && motionOn()) rb.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 240, easing: 'cubic-bezier(.22,.8,.24,1)' });
  }
  function openKids() {
    zxShow('قسم الأطفال', 'حكايات بالصور', 'نموذج أول',
      '<p class="advice-src">الصور رسم بالذكاء الاصطناعي لتوضيح الحكاية.</p>' +
      '<div class="kids-card" role="button" id="kidsJ1"><img class="kids-card-img" src="img/kids/joseph/b1.webp" alt="حكاية يوسف"><span class="kids-card-name">يوسف</span></div>', 'home');
    const a = document.getElementById('kidsJ1');
    if (a) a.onclick = () => zKidsOpen('joseph_s1');
  }
  function openFathersHub() {
    zxShow('أقوال وتأملات', 'للقراءة والتأمل', 'اختار', '<div class="bk-list">' +
      '<div class="bk-row" role="button" data-zx="fathers"><span class="bk-name">أقوال الآباء</span></div>' +
      '<div class="bk-row" role="button" data-zx="homilies"><span class="bk-name">عظات كاملة</span></div>' +
      '<div class="bk-row" role="button" data-zx="reflect"><span class="bk-name">عبارات تأملية</span></div></div>' +
      '', 'home');
    document.querySelectorAll('[data-zx]').forEach(el => el.onclick = () => { const k = el.getAttribute('data-zx'); if (k === 'fathers') openFathers(); else if (k === 'homilies') openHomilies(); else openReflect(); });
  }
  function openFathers() {
    const P = FATHER_IDS().map(f => Object.assign(f, { id: fatherKey(f.who) }));
    zxShow('أقوال الآباء', 'اختار أبّ', 'أقوال الآباء', pcGrid('father', P, 'data-father'), 'fathers');
    document.querySelectorAll('.pc[data-father]').forEach(el => el.onclick = () => openFatherPerson(el.getAttribute('data-father')));
  }
  function openFatherPerson(key) {
    const list = ZX.fathers.filter(f => fatherKey(f.who) === key); if (!list.length) return;
    const im = (PC_IMG.father || {})[key];
    zxShow(list[0].who, 'أقواله', list[0].who,
      (im ? '<div class="pc-hero"><img src="img/people/' + im + '.jpg" alt=""></div>' : '') +
      list.map(f => '<div class="tip-blk"><div class="synax-tx"><p>«' + f.ar + '»</p></div><p class="advice-src">' + f.work + '</p></div>').join(''), 'fatherlist');
  }
  function openReflect() {
    zxShow('عبارات تأملية', 'للتأمل', 'عبارات تأملية',
      '' +
      ZX.reflections.map(t => '<div class="tip-blk"><div class="synax-tx"><p>' + t + '</p></div></div>').join(''), 'fathers');
  }
  function zxVerses(r) {
    const book = BIBLE.pack && BIBLE.pack.books.find(b => b.id === r[0]); if (!book) return '';
    const nm = book.name, ch = r[1], v1 = r[2], v2 = r[3] || r[2], out = [];
    for (let v = v1; v <= v2; v++) { const t = book.chapters[String(ch)] && book.chapters[String(ch)][String(v)]; if (t) out.push(tashText(r[0], ch, v, t)); }
    return '<p class="verse">' + out.join(' ') + '</p><p class="advice-src">' + nm + ' <bdi dir="ltr">' + toArabicDigits(ch) + ':' + toArabicDigits(v1) + (v2 !== v1 ? '\u200E-' + toArabicDigits(v2) : '') + '</bdi></p>';
  }
  async function openDoctrine() {
    await bibleLoad();
    zxShow('العقيدة', 'شرح واختبر نفسك', 'العقيدة', '<div class="bk-list">' +
      ZX.doctrine.map(d => '<div class="bk-row" role="button" data-doc="' + d.id + '"><span class="bk-name">' + d.title + '</span></div>').join('') + '<div class="bk-row" role="button" data-doc="quiz"><span class="bk-name">اختبر نفسك</span><span class="bk-meta">أسئلة بشرح</span></div>' + ((window.ZILL_FAQ && ZILL_FAQ.items.length) ? '<div class="bk-row" role="button" data-doc="faq"><span class="bk-name">أسئلة وأجوبة</span><span class="bk-meta">' + toArabicDigits(ZILL_FAQ.items.length) + ' سؤال</span></div>' : '') + '</div>' +
      '', 'home');
    document.querySelectorAll('[data-doc]').forEach(el => el.onclick = () => { const k = el.getAttribute('data-doc'); if (k === 'quiz') openQuizMenu(); else if (k === 'faq') openFaq(); else openDoctrineItem(k); });
  }

  // ---- Q&A bank (reviewed entries only; sources stay in the data, never shown) ----
  const faqEsc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const faqNorm = t => String(t).replace(/[\u064B-\u065F\u0670]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
  function openFaq() {
    const F = window.ZILL_FAQ; if (!F || !F.items.length) return;
    zxShow('أسئلة وأجوبة', 'العقيدة', 'أسئلة وأجوبة',
      '<input id="faqQ" class="zx-search" type="search" placeholder="ابحث في الأسئلة" aria-label="بحث" style="width:100%;box-sizing:border-box;padding:12px;margin-bottom:10px;border-radius:12px;font:inherit">' +
      '<div class="bk-list" id="faqList"></div>', 'doctrine');
    const draw = () => {
      const q = faqNorm(document.getElementById('faqQ').value.trim());
      let h = '';
      F.topics.forEach(tp => {
        const its = F.items.filter(i => i.topic === tp && (!q || faqNorm(i.q + ' ' + i.s.map(x => x[1].join(' ')).join(' ')).includes(q)));
        if (!its.length) return;
        h += '<h2 class="rd-sec-title">' + faqEsc(tp) + '</h2>' + its.map(i => '<div class="bk-row" role="button" data-faq="' + i.id + '"><span class="bk-name">' + faqEsc(i.q) + '</span></div>').join('');
      });
      document.getElementById('faqList').innerHTML = h || '<div class="synax-tx"><p>مفيش نتيجة</p></div>';
      document.querySelectorAll('[data-faq]').forEach(el => el.onclick = () => openFaqItem(el.getAttribute('data-faq')));
    };
    document.getElementById('faqQ').oninput = draw; draw();
  }
  function openFaqItem(id) {
    const i = window.ZILL_FAQ.items.find(x => x.id === id); if (!i) return;
    zxShow(i.q, i.topic, i.q, i.s.map(sc => (sc[0] ? '<h2 class="rd-sec-title">' + faqEsc(sc[0]) + '</h2>' : '') + '<div class="synax-tx">' + sc[1].map(p => '<p>' + faqEsc(p) + '</p>').join('') + (sc[2] ? '<p class="advice-src">' + faqEsc(sc[2]) + '</p>' : '') + '</div>').join(''), 'faqlist');
  }
  function openDoctrineItem(id) {
    const d = ZX.doctrine.find(x => x.id === id); if (!d) return;
    zxShow(d.title, 'العقيدة', d.title,
      '<div class="synax-tx"><p>' + d.ex + '</p>' + (d.ex2 ? '<p>' + d.ex2 + '</p>' : '') + '</div>' +
      '<h2 class="rd-sec-title">من الكتاب المقدس</h2>' + d.refs.map(zxVerses).join('') +
      '', 'doctrine');
  }

  async function openMoreGames() {
    await bibleLoad();
    zxShow('ألعاب أكتر', '', '', '<div class="bk-list">' +
      '<div class="bk-row" role="button" data-mg="complete"><span class="bk-name">كمّل الآية</span></div>' +
      '<div class="bk-row" role="button" data-mg="order"><span class="bk-name">رتّب الآية</span></div>' +
      '<div class="bk-row" role="button" data-mg="memory"><span class="bk-name">ذاكرة الرموز</span></div>' +
      '<div class="bk-row" role="button" data-mg="tf"><span class="bk-name">صح ولا غلط</span></div>' +
      '<div class="bk-row" role="button" data-mg="maze"><span class="bk-name">متاهة الفلك</span></div>' +
      '<div class="bk-row" role="button" data-mg="ws"><span class="bk-name">دوّر على الكلمات</span></div>' +
      '<div class="bk-row" role="button" data-mg="sd"><span class="bk-name">لاقي الاختلافات</span></div>' +
      '<div class="bk-row" role="button" id="xpGJ"><span class="bk-name">رحلتي في ظل (نقاط الألعاب)</span></div></div>' +
      '', 'home');
    document.querySelectorAll('[data-mg]').forEach(el => el.onclick = () => openMG(el.getAttribute('data-mg')));
    const xg = document.getElementById('xpGJ'); if (xg) xg.onclick = () => window.ZXPUI && ZXPUI.journey();
  }
  function openMG(k) {
    const names = { complete: 'كمّل الآية', order: 'رتّب الآية', memory: 'ذاكرة الرموز', tf: 'صح ولا غلط', maze: 'متاهة الفلك', ws: 'دوّر على الكلمات', sd: 'لاقي الاختلافات' };
    zxShow(names[k], '', '', '<div id="mgRoot"></div>', 'games2');
    const r = document.getElementById('mgRoot'); r._done = 0; ({ complete: zgComplete, order: zgOrder, memory: zgMemory, tf: zgTF, maze: mzNew, ws: zwsNew, sd: zsdNew }[k])(r);
  }

  function openHomilies() {
    const S = window.SERMONS || { video: [], audio: [], who: '' };
    const row = (t, u, lbl) => '<div class="tip-blk"><div class="synax-tx"><p>' + t + '</p></div><a class="zx-btn" href="' + u + '" rel="noopener noreferrer">' + lbl + '</a></div>';
    const net = '<p class="advice-src">تفتح من الإنترنت (تحتاج نت).</p>';
    zxShow('عظات', 'شاهد أو اسمع أو اقرأ', 'عظات',
      '<h2 class="rd-sec-title">عظات فيديو — ' + S.who + '</h2>' + net + S.video.map(v => row(v[0], v[1], 'شاهد العظة')).join('') +
      '<h2 class="rd-sec-title">عظات صوتية — ' + S.who + '</h2>' + net + S.audio.map(v => row(v[0], v[1], 'اسمع العظة')).join('') +
      '<h2 class="rd-sec-title">عظات للقراءة</h2>' + net +
      ZX.homilies.map(h => '<div class="tip-blk"><div class="synax-tx"><p>' + h.title + '</p></div><p class="advice-src">' + h.who + '</p><a class="zx-btn" href="' + h.url + '" rel="noopener noreferrer">اقرأ</a></div>').join(''), 'fathers');
  }
  function openTasbeha() {
    if (window.zHymnPlayer) { window.zHymnPlayer.open(); return; }
    zxShow('التسبحة والترانيم', 'صوتيات', 'قيد التجهيز',
      '<div class="bk-list">' +
      ['ترانيم مشهورة', 'مدائح', 'مدايح القديسين (صوت ونص)', 'التسبحة', 'عظات صوتية'].map(n => '<div class="bk-row"><span class="bk-name">' + n + '</span><span class="bk-meta">قريبًا</span></div>').join('') + '</div>' +
      '', 'home');
    const lo = document.getElementById('litOpen'); if (lo) lo.onclick = openLiturgyAudio;
  }


  // ---- Optional free download: CoptNet Gregorian liturgy (unmodified files, full notice shown) ----
  const LIT_BASE = 'http://www.coptic.net/collections/AudioCopticLiturgies/';
  const LIT_PAGE = 'http://www.coptic.net/collections/AudioCopticLiturgies/';
  const LIT_FILES = [["المقدمة", "Introduction", 803304], ["صلاة الصلح", "Prayer of Reconciliation", 11058459], ["الأنافورا", "The Anophora", 13064557], ["قدوس قدوس قدوس", "Holy, Holy, O Lord", 16027478], ["التقديس", "The Consecration", 10786265], ["استدعاء الروح القدس", "Invocation of the Holy Spirit", 2368570], ["الأواشي والطلبات الغريغورية", "Intercession and Gregorian Litanies", 11128578], ["جيناي نان (١)", "Jenai Nan", 7408320], ["جيناي نان (٢)", "Jenai Nan", 14410392], ["التذكار", "Commemoration", 19206473], ["مقدمة التقسيم", "Introduction to Fraction", 8158976], ["تقسيم أبراهام", "Fraction of Abraham", 31322312]];
  const LIT_LIC = "License: This Liturgy is provided to you under certain restrictions. Downloading this Liturgy constitutes legal acceptance of the terms and conditions set forth here, as well as any further conditions to be imposed in the future by the copyright holders of this recording or CoptNet. These restrictions include, but are not limited to, the following:\n- you may not sell this liturgy in any form or on any recorded media, including, but not limited to, cassette, compact disk, digital audio tape, optical disk, hard disk, or any other distributable media. You may not accept payment of any kind in exchange for this Liturgy under any circumstances.\n- You may redistribute this liturgy at no cost provided this notice is included with it and provided that you make absolutely clear to the recipients that this liturgy is Copyrighted exclusively by Fr. Mina Rizkalla of The Coptic Orthodox Church of St. Anthony and Archangel Michael in Melbourne, Australia.\n- Under no circumstances does transferal of this electronic recording in any way, shape, or form invalidate or restrict this usage license or the respective copyrights associated with this recorded Liturgy.\n- No warranty of any kind whatsoever, express or implied, as to the quality, content, or originality of this recording is made. Downloading of the recording constitutes acceptance of this statement. Neither the Copyright holders nor CoptNet nor anyone acting in the capacity of an officer of CoptNet shall be held liable in any way for this recording.";
  function litFS() { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Filesystem; }
  function litName(i) { return 'coptic-liturgy-arabic-' + String(i + 1).padStart(2, '0') + '.mp3'; }
  function litMB(b) { return toArabicDigits((b / 1000000).toFixed(1).replace('.0', '')).replace('.', '٫') + ' ميجا'; }
  async function litHave(i) { const fs = litFS(); if (!fs) return false; try { const s = await fs.stat({ path: 'zill_liturgy/' + litName(i), directory: 'DATA' }); return !s || s.size === undefined || Number(s.size) === LIT_FILES[i][2]; } catch (e) { return false; } }
  async function litRm(path) { const fs = litFS(); try { await fs.deleteFile({ path, directory: 'DATA' }); } catch (e) {} }
  async function openLiturgyAudio() {
    const fs = litFS(); const have = [];
    for (let i = 0; i < LIT_FILES.length; i++) have.push(await litHave(i));
    const total = LIT_FILES.reduce((s, f) => s + f[2], 0);
    zxShow('القداس الغريغوري (تسجيل صوتي)', 'تحميل اختياري مجاني', 'القداس الغريغوري', 
      '<p class="advice-src">ده <b>تسجيل كامل للقداس الغريغوري بالعربي والقبطي</b> (قداس كامل، مش ترانيم منفصلة). التسجيل لأبونا مينا رزق الله، كنيسة الأنبا أنطونيوس ورئيس الملائكة ميخائيل، ملبورن، أستراليا. حقوقه محفوظة له حصريًا.</p>' +
      '<p class="advice-src">التسجيل مش جوه التطبيق عشان حجمه كبير (حوالي ' + litMB(total) + ' كلهم). بتحمّله لو عايز، ببلاش، من موقع CoptNet، والملفات بتتحفظ زي ما هي من غير أي تعديل. التحميل بيحتاج نت وبياخد مساحة على موبايلك، وتقدر تمسح أي ملف بعد ما تحمّله لتوفير المساحة.</p><p class="advice-src">تنبيه: موقع المصدر بيشتغل من غير تشفير. التطبيق بيتأكد بس إن حجم الملف المحمّل مطابق للحجم المنشور، وده مش ضمان إن الملف أصلي.</p>' +
      '<div class="bk-list">' + LIT_FILES.map((f, i) => '<div class="bk-row" role="button" data-lit="' + i + '"><span class="bk-name">' + toArabicDigits(i + 1) + '. ' + f[0] + ' <bdi dir="ltr">(' + f[1] + ')</bdi></span><span class="bk-meta">' + (have[i] ? 'شغّل' : 'حمّل (' + litMB(f[2]) + ')') + '</span>' + (have[i] ? '<span class="game-btn" style="min-width:0;padding:4px 12px;font-size:12px;margin-inline-start:8px" data-litdel="' + i + '">امسح</span>' : '') + '</div>').join('') + '</div>' +
      '<div id="litStat" class="advice-src" role="status"></div><div id="litPlayer"></div>' +
      (fs ? '' : '<p class="rd-concl">التحميل شغال بس جوه تطبيق الأندرويد.</p>') +
      '<h2 class="rd-sec-title">المصدر والترخيص</h2><p class="advice-src">المصدر: ' + zxLink(LIT_PAGE, LIT_PAGE.replace('http://', '')) + ' . حقوق النشر: <bdi dir="ltr">Fr. Mina Rizkalla, The Coptic Orthodox Church of St. Anthony and Archangel Michael, Melbourne, Australia</bdi>. نص الترخيص الأصلي بالإنجليزي زي ما هو:</p>' +
      '<p class="bible-src" dir="ltr" style="text-align:left;white-space:pre-wrap">' + LIT_LIC + '</p>', 'tasbeha');
    document.querySelectorAll('[data-lit]').forEach(el => el.onclick = ev => { if (ev.target.closest('[data-litdel]')) return; litAct(+el.getAttribute('data-lit')); });
    document.querySelectorAll('[data-litdel]').forEach(el => el.onclick = async ev => { ev.stopPropagation(); const k = +el.getAttribute('data-litdel'); await litRm('zill_liturgy/' + litName(k)); await litRm('zill_liturgy/' + litName(k) + '.part'); openLiturgyAudio(); });
    if (fs) for (let i = 0; i < LIT_FILES.length; i++) litRm('zill_liturgy/' + litName(i) + '.part');
  }
  let LIT_BUSY = false;
  async function litAct(i) {
    const fs = litFS(); let st = document.getElementById('litStat'); if (!fs) { st.textContent = 'التحميل شغال بس جوه تطبيق الأندرويد.'; return; }
    const path = 'zill_liturgy/' + litName(i);
    if (!(await litHave(i))) {
      if (LIT_BUSY) { st.textContent = 'في تحميل شغال دلوقتي. استنى لما يخلص.'; return; }
      LIT_BUSY = true;
      st.textContent = 'بيتحمّل: ' + LIT_FILES[i][0] + '... (' + litMB(LIT_FILES[i][2]) + ')';
      const part = path + '.part';
      try {
        await litRm(path); await litRm(part);
        await fs.downloadFile({ url: LIT_BASE + litName(i), path: part, directory: 'DATA', recursive: true });
        const s = await fs.stat({ path: part, directory: 'DATA' });
        if (s && s.size !== undefined && Number(s.size) !== LIT_FILES[i][2]) { await litRm(part); st.textContent = 'الملف اتحمّل ناقص أو مختلف في الحجم، فاتمسح. جرّب تاني.'; LIT_BUSY = false; return; }
        await fs.rename({ from: part, to: path, directory: 'DATA', toDirectory: 'DATA' });
      } catch (e) {
        await litRm(part); await litRm(path);
        const m = String((e && e.message) || e).toLowerCase();
        st.textContent = /space|enospc|storage|quota/.test(m) ? 'المساحة على الموبايل مش كفاية. امسح حاجة وجرّب تاني.' : 'التحميل ما اكتملش. اتأكد من النت وجرّب تاني.';
        LIT_BUSY = false; return;
      }
      LIT_BUSY = false;
      await openLiturgyAudio(); st = document.getElementById('litStat');
    }
    try {
      const u = await fs.getUri({ path, directory: 'DATA' });
      const src = window.Capacitor.convertFileSrc(u.uri);
      document.getElementById('litPlayer').innerHTML = '<audio controls autoplay preload="none" style="width:100%;margin-top:10px" src="' + src + '"></audio>';
      st = document.getElementById('litStat'); if (st) st.textContent = 'شغّال: ' + LIT_FILES[i][0];
    } catch (e) { st.textContent = 'مقدرتش أفتح الملف المحمّل.'; }
  }

  window.zShowScreen = showScreen;
  let ZQ_CUR = null;
  function openQuizMenu() {
    const cats = [['all', 'كل الأسئلة'], ['doc', 'العقيدة'], ['rite', 'الطقس والقداس'], ['sac', 'الأسرار السبعة'], ['saint', 'سير القديسين'], ['bible', 'قصص الكتاب المقدس']];
    zxShow('اختبر نفسك', 'اختار قسم', 'الأقسام',
      '<div class="bk-list">' + cats.map(c => '<div class="bk-row" role="button" data-qc="' + c[0] + '"><span class="bk-name">' + c[1] + '</span></div>').join('') + '</div>' +
      '', 'doctrine');
    document.querySelectorAll('[data-qc]').forEach(el => el.onclick = () => { const k = el.getAttribute('data-qc'); ZQ_CUR = k === 'all' ? ZX.quiz : ZX.quiz.filter(q => q.cat === k); openQuiz(0, 0); });
  }

  async function openQuiz(i, ok) {
    await bibleLoad();
    const Q = ZQ_CUR || ZX.quiz;
    if (i >= Q.length) { zxShow('اختبر نفسك', 'العقيدة', 'خلصت', '<div class="synax-tx"><p>جاوبت ' + toArabicDigits(ok) + ' من ' + toArabicDigits(Q.length) + ' صح.</p></div><div class="game-actions"><span class="game-btn" id="qAgain" role="button">ابدأ من الأول</span></div>', 'doctrine'); document.getElementById('qAgain').onclick = () => openQuiz(0, 0); return; }
    const q = Q[i];
    zxShow('اختبر نفسك', 'سؤال ' + toArabicDigits(i + 1), 'سؤال ' + toArabicDigits(i + 1),
      '<div class="synax-tx"><p>' + q.q + '</p></div><div class="zg-opts" id="qo" style="flex-direction:column;align-items:stretch"></div><div id="qf"></div>', 'doctrine');
    let done = false; const o = document.getElementById('qo');
    q.o.map((t, k) => [t, k]).sort(() => Math.random() - 0.5).forEach(([t, k]) => { const b = document.createElement('div'); b.dataset.k = k; b.className = 'game-btn'; b.setAttribute('role', 'button'); b.textContent = t;
      b.onclick = () => { if (done) return; done = true; const right = k === q.a; const n = ok + (right ? 1 : 0);
        o.querySelectorAll('.game-btn').forEach(x => x.classList.add(+x.dataset.k === q.a ? 'right' : (x === b ? 'wrong' : 'dim')));
        document.getElementById('qf').innerHTML = '<p class="advice-src">' + (right ? 'صح ✓' : 'مش دي. الإجابة الصح مظلّلة.') + '</p><div class="synax-tx"><p>' + packText(q.why) + '</p></div>' +
          (q.ref ? zxVerses(q.ref) : '') + '<div class="game-actions"><span class="game-btn" id="qNext" role="button">' + (i + 1 < Q.length ? 'السؤال اللي بعده' : 'النتيجة') + '</span></div>';
        document.getElementById('qNext').onclick = () => openQuiz(i + 1, n); };
      o.appendChild(b); });
  }


  /* Person cards: photo (public-domain image, file-by-file) + name. People without a vetted image get a plain name card, never a stand-in picture. */
  const PC_IMG = {"bio": {"moses": "moses", "david": "david", "daniel": "daniel", "jonah": "jonah", "mary": "mary", "samuel": "samuel", "elijah": "elijah", "peter": "peter", "paul": "paul"}, "saint": {"george": "george", "anthony": "anthony", "mina": "mina", "paul": "paul_hermit", "macarius": "macarius", "barbara": "barbara", "marina": "marina", "moses": "moses_black"}, "pat": {"athanasius": "athanasius", "cyril": "cyril", "mark": "mark"}, "father": {"athanasius": "athanasius", "anthony": "anthony"}};
  function pcGrid(kind, items, attr) {
    return '<div class="pc-grid">' + items.map(b => { const im = (PC_IMG[kind] || {})[b.id];
      return '<div class="pc" role="button" ' + attr + '="' + b.id + '">' + (im ? '<img class="pc-img" loading="lazy" alt="" onerror="this.outerHTML=\'<div class=&quot;pc-img pc-none&quot;></div>\'" src="img/people/' + im + '.jpg">' : '<div class="pc-img pc-none"></div>') + '<span class="pc-name">' + b.name + '</span></div>'; }).join('') + '</div>';
  }
  const FATHER_IDS = () => { const seen = [], out = []; ZX.fathers.forEach(f => { if (!seen.includes(f.who)) { seen.push(f.who); out.push({ id: String(out.length), name: f.who, who: f.who }); } }); return out; };
  function fatherKey(w) { return w.includes('أثناسيوس') ? 'athanasius' : w.includes('أنطونيوس') ? 'anthony' : 'x' + w; }
  function openBios() {
    zxShow('السِّيَر', 'حياة وقصص', 'السِّيَر',
      '<div class="bk-list">' +
      '<div class="bk-row" role="button" data-bio-grp="bible"><span class="bk-name">شخصيات الكتاب المقدس</span></div>' +
      '<div class="bk-row" role="button" data-bio-grp="saints"><span class="bk-name">القديسون</span></div>' +
      '<div class="bk-row" role="button" data-bio-grp="pat"><span class="bk-name">البطاركة</span></div></div>' +
      '', 'home');
    document.querySelector('[data-bio-grp=bible]').onclick = openBioList;
    document.querySelector('[data-bio-grp=pat]').onclick = openPatList;
    document.querySelector('[data-bio-grp=saints]').onclick = openSaintList;
  }
  function openBioList() {
    zxShow('شخصيات الكتاب المقدس', 'مجموعة أولى', 'اختار شخصية',
      pcGrid('bio', ZX.bios, 'data-bio'), 'bios');
    document.querySelectorAll('.pc[data-bio]').forEach(el => el.onclick = () => openBio(el.getAttribute('data-bio')));
  }
  function openPatList() {
    zxShow('البطاركة', 'مجموعة أولى', 'اختار',
      pcGrid('pat', ZX.pats, 'data-pat'), 'bios');
    document.querySelectorAll('.pc[data-pat]').forEach(el => el.onclick = () => openPat(el.getAttribute('data-pat')));
  }
  async function openPat(id) {
    await bibleLoad();
    const b = ZX.pats.find(x => x.id === id); if (!b) return; SIB = { back: 'patlist', list: ZX.pats, id, open: openPat };
    const le = longFind(await longLoad('bio'), 'bio', longKey(id));
    zxShow(b.name, 'البطاركة', b.name,
      (le ? longHTML(le) : '<div class="synax-tx"><p>' + b.sum + '</p></div>') +
      (b.refs.length ? '<h2 class="rd-sec-title">من الكتاب المقدس</h2>' + b.refs.map(zxVerses).join('') : '') + (b.note ? '<p class="rd-concl">' + b.note + '</p>' : ''), 'patlist');
  }

  function openSaintList() {
    zxShow('القديسون', 'مجموعة أولى', 'اختار',
      pcGrid('saint', ZX.saints, 'data-saint'), 'bios');
    document.querySelectorAll('.pc[data-saint]').forEach(el => el.onclick = () => openSaint(el.getAttribute('data-saint')));
  }
  async function openSaint(id) {
    await bibleLoad();
    const b = ZX.saints.find(x => x.id === id); if (!b) return; SIB = { back: 'saintlist', list: ZX.saints, id, open: openSaint };
    const le = longFind(await longLoad('bio'), 'bio', longKey(id, 'moses_black'));
    zxShow(b.name, 'القديسون', b.name,
      (le ? longHTML(le) : '<div class="synax-tx"><p>' + b.sum + '</p></div>') +
      (b.refs.length ? '<h2 class="rd-sec-title">من الكتاب المقدس</h2>' + b.refs.map(zxVerses).join('') : '') + (b.note ? '<p class="rd-concl">' + b.note + '</p>' : ''), 'saintlist');
  }

  // ---- Long readings (bios / crises): optional sourced packs, rendered only when an entry exists ----
  let SIB = null;
  const LONG = {};
  function longLoad(kind) { const f = kind === 'bio' ? 'long-bios' : 'long-crises'; return LONG[f] ? Promise.resolve(LONG[f]) : packLoadJson(f, 'content/packs/' + f + '.json').catch(() => ({ entries: [] })).then(j => (LONG[f] = j.entries || [])); }
  function longRef(ref) {
    const t = String(ref || '').replace(/[\u0660-\u0669]/g, d => d.charCodeAt(0) - 0x660).replace(/\u200E/g, '').trim();
    const m = t.match(/^(.+?)\s*(\d+):(\d+)(?:\s*[-\u2013]\s*(\d+))?$/); if (!m || !BIBLE.pack) return null;
    const nm = m[1].trim(), bk = BIBLE.pack.books.find(b => b.name === nm); if (!bk) return null;
    return [bk.id, +m[2], +m[3], m[4] ? +m[4] : undefined];
  }
  // An entry is used only when it is explicitly marked ui_ready; sections that are held or only partly read are never shown.
  const LONG_ALIAS = {}
  // saint/patriarch ids that equal a Bible-person id (paul, peter, moses) must not pick the apostle/prophet entry
  function longKey(id, alias) { if (id === 'moses' && alias) return alias; return ZX.bios.some(x => x.id === id) ? '__none__' : id; }
  function longFind(list, kind, id) { return list.find(x => x.ui_ready === true && (x.id === id || x.id === kind + '_' + id)); }
  function longHTML(e) {
    return (e.sections || []).filter(s => s.status !== 'held' && s.status !== 'read_partial').map(s => {
      let h = '<h2 class="rd-sec-title">' + agEsc(s.heading_ar || '') + '</h2>';
      if (s.type === 'scripture') { const r = longRef(s.ref); h += r ? zxVerses(r) : ''; }
      else {
        if (s.type === 'app_written') h += '<p class="advice-src">من كتابة التطبيق.</p>';
        if (s.type === 'attributed_quote') h += '<p class="advice-src">اقتباس منسوب</p>';
        h += '<div class="synax-tx long-tx">' + (s.paragraphs_ar || []).map(p => '<p>' + toArabicDigits(agEsc(p)) + '</p>').join('') + '</div>';
      }
      return h;
    }).join('');
  }
  async function openBio(id) {
    await bibleLoad();
    const b = ZX.bios.find(x => x.id === id); if (!b) return; SIB = { back: 'biolist', list: ZX.bios, id, open: openBio };
    const le = longFind(await longLoad('bio'), 'bio', id);
    zxShow(b.name, 'شخصيات الكتاب المقدس', b.name,
      (le ? longHTML(le) : '<div class="synax-tx"><p>' + b.sum + '</p></div>') +
      '<h2 class="rd-sec-title">من الكتاب المقدس</h2>' + b.refs.map(zxVerses).join('') + '', 'biolist');
  }

  function sgGet() { try { return JSON.parse(localStorage.getItem('zill.suggest') || '[]'); } catch (e) { return []; } }
  function openSuggest() {
    const list = sgGet();
    zxShow('اقتراحاتك', 'اكتب اللي محتاجه', 'اقتراح جديد',
      '<p class="advice-src">الاقتراح بيتحفظ على تليفونك، والإرسال بيتم على واتساب لرقم صاحب التطبيق وإنت اللي بتدوس إرسال: ٢٠١٢٠٠٣٧٦٤٠٤+.</p>' +
      '<textarea id="sgText" rows="5" placeholder="اكتب اقتراحك هنا" style="width:100%;box-sizing:border-box;padding:12px;border-radius:12px;font:inherit"></textarea>' +
      '<div class="bk-list"><div class="bk-row" role="button" id="sgSave"><span class="bk-name">حفظ الاقتراح</span></div></div>' +
      '<h2 class="rd-sec-title">اقتراحاتك المحفوظة (' + toArabicDigits(list.length) + ')</h2>' +
      list.map((s, i) => '<div class="synax-tx"><p>' + s.t.replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c])) + '</p><div class="bk-row"><a class="zx-link" data-sgsend="' + i + '" href="https://wa.me/201200376404?text=' + encodeURIComponent('اقتراح لتطبيق ظِلّ:\n' + s.t) + '" rel="noopener noreferrer"><span class="bk-name">ابعت على واتساب</span></a></div><div class="bk-row" role="button" data-sgdel="' + i + '"><span class="bk-name">حذف</span></div></div>').join(''), 'home');
    document.getElementById('sgSave').onclick = () => { const v = document.getElementById('sgText').value.trim(); if (!v) return; const l = sgGet(); l.push({ t: v, d: Date.now() }); localStorage.setItem('zill.suggest', JSON.stringify(l)); openSuggest(); };
    document.querySelectorAll('[data-sgdel]').forEach(el => el.onclick = () => { const l = sgGet(); l.splice(+el.getAttribute('data-sgdel'), 1); localStorage.setItem('zill.suggest', JSON.stringify(l)); openSuggest(); });
  }

  let CRISIS_G = null;
  function crisisGuide() { return CRISIS_G ? Promise.resolve(CRISIS_G) : packLoadJson('crisis-guide', 'content/packs/crisis-guide.json').then(j => (CRISIS_G = j.crises)); }
  function openCrisisHub() {
    const pack = CONTENT.pack, adv = pack && pack.advice; if (!adv) return;
    document.getElementById('readTitle').firstChild.textContent = 'الأزمات';
    document.getElementById('readSub').textContent = '';
    document.getElementById('readHead').textContent = '';
    const draw = list => {
      document.getElementById('readBody').innerHTML = '<div class="bk-list">' + list.map(c =>
        '<div class="bk-row" role="button" data-crisis="' + packText(c.id) + '"><span class="bk-name">' + packText(c.name) + '</span></div>').join('') + '</div>' +
        '<p class="rd-concl">' + packText(adv.disclaimer || '') + '</p>';
      document.querySelectorAll('[data-crisis]').forEach(el => el.onclick = () => openCrisis(el.getAttribute('data-crisis')));
    };
    draw(adv.crises);
    setReadCtx(null); READ_BACK = 'home'; showScreen('read');
    crisisGuide().then(g => { if (READ_BACK === 'home' && document.querySelector('[data-crisis]')) draw(g); }).catch(() => {});
  }
  function openCrisis(id) {
    const adv = CONTENT.pack.advice;
    Promise.all([crisisGuide(), longLoad('crisis'), bibleLoad()]).then(([g, longs]) => {
      const c = g.find(x => x.id === id); if (!c) return;
      const le = longFind(longs, 'crisis', id);
      const old = adv.crises.find(x => x.id === id);
      document.getElementById('readTitle').firstChild.textContent = c.name;
      document.getElementById('readSub').textContent = '';
      document.getElementById('readHead').textContent = c.name;
      const refFix = r => r.replace(/^(.+?)\s*(\d+):(\d+)$/, (m, n, c2, x) => agEsc(n) + ' <bdi dir="ltr">' + toArabicDigits(c2) + ':' + toArabicDigits(x) + '</bdi>');
      const vb = v => '<div class="tip-blk"><div class="synax-tx"><p>' + agEsc(v.t) + '</p></div><p class="advice-src">' + refFix(v.r) + '</p></div>';
      const P = t => '<div class="tip-blk"><div class="synax-tx"><p>' + packText(t) + '</p></div></div>';
      const rb = document.getElementById('readBody');
      rb.innerHTML = '<p class="rd-concl">لو في خطر مباشر على حياتك أو حياة حد، اتصل بالإسعاف (١٢٣ في مصر) أو روح لأقرب طوارئ، وكلم حد قريب منك فورًا. التطبيق مش بديل عن ده.</p>' +
        (adv.disclaimer ? '<p class="rd-concl">' + packText(adv.disclaimer) + '</p>' : '') +
        (le ? longHTML(le) : '') +
        '<h2 class="rd-sec-title">اللي بتمر بيه</h2>' + P(c.problem) +
        '<h2 class="rd-sec-title">طمأنة</h2>' + P(c.comfort) + c.verses.slice(0, 3).map(vb).join('') +
        '<h2 class="rd-sec-title">خطوات تساعدك</h2>' + c.steps.map(t => P(t)).join('') +
        '<h2 class="rd-sec-title">صلاة</h2><p class="advice-src">صلاة بكلمات التطبيق، مش نص كنسي.</p>' + '<div class="tip-blk"><div class="synax-tx">' + c.prayer.map(l => '<p>' + packText(l) + '</p>').join('') + '</div></div>' +
        (c.verses.length > 3 ? '<h2 class="rd-sec-title">آيات كمان</h2><div class="cv-list">' + c.verses.slice(3).map(vb).join('') + '</div>' : '') +
        (old && old.tips && old.tips.length ? '<h2 class="rd-sec-title">نصايح تانية</h2>' + old.tips.map(raw => P(normTip(raw).t)).join('') : '');
      sectionize(rb); setReadCtx(null); READ_BACK = 'crisis'; showScreen('read');
    }).catch(() => {});
  }

  function openAdviceFull(pack) {
    const a = adviceForToday(pack, new Date());
    if (!a) return;
    const head = document.getElementById('readTitle');
    head.firstChild.textContent = 'نصيحة اليوم';
    document.getElementById('readSub').textContent = a.crisis;
    document.getElementById('readHead').textContent = a.crisis;
    document.getElementById('readBody').innerHTML =
      '<div class="synax-tx"><p>' + packText(a.tip) + '</p></div>' +
      (a.verse ? '<p class="verse">«' + packText(a.verse) + '» ' + packText(toArabicDigits(a.vref)) + '</p>' : '') +
      (a.disclaimer ? '<p class="rd-concl">' + packText(a.disclaimer) + '</p>' : '');
    setReadCtx(null);
    showScreen('read');
  }

  /* Bible browser: books list -> chapter chips -> chapter text (read screen). */
  let bibleView = 'books';

  async function openBible() {
    showScreen('bible');
    const body = document.getElementById('bibleBody');
    const sub = document.getElementById('bibleSub');
    document.getElementById('bibleTitle').firstChild.textContent = 'الكتاب المقدس';
    if (!BIBLE.pack) {
      body.innerHTML = '<p class="rd-intro">بيتم تجهيز الكتاب…</p>';
      sub.textContent = 'لحظة واحدة';
    }
    const pack = await bibleLoad();
    if (!pack) { body.innerHTML = '<p class="rd-intro">تعذر تحميل نص الكتاب في النسخة دي.</p>'; return; }
    bibleView = 'testaments';
    BIBLE.book = null;
    sub.textContent = 'اختر العهد';
    let resume = null; try { resume = JSON.parse(localStorage.getItem('zill.resume') || 'null'); } catch (e) {}
    const rbk = resume && pack.books.find(b => b.id === resume.book);
    body.innerHTML = (rbk ? '<div class="bk-list"><div class="bk-row" id="bibleResume" role="button"><span class="bk-name">كمّل من حيث وقفت: ' + rbk.name + ' ' + toArabicDigits(resume.ch) + '</span></div></div>' : '') +
      '<input id="bibleSearch" class="bk-search" type="search" placeholder="ابحث في الكتاب كله…">' +
      '<div id="bibleList">' + bibleGroupsHTML(pack) + '</div>';
    const rr = document.getElementById('bibleResume');
    if (rr && rbk) rr.onclick = () => { BIBLE.book = rbk; openBibleChapter(resume.ch, resume.y || 0); };
  }

  function openBibleGroup(gi) {
    if (!BIBLE.pack || !BIBLE_GROUPS[gi]) return;
    bibleView = 'books'; BIBLE.book = null; BIBLE.grp = gi;
    document.getElementById('bibleSub').textContent = 'اختر السفر';
    document.getElementById('bibleTitle').firstChild.textContent = BIBLE_GROUPS[gi].name;
    document.getElementById('bibleBody').innerHTML = '<div id="bibleList">' + bibleBooksHTML(BIBLE.pack, gi) + '</div>';
  }

  function openBibleBook(bookId) {
    const book = BIBLE.pack.books.find(b => b.id === bookId);
    if (!book) return;
    BIBLE.grp = bibleGroupOf(book.id);
    bibleView = 'chapters';
    BIBLE.book = book;
    document.getElementById('bibleSub').textContent = 'اختر الأصحاح';
    document.getElementById('bibleTitle').firstChild.textContent = book.name;
    document.getElementById('bibleBody').innerHTML = bibleChaptersHTML(book);
  }


  // ---- Verse selection + copy / share text / share image / save image (user-initiated only) ----
  let VSEL = new Set(), SHARE_SRC = null;
  const SH_MSG = { copied: 'اتنسخت الآية مع المرجع', shared: 'تمام', cancelled: '', 'copied-fallback': 'المشاركة مش متاحة هنا، فاتنسخت الآية', failed: 'ما نفعش. جرّب تاني', toolong: 'الآيات طويلة على الكارت. شاركها كنص', downloaded: 'الصورة اتنزلت', saved: 'الصورة اتحفظت في مجلد Zill جوه المستندات', savefail: 'مقدرتش أحفظ الصورة. جرّب «صورة» واحفظها من قايمة المشاركة' };
  function ensureShareBar() {
    let bar = document.getElementById('shareBar'); if (bar) return bar;
    bar = document.createElement('div'); bar.id = 'shareBar'; bar.hidden = true;
    bar.innerHTML = '<div class="sb-msg" id="shareMsg" role="status"></div><div class="sb-row"><button data-sa="expl">شرح</button><button data-sa="copy">نسخ</button><button data-sa="text">شارك نص</button><button data-sa="img">شارك صورة</button><button data-sa="x" aria-label="إلغاء التحديد">✕</button></div>';
    document.getElementById('scr-read').appendChild(bar);
    bar.addEventListener('click', async ev => {
      const bt = ev.target.closest('[data-sa]'); if (!bt || !SHARE_SRC) return; const k = bt.dataset.sa;
      if (k === 'x') { clearVerseSel(); return; }
      if (k === 'expl') { openExplain(); return; }
      const s = SHARE_SRC(); if (!s) return; const msg = document.getElementById('shareMsg');
      const r = k === 'copy' ? await zCopy(s.text, s.ref) : k === 'text' ? await zShareText(s.text, s.ref) : k === 'img' ? await zShareImage(s.text, s.ref) : await zSaveImage(s.text, s.ref);
      msg.textContent = SH_MSG[r] !== undefined ? SH_MSG[r] : '';
    });
    return bar;
  }
  function showShareBar(src) { const b = ensureShareBar(); SHARE_SRC = src; const eb = b.querySelector('[data-sa="expl"]'); if (eb) eb.hidden = (src !== selVerseSrc); document.getElementById('shareMsg').textContent = ''; b.hidden = false; }
  function openExplain() {
    if (!VSEL.size || !BIBLE.book) return;
    const nums = [...VSEL].sort((a, b) => a - b);
    let pn = document.getElementById('explPanel');
    if (!pn) { pn = document.createElement('div'); pn.id = 'explPanel'; pn.setAttribute('role', 'dialog'); pn.setAttribute('aria-label', 'شرح الآية'); document.getElementById('scr-read').appendChild(pn); }
    pn.innerHTML = ''; const x = document.createElement('button'); x.className = 'ex-x'; x.textContent = '✕'; x.setAttribute('aria-label', 'إغلاق'); x.onclick = () => { pn.hidden = true; };
    pn.appendChild(x); pn.appendChild(zExplRender(zExplFind(BIBLE.book.id, BIBLE.chapter, nums), selRefText())); pn.hidden = false; pn.scrollTop = 0;
  }
  function hideShareBar() { const ep = document.getElementById('explPanel'); if (ep) ep.hidden = true; const b = document.getElementById('shareBar'); if (b) b.hidden = true; SHARE_SRC = null; }
  function clearVerseSel() { VSEL.clear(); document.querySelectorAll('#readBody .verse.vsel').forEach(e => e.classList.remove('vsel')); hideShareBar(); }
  // Android system Back (called from native MainActivity): close overlay, else previous in-app page, else let the app exit (return false only on Home).
  window.zillBack = function () {
    if (typeof zGuideClose === 'function' && zGuideClose()) return true;
    if (typeof zKidsClose === 'function' && zKidsClose()) return true;
    const ep = document.getElementById('explPanel'); if (ep && !ep.hidden) { ep.hidden = true; return true; }
    const sb = document.getElementById('shareBar'); if ((sb && !sb.hidden) || VSEL.size) { clearVerseSel(); return true; }
    const cur = SCREENS.find(x => { const e = document.getElementById('scr-' + x); return e && !e.hidden; });
    if (!cur || cur === 'home') return false;
    const ids = { read: 'readBack', bible: 'bibleBack', favs: 'favsBack', game: 'gameBack', snake: 'snakeBack', settings: 'setBack' };
    const b = document.getElementById(ids[cur]);
    if (b) { b.click(); return true; }
    showScreen('home'); return true;
  };
  function selRefText() {
    const nums = [...VSEL].sort((a, b) => a - b), parts = []; let s = nums[0], p = nums[0];
    for (let i = 1; i <= nums.length; i++) { if (nums[i] === p + 1) { p = nums[i]; continue; } parts.push(s === p ? toArabicDigits(s) : toArabicDigits(s) + '\u200E-\u200E' + toArabicDigits(p)); s = nums[i]; p = nums[i]; }
    return BIBLE.book.name + ' ' + toArabicDigits(BIBLE.chapter) + ':' + parts.join('،');
  }
  function selVerseSrc() {
    if (!VSEL.size || !BIBLE.book) return null;
    const nums = [...VSEL].sort((a, b) => a - b);
    const text = nums.map(n => { const p = document.querySelector('#readBody .verse[data-v="' + n + '"]'); if (!p) return ''; const c = p.cloneNode(true); const vn = c.querySelector('.vnum'); if (vn) vn.remove(); return c.textContent.trim(); }).filter(Boolean).join(' ');
    return { text, ref: selRefText() };
  }
  document.getElementById('readBody').addEventListener('click', ev => {
    const p = ev.target.closest('.verse[data-v]'); if (!p || !READ_CTX || READ_CTX.kind !== 'bible') return;
    if (window.getSelection && String(window.getSelection()).length > 0) return;
    const n = Number(p.dataset.v); if (VSEL.has(n)) { VSEL.delete(n); p.classList.remove('vsel'); } else { VSEL.add(n); p.classList.add('vsel'); }
    if (VSEL.size) showShareBar(selVerseSrc); else hideShareBar();
  });

  function openBibleChapter(chapter, y) {
    const book = BIBLE.book;
    if (!book || !book.chapters[String(chapter)]) return;
    BIBLE.chapter = chapter; clearVerseSel();
    const head = document.getElementById('readTitle');
    head.firstChild.textContent = book.name;
    document.getElementById('readSub').textContent = 'أصحاح ' + toArabicDigits(chapter);
    document.getElementById('readHead').textContent = book.name + ' ' + toArabicDigits(chapter);
    document.getElementById('readBody').innerHTML = '<div class="chap-share"><button class="share-btn" id="shareChap" type="button">شارك الأصحاح</button><span class="chap-share-msg" id="shareChapMsg" role="status"></span></div>' + bibleChapterText(book, chapter) + (typeof chapFactsHTML === 'function' ? chapFactsHTML(book.id, chapter) : '');
    const scb = document.getElementById('shareChap'); if (scb) scb.onclick = async () => { const m = document.getElementById('shareChapMsg'); m.textContent = 'بجهّز الصورة…'; const r = await zShareChapter(book, chapter); m.textContent = ({ shared: '', cancelled: '', failed: 'ما نفعش. جرّب تاني', unavailable: 'المشاركة بالصور مش متاحة هنا' })[r] || ''; };
    if (typeof zLoadNotes === 'function' && !document.querySelector('#readBody .chfacts')) zLoadNotes(book.id).then(() => {
      const rb = document.getElementById('readBody');
      if (BIBLE.book === book && BIBLE.chapter === chapter && rb && !rb.querySelector('.chfacts')) rb.insertAdjacentHTML('beforeend', chapFactsHTML(book.id, chapter));
    });
    setReadCtx({ id: 'bible:' + book.id + ':' + chapter, kind: 'bible', book: book.id, chapter,
      title: book.name + ' ' + toArabicDigits(chapter) });
    READ_BACK = 'bible';
    showScreen('read');
    try { localStorage.setItem('zill.resume', JSON.stringify({ book: book.id, ch: chapter, y: 0 })); } catch (e) {}
    const rs = document.querySelector('#scr-read .read-scroll'); if (rs) rs.scrollTop = (y || 0);
  }

  async function openToday() {
    const pack = await bibleLoad(); if (!pack) return;
    const v = verseOfDay(pack, new Date()), c = chapterOfDay(pack, new Date());
    document.getElementById('readTitle').firstChild.textContent = 'صلاة اليوم';
    document.getElementById('readSub').textContent = '';
    document.getElementById('readHead').textContent = formatGregorianAr(new Date());
    document.getElementById('readBody').innerHTML =
      '<h2 class="rd-sec-title">آية اليوم</h2>' + (v ? '<p class="verse">' + v.text + '</p><p class="rd-ref-line">' + v.book.name + ' ' + numRef(v.ch + ':' + v.v) + '</p><button class="share-btn" id="shareVerse">نسخ ومشاركة</button>' : '') +
      '<h2 class="rd-sec-title">أصحاح اليوم</h2><div class="bk-list"><div class="bk-row" id="todayCh" role="button"><span class="bk-name">' + c.book.name + ' ' + toArabicDigits(c.ch) + '</span></div></div>' +
      '<h2 class="rd-sec-title">صلوات اليوم</h2><p class="rd-intro">قريبًا.</p>' +
      '<h2 class="rd-sec-title">متابعتك</h2><div class="bk-list"><div class="bk-row" role="button" id="xpGoal"><span class="bk-name">هدف اليوم</span></div><div class="bk-row" role="button" id="xpJourney"><span class="bk-name">رحلتي في ظل</span></div></div>';
    sectionize(document.getElementById('readBody'));
    setReadCtx(null); READ_BACK = 'home'; showScreen('read');
    const sv = document.getElementById('shareVerse'); if (sv && v) sv.onclick = () => showShareBar(() => ({ text: v.text, ref: v.book.name + ' ' + toArabicDigits(v.ch) + ':' + toArabicDigits(v.v) }));
    document.getElementById('xpGoal').onclick = () => window.ZXPUI && ZXPUI.goal();
    document.getElementById('xpJourney').onclick = () => window.ZXPUI && ZXPUI.journey();
    document.getElementById('todayCh').onclick = () => { BIBLE.book = c.book; openBibleChapter(c.ch); READ_BACK = 'home'; };
  }

  function openPrayersPlaceholder() { openAgpeya(); }
  function _oldPrayersPlaceholder() {
    const head = document.getElementById('readTitle');
    head.firstChild.textContent = 'الصلوات';
    document.getElementById('readSub').textContent = '';
    document.getElementById('readHead').textContent = 'لسه بنجهز القسم ده';
    document.getElementById('readBody').innerHTML =
      '<p class="rd-intro">قريبًا.</p>';
    setReadCtx(null);
    showScreen('read');
  }

  /* مين الشخصية؟ */
  async function renderGameRound() {
    await gameBankLoad();
    const round = gameNext();
    const body = document.getElementById('gameBody');
    const clues = round.character.clues;
    body.innerHTML =
      '<div id="gameClues"><p class="game-clue">' + clues[0] + '</p></div>' +
      '<div class="game-actions"><span class="game-btn ghost" id="gameHint">تلميح تاني</span></div>' +
      (round.text ? '<div class="game-opts">' + round.options.map(o => '<span class="game-btn" data-opt="' + o + '" role="button">' + o + '</span>').join('') + '</div>'
      : '<div class="game-opts game-opts-pt">' + round.options.map(o =>
        '<span class="game-btn game-pt" data-opt="' + o + '" role="button"><img alt="" src="img/people/' + GAME_IMG[o] + '.jpg"><span>' + o + '</span></span>').join('') + '</div>') +
      '<div id="gameResult"></div>';
    showScreen('game');
  }

  function gameReveal() {
    const body = document.getElementById('gameBody');
    const res = document.getElementById('gameResult');
    const correct = GAME.answered === 'right';
    const c = gameChar(GAME.current);
    document.getElementById('gameSub').textContent = correct ? 'إجابة صحيحة' : 'الإجابة:';
    // keep only the clues the player already saw (unseen clues stay hidden so the character can come back)
    document.getElementById('gameHint').style.display = 'none';
    document.querySelectorAll('#gameBody [data-opt]').forEach(el => {
      el.classList.add(el.getAttribute('data-opt') === c.name ? 'right' : 'dim');
    });
    res.innerHTML =
      '<h2 class="rd-sec-title">' + packText(c.name) + '</h2>' +
      '<div class="synax-tx"><p>' + packText(c.explain) + '</p></div>' +
      '<p class="advice-src">الشاهد: ' + packText(c.ref.label) + '</p>' +
      '<div class="game-actions">' +
      (c.ref.book ? '<span class="game-btn" id="gameRef" role="button">افتح الشاهد</span>' : '') +
      '<span class="game-btn ghost" id="gameNext" role="button">شخصية تانية</span></div>';
  }

  function initGame() {
    const body = document.getElementById('gameBody');
    const back = document.getElementById('gameBack');
    if (back) back.addEventListener('click', () => showScreen('home'));
    if (!body) return;
    body.addEventListener('click', async ev => {
      const hint = ev.target.closest('#gameHint');
      if (hint && !GAME.answered) {
        const c = gameChar(GAME.current);
        if (GAME.clueIdx < c.clues.length - 1) {
          GAME.clueIdx++;
          const p = document.createElement('p');
          p.className = 'game-clue';
          p.textContent = c.clues[GAME.clueIdx];
          document.getElementById('gameClues').appendChild(p);
          if (GAME.clueIdx === c.clues.length - 1) hint.style.display = 'none';
        }
        return;
      }
      const opt = ev.target.closest('[data-opt]');
      if (opt && !GAME.answered) {
        const c = gameChar(GAME.current);
        const pick = opt.getAttribute('data-opt');
        if (pick === c.name) { GAME.answered = 'right'; zxpQ('who', true); gameReveal(); }
        else { GAME.answered = 'wrong'; zxpQ('who', false); gameReveal(); opt.classList.remove('dim'); opt.classList.add('wrong'); }
        return;
      }
      if (ev.target.closest('#gameNext')) { document.getElementById('gameSub').textContent = ''; renderGameRound(); return; }
      if (ev.target.closest('#gameRef')) {
        const c = gameChar(GAME.current);
        const packB = await bibleLoad();
        BIBLE.book = packB.books.find(b => b.id === c.ref.book);
        if (BIBLE.book) { READ_BACK = 'game'; openBibleChapter(c.ref.ch); READ_BACK = 'game'; }
      }
    });
  }
  function openFavs() {
    const body = document.getElementById('favsBody');
    const list = favsLoad();
    if (!list.length) {
      body.innerHTML = '<p class="rd-intro">لسه مفيش حاجة محفوظة. افتح أي قراءة أو أصحاح واضغط على القلب فوق عشان تحفظه هنا.</p>';
    } else {
      body.innerHTML = '<div class="bk-list">' + list.map(f =>
        '<div class="bk-row" data-fav="' + f.id + '" role="button"><span class="bk-name">' + f.title + '</span>' +
        '<span class="fav-del" data-del="' + f.id + '" role="button">✕</span></div>'
      ).join('') + '</div>';
    }
    showScreen('favs');
  }

  async function openFavEntry(f) {
    if (f.kind === 'bible') {
      const pack = await bibleLoad();
      BIBLE.book = pack.books.find(b => b.id === f.book);
      if (BIBLE.book) { READ_BACK = 'favs'; openBibleChapter(f.chapter); READ_BACK = 'favs'; }
    } else if (f.kind === 'day') {
      const pack = await loadMonthPack(f.cy, f.cm);
      if (pack && pack.days && pack.days[String(f.cd)]) {
        const c = { year: f.cy, month: f.cm, day: f.cd, monthName: COPTIC_MONTHS[f.cm - 1] };
        READ_BACK = 'favs';
        openDayReadings(f.si, f.ui, { coptic: c, day: pack.days[String(f.cd)] });
        READ_BACK = 'favs';
      }
    } else if (f.kind === 'synax') {
      READ_BACK = 'favs';
      await openSynax(f.cm, f.cd, f.cy);
      READ_BACK = 'favs';
    }
  }

  // Where the read screen's back button returns (default: home).
  let READ_BACK = 'home';

  async function init() {
    initTheme();
    initDates();
    renderSections();
    renderNav();
    initGame();
    function setTitle(t, s) { const r = document.querySelector('#scr-settings .rtitle'); if (r) { r.firstChild.textContent = t; r.querySelector('.rsub').textContent = s; } }
    function openSettings() { setTitle('الإعدادات', 'المظهر والقراءة'); const sb = document.getElementById('setBody'); sb.innerHTML = settingsHTML(); sectionize(sb); showScreen('settings'); }
    function openReminders() { setTitle('التذكيرات والتنبيهات', 'كل تذكير لوحده'); document.getElementById('setBody').innerHTML = settingsHTML('rem'); showScreen('settings'); }
    window.openReminders = openReminders;
    window.openSettings = openSettings;
    const bell = document.getElementById('btnBell'); if (bell) bell.addEventListener('click', openSettings);
    const rbtn = document.getElementById('btnRem'); if (rbtn) rbtn.addEventListener('click', openReminders);
    const setBack = document.getElementById('setBack'); if (setBack) setBack.addEventListener('click', () => { renderSections(); showScreen('home'); });
    const setBody = document.getElementById('setBody');
    if (setBody) setBody.addEventListener('click', ev => { const rs = ev.target.closest('#remStatus'); if (!rs || rs.dataset.fix !== '1') return;
      try { const LN = window.Capacitor.Plugins.LocalNotifications; if (LN.changeExactNotificationSetting) LN.changeExactNotificationSetting(); } catch (e) {} });
    if (setBody) setBody.addEventListener('change', async ev => {
      const st = setLoad(); const t = ev.target; st.rem = st.rem || {}; st.hidden = st.hidden || [];
      if (t.dataset.remOn) { const id = t.dataset.remOn; st.rem[id] = Object.assign({}, st.rem[id], { on: t.checked }); }
      if (t.dataset.remTime) { const id = t.dataset.remTime; st.rem[id] = Object.assign({}, st.rem[id], { time: t.value }); }
      if (t.dataset.hide) { st.hidden = st.hidden.filter(x => x !== t.dataset.hide); if (t.checked) st.hidden.push(t.dataset.hide); }
      setSave(st);
      if (t.dataset.remOn || t.dataset.remTime) {
        const r = await remindersApply(st);
        const msg = { 'web-only': 'تم حفظ اختيارك. التنبيه الفعلي بيشتغل في تطبيق الأندرويد بس.', denied: 'إذن الإشعارات مش مفعّل. فعّله من إعدادات الموبايل.', scheduled: 'التذكيرات اتجدولت.', inexact: 'التذكيرات اتجدولت، بس الموبايل مش مسمّح بالمنبّهات الدقيقة فممكن تتأخر. اضغط هنا للسماح.', error: 'حصلت مشكلة في الجدولة.' }[r];
        document.getElementById('remStatus').dataset.fix = r === 'inexact' ? '1' : '';
        document.getElementById('remStatus').textContent = (() => { const rid = t.dataset.remOn || t.dataset.remTime, rr = REMINDERS.find(x => String(x.id) === String(rid)); return (st.rem[rid].on && !remTimeOf(rr, st.rem[rid])) ? 'اختار الوقت الأول.' : msg; })();
      }
    });
    setBody && setBody.addEventListener('click', ev => { const tb = ev.target.closest('[data-tash]'); if (tb) { const st = setLoad(); st.tash = tb.dataset.tash; setSave(st); BIBLE.tash = undefined; BIBLE.pack = null; setBody.querySelectorAll('[data-tash]').forEach(e => e.classList.toggle('sel', e.dataset.tash === st.tash)); } const th = ev.target.closest('[data-theme-set]'); if (th) { applyTheme(th.dataset.themeSet); setBody.querySelectorAll('[data-theme-set]').forEach(e => e.classList.toggle('sel', e.dataset.themeSet === th.dataset.themeSet)); }
      const rsb = ev.target.closest('[data-rs]'), lsb = ev.target.closest('[data-ls]');
      if (rsb || lsb) { const st = setLoad(); if (rsb) st.rs = rsb.dataset.rs; if (lsb) st.ls = lsb.dataset.ls; setSave(st); applyReading();
        setBody.querySelectorAll('[data-rs]').forEach(e => e.classList.toggle('sel', e.dataset.rs === (st.rs || '1')));
        setBody.querySelectorAll('[data-ls]').forEach(e => e.classList.toggle('sel', e.dataset.ls === (st.ls || '1'))); } });
    setBody && setBody.addEventListener('click', ev => { const f1 = ev.target.closest('[data-fx]'), f2 = ev.target.closest('[data-fg]'); if (!f1 && !f2) return; const st = setLoad(); if (f1) st.fx = f1.dataset.fx; if (f2) st.fg = f2.dataset.fg; setSave(st); applyFx();
      setBody.querySelectorAll('[data-fx]').forEach(e => e.classList.toggle('sel', e.dataset.fx === document.documentElement.dataset.motion)); setBody.querySelectorAll('[data-fg]').forEach(e => e.classList.toggle('sel', e.dataset.fg === document.documentElement.dataset.glass)); });
    const sb = document.getElementById('snakeBack'); if (sb) sb.addEventListener('click', () => showScreen('home'));
    const sa = document.getElementById('snakeAgain'); if (sa) sa.addEventListener('click', snakeStart);
    document.querySelectorAll('[data-sd]').forEach(el => el.addEventListener('click', () => { const [x, y] = el.getAttribute('data-sd').split(',').map(Number); snakeTurn(x, y); }));
    const cv = document.getElementById('snakeCv'); let t0 = null;
    if (cv) { cv.addEventListener('touchstart', e => { t0 = e.touches[0]; }, { passive: true });
      cv.addEventListener('touchend', e => { if (!t0) return; const t = e.changedTouches[0], dx = t.clientX - t0.clientX, dy = t.clientY - t0.clientY;
        if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return; if (Math.abs(dx) > Math.abs(dy)) snakeTurn(dx > 0 ? 1 : -1, 0); else snakeTurn(0, dy > 0 ? 1 : -1); t0 = null; }); }
    document.addEventListener('keydown', e => { const m = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key]; if (m) snakeTurn(m[0], m[1]); });
    const pack = await contentLoad();
    try { const _st = setLoad(); remindersApply(_st); } catch (e) {}
    await refreshKat();
    renderReadings();
    setInterval(() => { const k = katKey(); if (k !== KAT_SHOWN) { KAT_SHOWN = k; initDates(); refreshKat().then(renderReadings); } }, 60000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { const k = katKey(); if (k !== KAT_SHOWN) { KAT_SHOWN = k; initDates(); refreshKat().then(renderReadings); } } });
    renderAdvice(pack);
    renderHomeQuote();

    const cta = document.getElementById('ctaReadings');
    if (cta) cta.addEventListener('click', () => { READ_BACK = 'home'; openDayReadings(); });
    const back = document.getElementById('readBack');
    if (back) back.addEventListener('click', () => { const t = READ_BACK; READ_BACK = 'home'; if (t === 'agpeya') openAgpeya(); else if (t === 'fatherlist') openFathers(); else if (t === 'tasbeha') openTasbeha(); else if (t === 'crisis') openCrisisHub(); else if (t === 'fathers') openFathersHub(); else if (t === 'bios') openBios(); else if (t === 'biolist') openBioList(); else if (t === 'patlist') openPatList(); else if (t === 'saintlist') openSaintList(); else if (t === 'games2') openMoreGames(); else if (t === 'doctrine') openDoctrine(); else if (t === 'faqlist') openFaq(); else showScreen(t); });

    const advCard = document.getElementById('adviceCard');
    if (advCard) advCard.addEventListener('click', () => { READ_BACK = 'home'; openAdviceFull(pack); });

    const rsc = document.querySelector('#scr-read .read-scroll'); let rt = null;
    if (rsc) rsc.addEventListener('scroll', () => { if (!READ_CTX || READ_CTX.kind !== 'bible') return; clearTimeout(rt); rt = setTimeout(() => {
      try { localStorage.setItem('zill.resume', JSON.stringify({ book: READ_CTX.book, ch: READ_CTX.chapter, y: Math.round(rsc.scrollTop) })); } catch (e) {} }, 250); });
    const favBtn = document.getElementById('readFav');
    if (favBtn) favBtn.addEventListener('click', () => {
      if (!READ_CTX) return;
      const now = favsToggle(READ_CTX);
      favBtn.classList.toggle('faved', now);
    });
    const favsBack = document.getElementById('favsBack');
    if (favsBack) favsBack.addEventListener('click', () => showScreen('home'));
    const favsBody = document.getElementById('favsBody');
    if (favsBody) favsBody.addEventListener('click', ev => {
      const del = ev.target.closest('[data-del]');
      if (del) { favsToggle({ id: del.getAttribute('data-del') }); openFavs(); return; }
      const row = ev.target.closest('[data-fav]');
      if (!row) return;
      const f = favsLoad().find(x => x.id === row.getAttribute('data-fav'));
      if (f) openFavEntry(f);
    });

    const bibleBack = document.getElementById('bibleBack');
    if (bibleBack) bibleBack.addEventListener('click', () => {
      if (bibleView === 'chapters') openBibleGroup(BIBLE.grp >= 0 ? BIBLE.grp : 0);
      else if (bibleView === 'books' || bibleView === 'search') openBible();
      else showScreen('home');
    });
    const bibleBody = document.getElementById('bibleBody');
    if (bibleBody) bibleBody.addEventListener('click', ev => {
      const bk = ev.target.closest('[data-book]');
      const ch = ev.target.closest('[data-ch]');
      const gp = ev.target.closest('[data-grp]');
      if (gp) { openBibleGroup(+gp.getAttribute('data-grp')); return; }
      if (bk) { openBibleBook(+bk.getAttribute('data-book'));
        if (ch) openBibleChapter(+ch.getAttribute('data-ch'));
        return; }
      if (ch) openBibleChapter(+ch.getAttribute('data-ch'));
    });
    if (bibleBody) bibleBody.addEventListener('input', ev => {
      if (ev.target.id !== 'bibleSearch' || !BIBLE.pack) return;
      const list = document.getElementById('bibleList');
      const q = ev.target.value.trim();
      if (arNorm(q).length < 2) { list.innerHTML = bibleGroupsHTML(BIBLE.pack); bibleView = 'testaments'; return; }
      const res = bibleSearch(BIBLE.pack, q, 60);
      bibleView = 'search';
      list.innerHTML = res.length
        ? '<p class="bk-meta" style="padding:4px 2px">' + toArabicDigits(res.length) + (res.length === 60 ? '+' : '') + ' نتيجة</p><div class="bk-list">' +
          res.map(r => '<div class="bk-row" data-book="' + r.bookId + '" data-ch="' + r.chapter + '" role="button">' +
            '<span class="bk-name">' + r.book + ' ' + toArabicDigits(r.chapter) + ':' + toArabicDigits(r.verse) + '</span></div>' +
            '<p class="sr-hit">' + r.text + '</p>').join('') + '</div>'
        : '<p class="rd-intro">مفيش نتائج لـ«' + q + '».</p>';
    });

    const grid = document.getElementById('secGrid');
    if (grid) grid.addEventListener('click', ev => {
      const card = ev.target.closest('[data-sec]');
      if (!card) return;
      const id = card.getAttribute('data-sec');
      const added = HOME_ADD.find(x => x.id === id);
      if (added) { if (added.target.type === 'story' && window.zKidsOpen) zKidsOpen(added.target.id); return; }
      if (id === 'katameros') { READ_BACK = 'home'; openDayReadings(); }
      else if (id === 'synax') { READ_BACK = 'home'; openSynaxToday(); }
      else if (id === 'bible') openBible();
      else if (id === 'game') { zxpLogin(); renderGameRound(); }
      else if (id === 'today') openToday();
      else if (id === 'crisis') openCrisisHub();
      else if (id === 'fathers') openFathersHub();
      else if (id === 'bios') openBios();
      else if (id === 'suggest') openSuggest();
      else if (id === 'agpeya') openAgpeya();
      else if (id === 'tasbeha') openTasbeha();
      else if (id === 'kids') openKids();
      else if (id === 'games2') { zxpLogin(); openMoreGames(); }
      else if (id === 'doctrine') openDoctrine();
      else if (id === 'snake') { zxpLogin(); showScreen('snake'); snakeStart(); }
    });

    const navEl = document.getElementById('bottomNav');
    if (navEl) navEl.addEventListener('click', ev => {
      const item = ev.target.closest('[data-nav]');
      if (!item) return;
      const id = item.getAttribute('data-nav');
      const go = () => {
        if (id === 'book') openBible();
        else if (id === 'home') showScreen('home');
        else if (id === 'mine') openFavs();
        else if (id === 'prayers') { READ_BACK = 'home'; openPrayersPlaceholder(); }
      };
      go();
    });

    // Swipe between the main pages (home, book, prayers, mine). Finger moving left-to-right goes to the next page, right-to-left goes back.
    (function () {
      let t0 = null;
      const blocked = el => { for (let n = el; n && n !== document.body; n = n.parentElement) {
        const tg = n.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT' || tg === 'CANVAS') return true;
        if (n.isContentEditable) return true;
        if (n.scrollWidth > n.clientWidth + 4) { const ox = getComputedStyle(n).overflowX; if (ox === 'auto' || ox === 'scroll') return true; }
        if (n.hasAttribute && n.hasAttribute('data-noswipe')) return true; }
        return false; };
      const sibCtx = () => { const rd = document.getElementById('scr-read'); if (!rd || rd.hidden) return null;
        const hd = document.getElementById('readHead') && document.getElementById('readHead').textContent;
        if (READ_BACK === 'bible' && BIBLE.book && BIBLE.chapter && hd === BIBLE.book.name + ' ' + toArabicDigits(BIBLE.chapter)) return 'bible';
        if (SIB && READ_BACK === SIB.back) { const b = SIB.list.find(x => x.id === SIB.id); if (b && hd === b.name) return 'person'; }
        return null; };
      const cur = () => { const e = SCREENS.map(x => document.getElementById('scr-' + x)).find(x => x && !x.hidden); return e ? navTabFor(e.id.replace('scr-', '')) : null; };
      document.addEventListener('touchstart', e => { if (e.touches.length !== 1 || !(cur() || sibCtx()) || blocked(e.target)) { t0 = null; return; }
        const t = e.touches[0]; t0 = { x: t.clientX, y: t.clientY, t: Date.now(), ag: !!(e.target.closest && e.target.closest('#agBody')), agi: (typeof AG !== 'undefined' && AG) ? AG.i : 0 }; }, { passive: true });
      document.addEventListener('touchend', e => { if (!t0) return; const st = t0, t = e.changedTouches[0], dx = t.clientX - t0.x, dy = t.clientY - t0.y, dt = Date.now() - t0.t; t0 = null;
        if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.8 || dt > 800) return;
        if (st.ag) { const h = AGPEYA && AGPEYA.hours.find(x => x.id === AG.hour), n = st.agi + (dx > 0 ? 1 : -1); if (h && n >= 0 && n < h.s.length) return; } // the Agpeya reader moves between its own sections first; at its first/last section the swipe continues to the next page
        const sc = cur() ? null : sibCtx(), dir = dx > 0 ? 1 : -1;
        if (sc === 'bible') { const bk = BIBLE.book, bs = BIBLE.pack.books, n = BIBLE.chapter + dir;
          if (bk.chapters[String(n)]) openBibleChapter(n);
          else { const nb = bs[bs.findIndex(x => x.id === bk.id) + dir]; if (nb) { BIBLE.book = nb; const cs = Object.keys(nb.chapters).map(Number); openBibleChapter(dir > 0 ? Math.min.apply(null, cs) : Math.max.apply(null, cs)); } }
          return; }
        if (sc === 'person') { const k = SIB.list.findIndex(x => x.id === SIB.id) + dir; if (SIB.list[k]) SIB.open(SIB.list[k].id); return; }
        const order = NAV.map(n => n.id), i = order.indexOf(cur()); if (i < 0) return;
        const j = i + (dx > 0 ? 1 : -1); if (j < 0 || j >= order.length) return;
        const id = order[j];
        if (id === 'book') openBible(); else if (id === 'home') showScreen('home'); else if (id === 'mine') openFavs(); else if (id === 'prayers') { READ_BACK = 'home'; openPrayersPlaceholder(); } }, { passive: true });
    })();

    // Deep-link for testing: ?screen=readings|synax|bible|advice opens that screen directly.
    const scr = new URLSearchParams(location.search).get('screen');
    if (scr === 'readings') openDayReadings();
    else if (scr === 'synax') openSynaxToday();
    else if (scr === 'bible') {
      await openBible();
      const bk = +(new URLSearchParams(location.search).get('book') || 0);
      const chp = +(new URLSearchParams(location.search).get('ch') || 0);
      if (bk) openBibleBook(bk);
      if (bk && chp) openBibleChapter(chp);
    }
    else if (scr === 'advice') openAdviceFull(pack);
    else if (scr === 'favs') openFavs();
    else if (scr === 'prayers') openPrayersPlaceholder();
    else if (scr === 'game') renderGameRound();
    else if (scr === 'today') openToday();
    else if (scr === 'settings') openSettings();
    else if (scr === 'snake') { showScreen('snake'); snakeStart(); }
    const qp2 = new URLSearchParams(location.search);
    if (qp2.get('q') && scr === 'bible') {
      const si = document.getElementById('bibleSearch');
      if (si) { si.value = qp2.get('q'); si.dispatchEvent(new Event('input', { bubbles: true })); }
    }
    if (qp2.get('scroll') === 'end') {
      const sc = document.querySelector('#scr-home .scroll');
      if (sc) setTimeout(() => { sc.scrollTop = sc.scrollHeight; }, 600);
    }

    // Non-blocking update check: no endpoint configured by default, so this is a no-op.
    if (typeof uiLabelsApply === 'function') uiLabelsApply();
    if (typeof updaterAutoCheck === 'function') updaterAutoCheck();
    // first screen drawn without error: confirm this web bundle to the native updater
    if (typeof shellBootConfirm === 'function') shellBootConfirm();
  }

  document.addEventListener('DOMContentLoaded', init);
})();

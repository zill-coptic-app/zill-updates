/* TEMPORARY update experiment (zs-3). Removable from Settings; not part of the app proper. */
(function () {
  var KEY = 'zill.exp.on';
  function on() { try { return localStorage.getItem(KEY) !== '0'; } catch (e) { return true; } }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h; return d.firstChild; }
  var css = document.createElement('style');
  css.textContent = '.zexp-card{margin:14px 16px 120px;padding:14px 16px;border-radius:18px;background:var(--card-bg);border:1px dashed var(--gold);color:var(--text);font-family:"Noto Sans Arabic",sans-serif;text-align:right}' +
    '.zexp-card b{color:var(--gold)}.zexp-btn{margin-top:10px;padding:10px 18px;border-radius:14px;border:0;background:var(--gold);color:var(--on-gold);font:700 15px "Noto Sans Arabic",sans-serif}' +
    '#zexpGame{position:fixed;inset:0;z-index:99999;background:#17142e;color:#F3EDDF;display:flex;flex-direction:column;align-items:center;padding:18px;direction:rtl;font-family:"Noto Sans Arabic",sans-serif}' +
    '#zexpGame[hidden]{display:none}.zexp-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;width:min(92vw,380px);margin-top:14px}' +
    '.zexp-c{aspect-ratio:1;border-radius:14px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#E3B257;font-size:30px;display:flex;align-items:center;justify-content:center;cursor:pointer;user-select:none}' +
    '.zexp-c.open{background:#E3B257;color:#241A08}.zexp-c.done{background:rgba(227,178,87,.25);color:#E3B257;opacity:.6}';
  document.head.appendChild(css);
  var LET = ['ⲁ', 'ⲃ', 'ⲅ', 'ⲇ', 'ⲉ', 'ⲍ', 'ⲏ', 'ⲑ'];
  function game() {
    var g = document.getElementById('zexpGame');
    if (!g) { g = el('<div id="zexpGame" hidden></div>'); document.body.appendChild(g); }
    var cards = LET.concat(LET).sort(function () { return Math.random() - .5; }), first = null, lock = false, moves = 0, found = 0;
    g.innerHTML = '<div style="width:100%;display:flex;justify-content:space-between;align-items:center"><b style="font-size:19px;color:#E3B257">ذاكرة الحروف القبطية (تجربة)</b><button class="zexp-btn" id="zexpX" style="margin:0;padding:6px 14px">رجوع</button></div>' +
      '<p id="zexpMsg" style="opacity:.8;margin-top:10px">دوّر على كل حرفين متشابهين. الحركات: 0</p><div class="zexp-grid"></div>';
    var grid = g.querySelector('.zexp-grid'), msg = g.querySelector('#zexpMsg');
    cards.forEach(function (c, i) {
      var b = el('<div class="zexp-c">؟</div>'); grid.appendChild(b);
      b.addEventListener('click', function () {
        if (lock || b.classList.contains('open') || b.classList.contains('done')) return;
        b.classList.add('open'); b.textContent = c;
        if (first === null) { first = b; return; }
        moves++; var a = first; first = null;
        if (a.textContent === c) { a.className = b.className = 'zexp-c done'; found++; if (found === 8) msg.textContent = 'خلصتها في ' + moves + ' حركة!'; }
        else { lock = true; setTimeout(function () { a.className = b.className = 'zexp-c'; a.textContent = b.textContent = '؟'; lock = false; }, 700); }
        if (found < 8) msg.textContent = 'دوّر على كل حرفين متشابهين. الحركات: ' + moves;
      });
    });
    g.querySelector('#zexpX').addEventListener('click', function () { g.hidden = true; });
    g.hidden = false;
  }
  function home() {
    var h = document.getElementById('scr-home'); var old = document.getElementById('zexpHome');
    if (old) old.remove();
    if (!h || !on()) return;
    var c = el('<div class="zexp-card" id="zexpHome"><b>تجربة تحديث (٣)</b><p style="margin-top:6px;line-height:1.9">الكارت ده جه من تحديث الواجهة، مش من التطبيق نفسه. مؤقت، ويتشال لما تقول.</p><button class="zexp-btn" id="zexpPlay">العب لعبة الذاكرة</button></div>');
    (h.querySelector('.scroll')||h).appendChild(c); c.querySelector('#zexpPlay').addEventListener('click', game);
  }
  function settings() {
    var s = document.getElementById('scr-settings'); if (!s) return;
    var st = document.getElementById('zUpdSt');
    if (!st || document.getElementById('zexpSet')) return;
    var r = el('<div class="set-row" id="zexpSet"><label><input type="checkbox" id="zexpChk"' + (on() ? ' checked' : '') + '> إظهار تجارب التحديث (تجربة ٣)</label></div>');
    st.parentNode.insertBefore(r, st.nextSibling);
    r.querySelector('input').addEventListener('change', function (e) { try { localStorage.setItem(KEY, e.target.checked ? '1' : '0'); } catch (x) {} home(); });
  }
  function init() { home(); settings(); var s = document.getElementById('scr-settings'); if (s) new MutationObserver(settings).observe(s, { childList: true, subtree: true }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 800); }); else setTimeout(init, 800);
})();

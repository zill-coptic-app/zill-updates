/* TEMPORARY New Year winter theme experiment (zs-5). Removable from Settings; not part of the app proper. */
(function () {
  var KEY = 'zill.win.on';
  function on() { try { return localStorage.getItem(KEY) !== '0'; } catch (e) { return true; } }
  var $ = function (i) { return document.getElementById(i); };
  if (!on()) { window.addEventListener('DOMContentLoaded', settingsInit); setTimeout(settingsInit, 1200); return; }
  var lowEnd = (navigator.hardwareConcurrency || 4) <= 4 || (navigator.deviceMemory || 4) <= 3;
  var still = false;
  try { still = document.documentElement.getAttribute('data-motion') === '0' || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) {}

  var HAT = '<svg class="zw-hat" viewBox="0 0 64 48" aria-hidden="true"><path d="M6 40C8 18 22 4 44 6c4 .5 8 3 10 8-6-2-10-1-12 3 6 4 10 12 12 23z" fill="#D2232A"/><path d="M6 40C8 18 22 4 44 6c-14 4-22 14-24 34z" fill="#EF4B4B" opacity=".55"/><rect x="2" y="34" width="60" height="12" rx="6" fill="#F7F7FB"/><circle cx="52" cy="10" r="6.5" fill="#fff"/></svg>';
  var HEAD = '<svg viewBox="0 0 80 84" aria-hidden="true"><path d="M10 34C10 14 26 2 44 4c6 1 12 4 14 10-6-2-10 0-12 4 10 4 18 8 22 16z" fill="#D2232A"/><circle cx="64" cy="14" r="7" fill="#fff"/><rect x="8" y="30" width="64" height="12" rx="6" fill="#fff"/><circle cx="40" cy="52" r="20" fill="#F6C9A3"/><path d="M18 52c0 18 10 28 22 28s22-10 22-28c-4 8-12 10-22 10S22 60 18 52z" fill="#fff"/><circle cx="32" cy="50" r="2.4" fill="#2a2a3a"/><circle cx="48" cy="50" r="2.4" fill="#2a2a3a"/><circle cx="40" cy="56" r="4" fill="#E58A8A"/><path d="M30 64c6 4 14 4 20 0" stroke="#d9d9e6" stroke-width="3" fill="none" stroke-linecap="round"/></svg>';
  var SLEIGH = '<svg viewBox="0 0 240 80" aria-hidden="true"><g fill="none" stroke="#7a4a22" stroke-width="3" stroke-linecap="round"><path d="M10 40h40M10 40l-6-8M30 40l8 14M50 40l8 14"/></g><g fill="#8a5a2b"><ellipse cx="36" cy="38" rx="17" ry="9"/><circle cx="12" cy="30" r="6"/></g><g stroke="#e9c074" stroke-width="2.5" fill="none" stroke-linecap="round"><path d="M10 25l-4-10M10 25l5-9M8 17l-5-2M13 17l4-5"/></g><circle cx="7" cy="32" r="2.4" fill="#e23"/><path d="M62 40h28" stroke="#e9c074" stroke-width="2"/><path d="M90 48c0-14 6-22 18-22h82c0 22-12 34-30 34H108c-10 0-18-4-18-12z" fill="#C62232"/><path d="M96 62c20 6 92 6 118 0" stroke="#E3B257" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M96 70c10 4 18 4 26 0" stroke="#E3B257" stroke-width="3" fill="none"/><circle cx="170" cy="22" r="14" fill="#F6C9A3"/><path d="M158 20c6 14 18 14 24 0-2 8-6 10-12 10s-10-2-12-10z" fill="#fff"/><path d="M156 18c0-12 10-16 20-14 4 1 8 4 8 8l-6-2c4 4 6 8 6 12z" fill="#D2232A"/><circle cx="186" cy="8" r="4" fill="#fff"/><rect x="190" y="28" width="26" height="22" rx="8" fill="#B38A4A"/><rect x="194" y="22" width="10" height="9" fill="#2e8b57"/><rect x="206" y="20" width="9" height="10" fill="#E3B257"/></svg>';

  var css = document.createElement('style');
  css.textContent =
    '#zwSnow{position:fixed;inset:0;width:100%;height:100%;z-index:29;pointer-events:none}' +
    /* hat on the logo */
    '.zw-logo{position:relative;display:inline-block;line-height:0;margin-inline-end:0}.zw-logo .zw-hat{position:absolute;width:26px;height:20px;top:-12px;right:-7px;transform:rotate(14deg);transform-origin:50% 100%;animation:zwWob 3.4s ease-in-out infinite;pointer-events:none;filter:drop-shadow(0 1px 1px rgba(0,0,0,.35))}' +
    '@keyframes zwWob{0%,100%{transform:rotate(12deg)}50%{transform:rotate(20deg)}}' +
    /* snow caps on cards */
    '.zw-cap{position:absolute;top:-4px;left:7%;right:7%;height:11px;pointer-events:none;z-index:2;background:' +
    'radial-gradient(ellipse 14px 9px at 12% 70%,#fff 62%,transparent 64%),radial-gradient(ellipse 20px 11px at 34% 60%,#fff 62%,transparent 64%),radial-gradient(ellipse 12px 8px at 52% 75%,#fff 62%,transparent 64%),radial-gradient(ellipse 22px 11px at 74% 60%,#fff 62%,transparent 64%),radial-gradient(ellipse 12px 8px at 92% 72%,#fff 62%,transparent 64%),linear-gradient(#fff,#fff) 0 8px/100% 3px no-repeat;filter:drop-shadow(0 1px 1px rgba(60,90,160,.45))}' +
    '.zw-rel{position:relative}' +
    '.zw-hbar .zw-cap{left:10%;right:10%}' +
    /* drift at the bottom */
    '#zwDrift{position:fixed;left:0;right:0;bottom:0;height:10px;z-index:28;pointer-events:none;transition:height 90s linear;background:linear-gradient(#fff,#dbe8ff);border-radius:60% 40% 0 0/22px 18px 0 0;box-shadow:0 -3px 8px rgba(255,255,255,.35)}' +
    '#zwDrift.zw-grow{height:34px}' +
    /* frozen glass nav */
    'html.zw #bottomNav{background:linear-gradient(180deg,rgba(214,236,255,.30),rgba(120,170,230,.22) 55%,rgba(34,52,112,.96)),rgba(22,32,78,.97);border:1px solid rgba(215,235,255,.7);box-shadow:inset 0 1px 0 rgba(255,255,255,.8),inset 0 0 18px rgba(170,210,255,.28),0 0 14px rgba(150,200,255,.28)}' +
    'html.zw #bottomNav::before{content:"";position:absolute;inset:0;border-radius:26px;pointer-events:none;z-index:0;background:radial-gradient(circle at 12% 30%,rgba(255,255,255,.7) 0 1px,transparent 2px),radial-gradient(circle at 38% 70%,rgba(255,255,255,.6) 0 1px,transparent 2px),radial-gradient(circle at 63% 25%,rgba(255,255,255,.7) 0 1px,transparent 2px),radial-gradient(circle at 88% 60%,rgba(255,255,255,.6) 0 1.4px,transparent 2.4px),linear-gradient(115deg,transparent 30%,rgba(255,255,255,.18) 38%,transparent 46%)}' +
    'html.zw #bottomNav::after{content:"";position:absolute;left:10px;right:10px;bottom:0;height:11px;pointer-events:none;z-index:0;background:linear-gradient(135deg,transparent 50%,rgba(230,244,255,.9) 50%) 0 0/14px 11px,linear-gradient(225deg,transparent 50%,rgba(230,244,255,.9) 50%) 0 0/14px 11px;background-repeat:repeat-x;opacity:.9;}' +
    'html.zw #bottomNav .nav-pill{background:linear-gradient(180deg,rgba(235,248,255,.5),rgba(150,200,255,.22));border-color:rgba(225,242,255,.85);box-shadow:inset 0 1px 0 #fff,0 0 12px rgba(170,215,255,.5)}' +
    'html.zw .nav-item{opacity:.8;color:#EAF4FF}html.zw .nav-item.active{color:#fff}' +
    'html.zw[data-theme="light"] #bottomNav{background:linear-gradient(180deg,rgba(255,255,255,.95),rgba(200,225,250,.92));border-color:rgba(120,160,215,.8)}' +
    'html.zw[data-theme="light"] .nav-item{color:#1f3a6e;opacity:.75}html.zw[data-theme="light"] .nav-item.active{color:#0d2a63;opacity:1}' +
    'html.zw[data-theme="light"] #bottomNav .nav-pill{background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(160,200,245,.5));border-color:rgba(100,150,210,.9)}' +
    'html.zw[data-theme="light"] .zw-cap{filter:drop-shadow(0 1px 1px rgba(60,90,160,.7))}' +
    /* santa band: reserved decorative strip at the very top of Home, no content under it */
    '.zw-band{position:relative;height:40px;overflow:hidden;pointer-events:none;margin:0 -4px}' +
    '#zwSleigh{position:absolute;top:3px;left:0;width:104px;height:35px;transform:translateX(-120px);will-change:transform}' +
    '#zwSleigh.zw-fly{animation:zwFly 8s linear 1 forwards}' +
    '@keyframes zwFly{0%{transform:translate(-120px,2px)}25%{transform:translate(calc(var(--bw,360px)*.25),-2px)}50%{transform:translate(calc(var(--bw,360px)*.5),3px)}75%{transform:translate(calc(var(--bw,360px)*.75),-2px)}100%{transform:translate(calc(var(--bw,360px) + 20px),2px)}}' +
    '#zwSleigh svg{width:100%;height:100%}' +
    '#zwPeek{position:absolute;left:12px;bottom:-6px;width:36px;height:38px;animation:zwPeek 4.2s ease-in-out infinite;transform-origin:50% 100%}' +
    '@keyframes zwPeek{0%,100%{transform:translateY(5px) rotate(-5deg)}50%{transform:translateY(-1px) rotate(6deg)}}' +
    '#zwPeek svg{width:100%;height:100%}' +
    /* entry splash */
    '#zwSplash{position:fixed;inset:0;z-index:100000;background:radial-gradient(circle at 50% 36%,#2b3f86 0,#141a42 55%,#0b0f2a 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;transition:opacity .6s;direction:rtl;font-family:"Noto Sans Arabic",sans-serif;color:#F3EDDF}' +
    '#zwSplash.zw-out{opacity:0;pointer-events:none}' +
    '#zwSplash .zw-sl{position:relative;width:104px;height:104px;animation:zwPop .9s cubic-bezier(.3,1.4,.5,1) both}' +
    '#zwSplash .zw-sl img{width:104px;height:104px;border-radius:26px;object-fit:cover;box-shadow:0 0 0 2px rgba(233,192,116,.6),0 0 30px rgba(170,210,255,.45)}' +
    '#zwSplash .zw-sl .zw-hat{position:absolute;width:82px;height:62px;top:-38px;right:-22px;transform:rotate(14deg);filter:drop-shadow(0 2px 3px rgba(0,0,0,.4))}' +
    '#zwSplash .zw-sl::after{content:"";position:absolute;left:4px;right:4px;bottom:-4px;height:10px;border-radius:8px;background:radial-gradient(ellipse 10px 7px at 15% 40%,#fff 60%,transparent 62%),radial-gradient(ellipse 14px 8px at 45% 50%,#fff 60%,transparent 62%),radial-gradient(ellipse 12px 7px at 80% 40%,#fff 60%,transparent 62%)}' +
    '@keyframes zwPop{0%{transform:scale(.4) translateY(20px);opacity:0}100%{transform:none;opacity:1}}' +
    '#zwSplash .zw-t{font-size:30px;font-weight:800;color:#E9C074;text-shadow:0 0 18px rgba(233,192,116,.5);animation:zwUp .8s .3s both}' +
    '#zwSplash .zw-s{font-size:16px;color:#dbe8ff;animation:zwUp .8s .55s both}' +
    '@keyframes zwUp{0%{transform:translateY(14px);opacity:0}100%{transform:none;opacity:1}}' +
    '#zwSplash .zw-santa{position:absolute;bottom:9%;left:50%;width:70px;margin-left:-35px;animation:zwPeek 2.4s ease-in-out infinite}' +
    '#zwSplash canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}' +
    'html.zw[data-theme="light"] #zwSplash{background:radial-gradient(circle at 50% 36%,#5b78c9,#2a3a80 70%)}' +
    '@media (prefers-reduced-motion:reduce){#zwSleigh,#zwPeek,.zw-hat{animation:none!important}}';
  document.head.appendChild(css);
  document.documentElement.classList.add('zw');

  /* ---------- snow ---------- */
  function mkSnow(cv, n, speed) {
    var c = cv.getContext('2d'), W = 0, H = 0, ps = [], dpr = Math.min(window.devicePixelRatio || 1, lowEnd ? 1 : 1.5), run = true, last = 0;
    function size() { W = cv.clientWidth; H = cv.clientHeight; cv.width = W * dpr; cv.height = H * dpr; c.setTransform(dpr, 0, 0, dpr, 0, 0); }
    size(); window.addEventListener('resize', size);
    for (var i = 0; i < n; i++) ps.push({ x: Math.random() * W, y: Math.random() * H, r: 1 + Math.random() * 2.6, v: .35 + Math.random() * .9, p: Math.random() * 6.28, s: .4 + Math.random() * .8 });
    function draw() { c.clearRect(0, 0, W, H); for (var i = 0; i < ps.length; i++) { var p = ps[i]; c.globalAlpha = .45 + p.r / 5; c.fillStyle = '#fff'; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.283); c.fill(); } }
    function step(t) {
      if (!run) return;
      if (t - last > (lowEnd ? 50 : 33)) {
        var dt = Math.min((t - last) / 16, 3); last = t;
        for (var i = 0; i < ps.length; i++) { var p = ps[i]; p.y += p.v * speed * dt; p.p += .02 * dt; p.x += Math.sin(p.p) * p.s * dt * .6; if (p.y > H + 4) { p.y = -6; p.x = Math.random() * W; } if (p.x > W + 6) p.x = -6; if (p.x < -6) p.x = W + 6; }
        draw();
      }
      requestAnimationFrame(step);
    }
    draw();
    if (!still) requestAnimationFrame(step);
    document.addEventListener('visibilitychange', function () { var was = run; run = !document.hidden; if (run && !was && !still) requestAnimationFrame(step); });
    return { stop: function () { run = false; } };
  }

  function homeVisible() { var h = $('scr-home'); return !!h && !h.hidden && h.style.display !== 'none'; }

  function build() {
    if (!$('zwSnow')) { var cv = document.createElement('canvas'); cv.id = 'zwSnow'; document.body.appendChild(cv); mkSnow(cv, lowEnd ? 26 : 46, 1.15); }
    if (!$('zwDrift')) { var d = document.createElement('div'); d.id = 'zwDrift'; document.body.appendChild(d); setTimeout(function () { d.classList.add('zw-grow'); }, 400); }
    var sc = document.querySelector('#scr-home .scroll');
    if (sc && !sc.querySelector('.zw-band')) { var bd = document.createElement('div'); bd.className = 'zw-band'; bd.innerHTML = '<div id="zwPeek">' + HEAD + '</div><div id="zwSleigh">' + SLEIGH + '</div>'; sc.insertBefore(bd, sc.firstChild); }
    var logo = $('brandLogo');
    if (logo && !logo.parentNode.classList.contains('zw-logo')) { var w = document.createElement('span'); w.className = 'zw-logo'; logo.parentNode.insertBefore(w, logo); w.appendChild(logo); w.insertAdjacentHTML('beforeend', HAT); }
    caps();
  }
  function caps() {
    var sel = ['.sec-card', '#homeQuote', '#bottomNav', '.card:not(.bottom-nav)'];
    document.querySelectorAll(sel.join(',')).forEach(function (e) {
      if (e.querySelector(':scope > .zw-cap') || e.offsetWidth < 60) return;
      var cs = getComputedStyle(e); if (cs.position === 'static') e.classList.add('zw-rel');
      var i = document.createElement('i'); i.className = 'zw-cap'; e.insertBefore(i, e.firstChild);
    });
  }
  function fly() { var sl = $('zwSleigh'); if (!sl || !homeVisible() || still) return; var bd = sl.parentNode; bd.style.setProperty('--bw', bd.clientWidth + 'px'); sl.classList.remove('zw-fly'); void sl.offsetWidth; sl.classList.add('zw-fly'); }

  /* ---------- entry splash ---------- */
  function splash() {
    var sp = document.createElement('div'); sp.id = 'zwSplash';
    sp.innerHTML = '<canvas></canvas><div class="zw-sl"><img src="assets/img/logo_zill.png" alt="">' + HAT + '</div><div class="zw-t">كل سنة وانت طيب</div><div class="zw-s">سنة جديدة مليانة نور وسلام</div><div class="zw-santa">' + HEAD + '</div>';
    document.body.appendChild(sp);
    var sn = mkSnow(sp.querySelector('canvas'), lowEnd ? 40 : 70, 1.5), done = false;
    function out() { if (done) return; done = true; sp.classList.add('zw-out'); setTimeout(function () { sn.stop(); sp.remove(); fly(); }, 650); }
    sp.addEventListener('click', out); sp.addEventListener('touchstart', out, { passive: true });
    setTimeout(out, 2300);
  }

  /* ---------- settings row ---------- */
  function settingsInit() {
    function row() {
      var st = $('zUpdSt'); if (!st || $('zWinSet')) return;
      var d = document.createElement('div'); d.className = 'set-row'; d.id = 'zWinSet';
      d.innerHTML = '<label><input type="checkbox"' + (on() ? ' checked' : '') + '> ثيم رأس السنة (تجربة ٥)</label>';
      st.parentNode.insertBefore(d, st.nextSibling);
      d.querySelector('input').addEventListener('change', function (e) { try { localStorage.setItem(KEY, e.target.checked ? '1' : '0'); } catch (x) {} location.reload(); });
    }
    row(); var s = $('scr-settings'); if (s) new MutationObserver(row).observe(s, { childList: true, subtree: true });
  }

  function init() {
    build(); settingsInit();
    var obs = new MutationObserver(function () { clearTimeout(init._t); init._t = setTimeout(function () { build(); }, 200); });
    obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });
    setInterval(function () { if (!document.hidden) fly(); }, 26000);
  }
  if (document.body) splash(); else document.addEventListener('DOMContentLoaded', splash);
  setTimeout(init, 900);
})();

/* TEMPORARY update experiment (zs-3). Removable from Settings; not part of the app proper. */
(function () {
  var KEY = 'zill.exp.on';
  function on() { try { return localStorage.getItem(KEY) !== '0'; } catch (e) { return true; } }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h; return d.firstChild; }
  var css = document.createElement('style');
  css.textContent = '.zexp-card{margin:14px 16px 120px;padding:14px 16px;border-radius:18px;background:var(--card-bg);border:1px dashed var(--gold);color:var(--text);font-family:"Noto Sans Arabic",sans-serif;text-align:right}' +
    '.zexp-card b{color:var(--gold)}.zexp-btn{margin-top:10px;padding:10px 18px;border-radius:14px;border:0;background:var(--gold);color:var(--on-gold);font:700 15px "Noto Sans Arabic",sans-serif}' +
    '#zexpGame{position:fixed;inset:0;z-index:99999;background:#17142e;color:#F3EDDF;display:flex;flex-direction:column;align-items:center;padding:18px;direction:rtl;font-family:"Noto Sans Arabic",sans-serif}' +
    '#zexpGame[hidden]{display:none}.zexp-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;width:min(92vw,380px);margin-top:14px}' +
    '.zexp-c{aspect-ratio:1;border-radius:14px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#E3B257;font-size:30px;display:flex;align-items:center;justify-content:center;cursor:pointer;user-select:none}' +
    '.zexp-c.open{background:#E3B257;color:#241A08}.zexp-c.done{background:rgba(227,178,87,.25);color:#E3B257;opacity:.6}';
  document.head.appendChild(css);
  var LET = ['ⲁ', 'ⲃ', 'ⲅ', 'ⲇ', 'ⲉ', 'ⲍ', 'ⲏ', 'ⲑ'];
  function game() {
    var g = document.getElementById('zexpGame');
    if (!g) { g = el('<div id="zexpGame" hidden></div>'); document.body.appendChild(g); }
    var cards = LET.concat(LET).sort(function () { return Math.random() - .5; }), first = null, lock = false, moves = 0, found = 0;
    g.innerHTML = '<div style="width:100%;display:flex;justify-content:space-between;align-items:center"><b style="font-size:19px;color:#E3B257">ذاكرة الحروف القبطية (تجربة)</b><button class="zexp-btn" id="zexpX" style="margin:0;padding:6px 14px">رجوع</button></div>' +
      '<p id="zexpMsg" style="opacity:.8;margin-top:10px">دوّر على كل حرفين متشابهين. الحركات: 0</p><div class="zexp-grid"></div>';
    var grid = g.querySelector('.zexp-grid'), msg = g.querySelector('#zexpMsg');
    cards.forEach(function (c, i) {
      var b = el('<div class="zexp-c">؟</div>'); grid.appendChild(b);
      b.addEventListener('click', function () {
        if (lock || b.classList.contains('open') || b.classList.contains('done')) return;
        b.classList.add('open'); b.textContent = c;
        if (first === null) { first = b; return; }
        moves++; var a = first; first = null;
        if (a.textContent === c) { a.className = b.className = 'zexp-c done'; found++; if (found === 8) msg.textContent = 'خلصتها في ' + moves + ' حركة!'; }
        else { lock = true; setTimeout(function () { a.className = b.className = 'zexp-c'; a.textContent = b.textContent = '؟'; lock = false; }, 700); }
        if (found < 8) msg.textContent = 'دوّر على كل حرفين متشابهين. الحركات: ' + moves;
      });
    });
    g.querySelector('#zexpX').addEventListener('click', function () { g.hidden = true; });
    g.hidden = false;
  }
  function home() {
    var h = document.getElementById('scr-home'); var old = document.getElementById('zexpHome');
    if (old) old.remove();
    if (!h || !on()) return;
    var c = el('<div class="zexp-card" id="zexpHome"><b>تجربة تحديث (٣)</b><p style="margin-top:6px;line-height:1.9">الكارت ده جه من تحديث الواجهة، مش من التطبيق نفسه. مؤقت، ويتشال لما تقول.</p><button class="zexp-btn" id="zexpPlay">العب لعبة الذاكرة</button></div>');
    (h.querySelector('.scroll')||h).appendChild(c); c.querySelector('#zexpPlay').addEventListener('click', game);
  }
  function settings() {
    var s = document.getElementById('scr-settings'); if (!s) return;
    var st = document.getElementById('zUpdSt');
    if (!st || document.getElementById('zexpSet')) return;
    var r = el('<div class="set-row" id="zexpSet"><label><input type="checkbox" id="zexpChk"' + (on() ? ' checked' : '') + '> إظهار تجارب التحديث (تجربة ٣)</label></div>');
    st.parentNode.insertBefore(r, st.nextSibling);
    r.querySelector('input').addEventListener('change', function (e) { try { localStorage.setItem(KEY, e.target.checked ? '1' : '0'); } catch (x) {} home(); });
  }
  function init() { home(); settings(); var s = document.getElementById('scr-settings'); if (s) new MutationObserver(settings).observe(s, { childList: true, subtree: true }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 800); }); else setTimeout(init, 800);
})();

/* TEMPORARY tree-home experiment (zs-4). Reuses the existing section cards' own click handling; nothing is removed. */
(function () {
  var TKEY = 'zill.exp.tree';
  function tOn() { try { return localStorage.getItem(TKEY) !== '0'; } catch (e) { return true; } }
  function expOn() { try { return localStorage.getItem('zill.exp.on') !== '0'; } catch (e) { return true; } }
  var IC = {
    bible: '<path d="M7 4h10a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 12h8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    katameros: '<path d="M12 6c-2-1.5-5-1.5-8-1v13c3-.5 6-.5 8 1m0-13c2-1.5 5-1.5 8-1v13c-3-.5-6-.5-8 1m0-13v13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    kids: '<circle cx="12" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M5.5 20c.6-4 3.2-6 6.5-6s5.9 2 6.5 6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    today: '<path d="M12 3c1.6 2 2.2 3.200 2.200 4.300a2.200 2.200 0 0 1-4.400 0C9.800 6.200 10.400 5 12 3ZM9.500 12h5v8h-5z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    doctrine: '<path d="M12 3v18M6 9h12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    games2: '<rect x="3" y="8" width="18" height="9" rx="4.500" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 10.500v4M6 12.500h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="15.500" cy="12" r=".9" fill="currentColor"/><circle cx="17.800" cy="13.500" r=".9" fill="currentColor"/>',
    game: '<circle cx="12" cy="8" r="3.200" fill="none" stroke="currentColor" stroke-width="1.600"/><path d="M5.500 20c.6-4 3.200-6 6.500-6s5.900 2 6.500 6" fill="none" stroke="currentColor" stroke-width="1.600" stroke-linecap="round"/>',
    rem: '<path d="M6 17V11a6 6 0 0 1 12 0v6l1.500 2h-15L6 17Z" fill="none" stroke="currentColor" stroke-width="1.600" stroke-linejoin="round"/><path d="M10 21a2 2 0 0 0 4 0" fill="none" stroke="currentColor" stroke-width="1.600" stroke-linecap="round"/>'
  };
  // id, label, x, y (css px in a 360x470 canvas), label side
  var N = [
    ['bible', 'الكتاب المقدس', 124, 40, 'b'], ['katameros', 'القطمارس', 240, 36, 'b'],
    ['kids', 'قسم الأطفال', 300, 100, 'b'], ['today', 'صلاة اليوم', 58, 102, 'b'],
    ['doctrine', 'العقيدة', 94, 178, 'l'], ['games2', 'ألعاب أكتر', 262, 172, 'r'],
    ['game', 'مين الشخصية؟', 88, 276, 'b'], ['rem', 'المُذكّر', 272, 274, 'b']
  ];
  var P = [
    'M178 204 Q150 110 124 39', 'M178 204 Q215 110 240 35', 'M176 236 Q100 190 58 101', 'M176 236 Q260 190 300 99',
    'M176 276 Q120 240 94 177', 'M176 276 Q230 240 262 171', 'M179 307 Q130 300 88 275', 'M179 307 Q230 300 272 273'
  ];
  var css = document.createElement('style');
  css.textContent = '#zTree{position:relative;width:100%;margin:6px 0 0;direction:ltr;overflow:visible}#zTreeIn{position:absolute;left:0;top:0;width:360px;height:470px;transform-origin:0 0}' +
    '#zTree svg.tr{position:absolute;inset:0;width:100%;height:100%}' +
    '.zt-n{position:absolute;width:48px;height:48px;margin:-24px 0 0 -24px;border-radius:50%;border:1.5px solid var(--gold);background:rgba(40,34,70,.85);color:var(--gold);display:flex;align-items:center;justify-content:center;box-shadow:0 0 14px rgba(227,178,87,.35);cursor:pointer;-webkit-tap-highlight-color:transparent}' +
    '.zt-n svg{width:24px;height:24px}.zt-n:active{transform:scale(.94)}' +
    '.zt-t{position:absolute;white-space:nowrap;font:700 13px "Noto Sans Arabic",sans-serif;color:var(--text);direction:rtl;pointer-events:none;transform:translateX(-50%)}' +
    '.zt-more{display:block;margin:4px auto 10px;padding:10px 20px;border-radius:14px;border:1px solid var(--gold);background:transparent;color:var(--gold);font:700 14px "Noto Sans Arabic",sans-serif}' +

    '.ztree .hdr{padding:0 2px}.ztree .brand-logo{width:26px;height:26px;border-radius:7px}.ztree .wordmark{font-size:20px;padding-top:4px}' +
    '.ztree .icon-btn{width:30px;height:30px;border-radius:50%}.ztree .icon-btn svg{width:15px;height:15px}.ztree .hdr-actions{gap:8px}' +
    '.ztree .greet{display:flex;justify-content:space-between;align-items:center;padding:8px 2px 2px}.ztree .greet-hi{font-size:17px}' +
    '.ztree .greet-date{margin:0;gap:6px;border:1px solid var(--card-border);background:var(--card-bg);border-radius:99px;padding:4px 10px}' +
    '.ztree .coptic-chip{font-size:11px;background:none;color:var(--gold2);padding:0}.ztree .greg{font-size:11px;opacity:.85}' +
    '.ztree .home-quote{display:flex;align-items:center;gap:8px;padding:9px 16px;margin:8px 4px 0;border-radius:28px;text-align:right;cursor:pointer}' +
    '.ztree .hq-tx{flex:1;min-width:0;font-size:13px;line-height:1.7;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.ztree .hq-src{margin:0;white-space:nowrap;font-size:11px}' +
    '.ztree .home-quote.zq-open{flex-wrap:wrap;border-radius:22px;text-align:center}.ztree .home-quote.zq-open .hq-tx{flex:1 1 100%;white-space:normal;font-size:17px;line-height:2}.ztree .home-quote.zq-open .hq-src{flex:1 1 100%;text-align:center}' +
    '#zTree{margin-top:2px}' +
    '#secGrid.zt-hide{display:none}';
  document.head.appendChild(css);
  function hit(id) {
    if (id === 'rem') { var r = document.getElementById('btnRem'); if (r) r.click(); return; }
    var c = document.querySelector('#secGrid .sec-card[data-sec="' + id + '"]'); if (c) c.click();
  }
  function build() {
    var old = document.getElementById('zTree'); if (old) old.remove();
    var oldb = document.getElementById('zTreeMore'); if (oldb) oldb.remove();
    var grid = document.getElementById('secGrid'); if (!grid) return;
    var onx = tOn() && expOn(); document.documentElement.classList.toggle('ztree', onx);
    if (!onx) { grid.classList.remove('zt-hide'); return; }
    var hq = document.getElementById('homeQuote'); if (hq && !hq._zq) { hq._zq = 1; hq.addEventListener('click', function () { hq.classList.toggle('zq-open'); }); }
    var h = '<svg class="tr" viewBox="0 0 360 470" preserveAspectRatio="none"><g fill="none" stroke="#C9964A" stroke-width="2.500" stroke-linecap="round" opacity=".9">' +
      '<path d="M180 461 C178 400 182 340 179 307 C177 280 177 250 176 236 C177 225 178 215 178 204"/>' + P.map(function (d) { return '<path d="' + d + '"/>'; }).join('') +
      '<path d="M180 461 Q150 445 120 438 M180 461 Q210 445 240 434"/></g></svg>';
    N.forEach(function (n) {
      h += '<div class="zt-n" data-z="' + n[0] + '" role="button" aria-label="' + n[1] + '" style="left:' + n[2] + 'px;top:' + n[3] + 'px"><svg viewBox="0 0 24 24">' + IC[n[0]] + '</svg></div>';
      var lx = n[2], ly = n[3] + 28;
      if (n[4] === 'l') { lx = 33; ly = n[3] - 10; } else if (n[4] === 'r') { lx = 324; ly = n[3] - 10; }
      h += '<div class="zt-t" style="left:' + lx + 'px;top:' + ly + 'px">' + n[1] + '</div>';
    });
    var t = document.createElement('div'); t.id = 'zTree'; t.innerHTML = '<div id="zTreeIn">' + h + '</div>';
    grid.parentNode.insertBefore(t, grid);
    var fit = function () { var k = Math.min(1.25, (t.clientWidth || 360) / 360); t.firstChild.style.transform = 'scale(' + k + ')'; t.style.height = Math.round(470 * k) + 'px'; }; fit(); window.addEventListener('resize', fit);
    t.querySelectorAll('.zt-n').forEach(function (e) { e.addEventListener('click', function () { hit(e.getAttribute('data-z')); }); });
    var b = document.createElement('button'); b.id = 'zTreeMore'; b.className = 'zt-more'; b.textContent = 'باقي الأقسام ▾';
    grid.classList.add('zt-hide');
    b.addEventListener('click', function () { var hid = grid.classList.toggle('zt-hide'); b.textContent = hid ? 'باقي الأقسام ▾' : 'إخفاء باقي الأقسام ▴'; });
    grid.parentNode.insertBefore(b, grid);
  }
  function settingsRow() {
    var st = document.getElementById('zUpdSt'); if (!st || document.getElementById('zTreeSet')) return;
    var d = document.createElement('div'); d.className = 'set-row'; d.id = 'zTreeSet';
    d.innerHTML = '<label><input type="checkbox"' + (tOn() ? ' checked' : '') + '> الرئيسية على شكل شجرة (تجربة ٤)</label>';
    st.parentNode.insertBefore(d, st.nextSibling);
    d.querySelector('input').addEventListener('change', function (e) { try { localStorage.setItem(TKEY, e.target.checked ? '1' : '0'); } catch (x) {} build(); });
  }
  function init() { build(); settingsRow(); var s = document.getElementById('scr-settings'); if (s) new MutationObserver(settingsRow).observe(s, { childList: true, subtree: true }); }
  setTimeout(init, 1200);
})();
